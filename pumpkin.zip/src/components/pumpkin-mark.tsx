export function PumpkinMark({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="pumpkin-body" x1="10" y1="16" x2="54" y2="58" gradientUnits="userSpaceOnUse">
          <stop stopColor="#ffb46b" />
          <stop offset="0.5" stopColor="#ff7a18" />
          <stop offset="1" stopColor="#c2490a" />
        </linearGradient>
      </defs>
      <path
        d="M33 12c-.8-3.2-.1-6 2.6-7.6"
        stroke="#8fbf5a"
        strokeWidth="3.4"
        strokeLinecap="round"
        fill="none"
      />
      <path d="M32 11c4-2.6 10-2 12 1-3.4 2.8-9.2 2.6-12-1Z" fill="#6f9c45" />
      <ellipse cx="32" cy="37" rx="24" ry="19" fill="url(#pumpkin-body)" />
      <ellipse cx="32" cy="37" rx="9" ry="19" fill="#ffd6a5" opacity="0.28" />
      <ellipse cx="19" cy="37" rx="5.5" ry="15" fill="#a13a04" opacity="0.35" />
      <ellipse cx="45" cy="37" rx="5.5" ry="15" fill="#a13a04" opacity="0.35" />
      <path d="M22 33l5 3.5-5 2.6zM42 33l-5 3.5 5 2.6z" fill="#2a1305" />
      <path d="M25 45l7 4 7-4" stroke="#2a1305" strokeWidth="2.6" strokeLinecap="round" fill="none" />
    </svg>
  );
}
