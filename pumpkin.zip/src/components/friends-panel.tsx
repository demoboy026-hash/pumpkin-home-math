"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Check,
  Loader2,
  MessageSquare,
  Search,
  Send,
  UserMinus,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { AvatarView } from "@/components/avatar-view";
import { useSettings } from "@/components/providers";
import { useAccount } from "@/lib/account";

type Person = {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  effect: string | null;
};

type Friend = Person & {
  since: string;
  unread: number;
  lastMessage: { body: string; at: string; mine: boolean } | null;
};

type Request = Person & { requestId: number; requestedAt: string };

type FriendsPayload = {
  friends: Friend[];
  incoming: Request[];
  outgoing: Request[];
  suggestions: Person[];
  pendingRequests: number;
  error?: string;
};

type DmMessage = { id: number; mine: boolean; body: string; read: boolean; createdAt: string };

const EMPTY: FriendsPayload = {
  friends: [],
  incoming: [],
  outgoing: [],
  suggestions: [],
  pendingRequests: 0,
};

function timeAgo(iso: string) {
  const seconds = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.round(seconds / 3600)}h`;
  return `${Math.round(seconds / 86400)}d`;
}

export function FriendsPanel() {
  const { user, loading: accountLoading, refresh } = useAccount();
  const [noSession, setNoSession] = useState(false);
  const { notify } = useSettings();
  const [data, setData] = useState<FriendsPayload>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<DmMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [threadLoading, setThreadLoading] = useState(false);
  const [threadError, setThreadError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/friends", { cache: "no-store" });
      if (response.status === 401) {
        setData(EMPTY);
        setNoSession(true);
        return;
      }
      if (!response.ok) return;
      const payload = (await response.json()) as FriendsPayload;
      if (!payload.error) {
        setNoSession(false);
        setData({ ...EMPTY, ...payload });
        setActiveId((current) => {
          if (current && payload.friends.some((friend) => friend.id === current)) return current;
          return payload.friends[0]?.id ?? null;
        });
      }
    } catch {
      // keep the previous list
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const interval = setInterval(() => void load(), 8000);
    return () => clearInterval(interval);
  }, [load, user?.id]);

  const loadThread = useCallback(async (friendId: string) => {
    setThreadLoading(true);
    try {
      const response = await fetch(`/api/dm?with=${friendId}`, { cache: "no-store" });
      const payload = (await response.json()) as { messages?: DmMessage[]; error?: string };
      if (!response.ok) {
        setThreadError(payload.error ?? "Could not load messages.");
        return;
      }
      setThreadError(null);
      setMessages(payload.messages ?? []);
    } catch {
      setThreadError("Could not load messages.");
    } finally {
      setThreadLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!activeId) {
      setMessages([]);
      return;
    }
    void loadThread(activeId);
    const interval = setInterval(() => void loadThread(activeId), 4000);
    return () => clearInterval(interval);
  }, [activeId, loadThread]);

  useEffect(() => {
    const node = scrollRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages]);

  const act = async (action: string, personId: string, label: string) => {
    setBusyId(personId);
    try {
      const response = await fetch("/api/friends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, userId: personId }),
      });
      const payload = (await response.json()) as { error?: string; message?: string };
      if (!response.ok) {
        notify(payload.error ?? "Could not update that friend");
        return;
      }
      notify(payload.message ?? label);
      await load();
      if (action === "accept") {
        setActiveId(personId);
        await loadThread(personId);
      }
    } catch {
      notify("Could not update that friend");
    } finally {
      setBusyId(null);
    }
  };

  const send = async () => {
    const text = draft.trim();
    if (!text || !activeId || sending) return;
    setSending(true);
    const tempId = -Date.now();
    setMessages((previous) => [
      ...previous,
      { id: tempId, mine: true, body: text, read: false, createdAt: new Date().toISOString() },
    ]);
    setDraft("");
    try {
      const response = await fetch("/api/dm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: activeId, body: text }),
      });
      const payload = (await response.json()) as { message?: DmMessage; error?: string };
      if (!response.ok || !payload.message) {
        setMessages((previous) => previous.filter((message) => message.id !== tempId));
        setDraft(text);
        notify(payload.error ?? "Message did not send");
        return;
      }
      setMessages((previous) =>
        previous.map((message) => (message.id === tempId ? (payload.message as DmMessage) : message)),
      );
    } catch {
      setMessages((previous) => previous.filter((message) => message.id !== tempId));
      setDraft(text);
      notify("Message did not send");
    } finally {
      setSending(false);
    }
  };

  const activeFriend = data.friends.find((friend) => friend.id === activeId) ?? null;
  const filteredSuggestions = data.suggestions.filter((person) => {
    const term = search.trim().toLowerCase();
    if (!term) return true;
    return (
      person.username.toLowerCase().includes(term) ||
      person.displayName.toLowerCase().includes(term)
    );
  });

  if (accountLoading && loading) {
    return (
      <div className="glass flex items-center justify-center gap-2 rounded-2xl px-4 py-16 text-xs text-pumpkin-50/45">
        <Loader2 className="h-4 w-4 animate-spin" /> loading your friends
      </div>
    );
  }

  // The API is the source of truth: only show the sign-in prompt when the server
  // actually rejected the session, not while account state is still loading.
  if (!user && noSession) {
    return (
      <div className="glass rounded-2xl px-5 py-12 text-center">
        <Users className="mx-auto h-7 w-7 text-pumpkin-50/25" />
        <p className="mt-2 text-base font-bold text-pumpkin-50">Friends need an account</p>
        <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-pumpkin-50/45">
          Sign in (or create an account) to send friend requests and open private conversations.
          If you already made one, try restoring the saved session.
        </p>
        <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
          <Link href="/account" className="btn-accent inline-flex rounded-xl px-3.5 py-2 text-xs font-bold">
            Sign in or create account
          </Link>
          <button
            type="button"
            onClick={() => {
              setNoSession(false);
              void refresh(true).then(() => void load());
            }}
            className="btn-ghost inline-flex rounded-xl px-3 py-2 text-xs font-semibold text-pumpkin-50/75"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[330px_minmax(0,1fr)]">
      <div className="space-y-3">
        <section className="glass rounded-2xl p-3.5">
          <div className="flex items-center justify-between">
            <p className="section-label flex items-center gap-1.5">
              <UserPlus className="h-3 w-3" /> add a friend
            </p>
            <span className="text-[0.6rem] text-pumpkin-50/35">{data.suggestions.length} people</span>
          </div>
          <div className="mt-2 flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5">
            <Search className="h-3 w-3 text-pumpkin-50/35" />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search by name or @username"
              aria-label="Search people"
              className="w-full bg-transparent text-[0.72rem] text-pumpkin-50 outline-none placeholder:text-pumpkin-50/30"
            />
          </div>
          <ul className="mt-2 max-h-56 space-y-1 overflow-y-auto pr-0.5">
            {loading ? (
              <li className="py-3 text-center text-[0.68rem] text-pumpkin-50/35">loading…</li>
            ) : filteredSuggestions.length === 0 ? (
              <li className="py-3 text-center text-[0.66rem] leading-relaxed text-pumpkin-50/35">
                Nobody new right now. Everyone here is already a friend or has a request pending.
              </li>
            ) : (
              filteredSuggestions.map((person) => (
                <li key={person.id} className="flex items-center gap-2 rounded-lg px-1 py-1 hover:bg-white/[0.04]">
                  <AvatarView avatar={person.avatar} name={person.displayName} size={26} effect={person.effect} />
                  <button
                    type="button"
                    onClick={() => void act("request", person.id, "Request sent")}
                    disabled={busyId === person.id}
                    className="min-w-0 flex-1 text-left disabled:opacity-50"
                  >
                    <span className="block truncate text-[0.74rem] font-semibold text-pumpkin-50">
                      {person.displayName}
                    </span>
                    <span className="block truncate text-[0.6rem] text-pumpkin-50/40">
                      @{person.username}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void act("request", person.id, "Request sent")}
                    disabled={busyId === person.id}
                    className="rounded-md border border-[var(--accent-line)] bg-[var(--accent-soft)] px-2 py-1 text-[0.62rem] font-semibold text-pumpkin-50 disabled:opacity-50"
                  >
                    {busyId === person.id ? "…" : "Add"}
                  </button>
                </li>
              ))
            )}
          </ul>
        </section>

        {data.incoming.length > 0 ? (
          <section className="glass rounded-2xl p-3.5">
            <p className="section-label">requests · {data.incoming.length}</p>
            <ul className="mt-2 space-y-1.5">
              {data.incoming.map((person) => (
                <li key={person.id} className="rounded-xl border border-white/[0.07] bg-black/25 p-2">
                  <div className="flex items-center gap-2">
                    <AvatarView avatar={person.avatar} name={person.displayName} size={30} effect={person.effect} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[0.74rem] font-semibold text-pumpkin-50">
                        {person.displayName}
                      </p>
                      <p className="truncate text-[0.6rem] text-pumpkin-50/40">@{person.username}</p>
                    </div>
                  </div>
                  <div className="mt-2 flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => void act("accept", person.id, "Friend added")}
                      disabled={busyId === person.id}
                      className="btn-accent flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-[0.64rem] font-bold disabled:opacity-50"
                    >
                      <Check className="h-3 w-3" /> Accept
                    </button>
                    <button
                      type="button"
                      onClick={() => void act("decline", person.id, "Request declined")}
                      disabled={busyId === person.id}
                      className="btn-ghost flex items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-[0.64rem] font-semibold text-pumpkin-50/70 disabled:opacity-50"
                    >
                      <X className="h-3 w-3" /> Decline
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        <section className="glass rounded-2xl p-3.5">
          <p className="section-label flex items-center gap-1.5">
            <Users className="h-3 w-3" /> friends · {data.friends.length}
          </p>
          {data.friends.length === 0 ? (
            <p className="mt-2 text-[0.68rem] leading-relaxed text-pumpkin-50/40">
              No friends yet. Add someone above — once they accept you can message privately.
            </p>
          ) : (
            <ul className="mt-2 space-y-1">
              {data.friends.map((friend) => (
                <li key={friend.id}>
                  <div
                    className={`flex items-center gap-1 rounded-xl border px-1 ${
                      activeId === friend.id
                        ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                        : "border-transparent hover:bg-white/[0.04]"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setActiveId(friend.id)}
                      className="flex min-w-0 flex-1 items-center gap-2 py-1.5 pl-1 text-left"
                    >
                      <AvatarView avatar={friend.avatar} name={friend.displayName} size={30} effect={friend.effect} />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-1">
                          <span className="truncate text-[0.74rem] font-semibold text-pumpkin-50">
                            {friend.displayName}
                          </span>
                          {friend.unread > 0 ? (
                            <span className="rounded-full bg-[var(--accent)] px-1.5 text-[0.55rem] font-bold text-[#1b0c02]">
                              {friend.unread}
                            </span>
                          ) : null}
                        </span>
                        <span className="block truncate text-[0.6rem] text-pumpkin-50/40">
                          {friend.lastMessage
                            ? `${friend.lastMessage.mine ? "you: " : ""}${friend.lastMessage.body}`
                            : `@${friend.username}`}
                        </span>
                      </span>
                      {friend.lastMessage ? (
                        <span className="mr-1 shrink-0 text-[0.55rem] text-pumpkin-50/25">
                          {timeAgo(friend.lastMessage.at)}
                        </span>
                      ) : null}
                    </button>
                    <button
                      type="button"
                      onClick={() => void act("remove", friend.id, "Friend removed")}
                      aria-label={`Remove ${friend.displayName}`}
                      className="mr-1 text-pumpkin-50/25 transition hover:text-red-300"
                    >
                      <UserMinus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {data.outgoing.length > 0 ? (
          <section className="glass rounded-2xl p-3.5">
            <p className="section-label">sent requests</p>
            <ul className="mt-2 space-y-1">
              {data.outgoing.map((person) => (
                <li key={person.id} className="flex items-center gap-2 text-[0.7rem] text-pumpkin-50/55">
                  <AvatarView avatar={person.avatar} name={person.displayName} size={22} effect="none" ring={false} />
                  <span className="min-w-0 flex-1 truncate">{person.displayName}</span>
                  <button
                    type="button"
                    onClick={() => void act("cancel", person.id, "Request cancelled")}
                    className="text-[0.6rem] font-semibold text-pumpkin-50/40 hover:text-red-300"
                  >
                    cancel
                  </button>
                </li>
              ))}
            </ul>
          </section>
        ) : null}
      </div>

      <section className="glass flex min-h-[460px] flex-col overflow-hidden rounded-2xl">
        {activeFriend ? (
          <>
            <div className="flex items-center gap-2.5 border-b border-white/10 bg-black/30 px-3 py-2.5">
              <AvatarView
                avatar={activeFriend.avatar}
                name={activeFriend.displayName}
                size={34}
                effect={activeFriend.effect}
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-pumpkin-50">{activeFriend.displayName}</p>
                <p className="truncate text-[0.62rem] text-pumpkin-50/40">
                  @{activeFriend.username} · friends since{" "}
                  {new Date(activeFriend.since).toLocaleDateString()}
                </p>
              </div>
              <span className="flex items-center gap-1 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-2 py-1 text-[0.6rem] text-emerald-200/80">
                <MessageSquare className="h-2.5 w-2.5" /> private
              </span>
            </div>

            <div ref={scrollRef} className="flex-1 space-y-2 overflow-y-auto bg-black/20 px-3 py-3">
              {threadLoading && messages.length === 0 ? (
                <p className="flex items-center justify-center gap-1.5 py-6 text-[0.7rem] text-pumpkin-50/35">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" /> loading messages
                </p>
              ) : messages.length === 0 ? (
                <div className="grid h-full place-items-center text-center">
                  <div>
                    <p className="text-2xl">👋</p>
                    <p className="mt-1 text-sm font-semibold text-pumpkin-50/70">
                      Say hi to {activeFriend.displayName}
                    </p>
                    <p className="mt-1 text-[0.68rem] text-pumpkin-50/35">
                      Only the two of you can read this thread.
                    </p>
                  </div>
                </div>
              ) : (
                messages.map((message) => (
                  <div key={message.id} className={`flex ${message.mine ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[78%] ${message.mine ? "text-right" : ""}`}>
                      <p
                        className={`inline-block whitespace-pre-wrap break-words rounded-2xl border px-2.5 py-1.5 text-left text-[0.78rem] leading-relaxed ${
                          message.mine
                            ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                            : "border-white/[0.07] bg-white/[0.05] text-pumpkin-50/85"
                        }`}
                      >
                        {message.body}
                      </p>
                      <p className="mt-0.5 text-[0.55rem] text-pumpkin-50/25">
                        {new Date(message.createdAt).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                        {message.mine ? (message.read ? " · read" : " · sent") : ""}
                      </p>
                    </div>
                  </div>
                ))
              )}
              {threadError ? (
                <p className="rounded-lg border border-red-400/25 bg-red-500/10 px-2.5 py-1.5 text-[0.66rem] text-red-200/80">
                  {threadError}
                </p>
              ) : null}
            </div>

            <form
              onSubmit={(event) => {
                event.preventDefault();
                void send();
              }}
              className="flex items-center gap-2 border-t border-white/10 bg-black/30 px-3 py-2.5"
            >
              <input
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                placeholder={`Message ${activeFriend.displayName}…`}
                maxLength={800}
                aria-label="Direct message"
                className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/45 px-3 py-2.5 text-xs text-pumpkin-50 outline-none placeholder:text-pumpkin-50/30 focus:border-[var(--accent-line)]"
              />
              <button
                type="submit"
                disabled={sending || !draft.trim()}
                className="btn-accent flex items-center gap-1.5 rounded-xl px-3.5 py-2.5 text-xs font-bold disabled:opacity-50"
              >
                {sending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                Send
              </button>
            </form>
          </>
        ) : (
          <div className="grid flex-1 place-items-center px-4 py-12 text-center">
            <div>
              <Users className="mx-auto h-7 w-7 text-pumpkin-50/20" />
              <p className="mt-2 text-sm font-semibold text-pumpkin-50/70">Pick a friend to chat</p>
              <p className="mx-auto mt-1 max-w-sm text-[0.7rem] leading-relaxed text-pumpkin-50/40">
                Add someone from the list on the left. When they accept, their private thread opens
                here and stays synced while you browse.
              </p>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
