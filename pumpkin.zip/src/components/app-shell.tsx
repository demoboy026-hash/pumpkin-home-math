"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import {
  Bookmark,
  Check,
  ChevronRight,
  CircleUserRound,
  Compass,
  LayoutGrid,
  GraduationCap,
  Loader2,
  MessagesSquare,
  Settings2,
  ShieldAlert,
  LogIn,
  Sparkles,
  Tv,
  Users,
  Waypoints,
} from "lucide-react";
import { useSettings } from "@/components/providers";
import { PumpkinMark } from "@/components/pumpkin-mark";
import { ACTIVITIES } from "@/lib/activities";
import { CHAT_ROOMS } from "@/lib/types";
import { isSafeHttpUrl, prettyCombo } from "@/lib/settings";
import { BannerView } from "@/components/banner-view";
import { AvatarView } from "@/components/avatar-view";
import { OnlineCounter } from "@/components/online-counter";
import { useAccount } from "@/lib/account";

type NavItem = {
  href: string;
  label: string;
  hint: string;
  icon: typeof Compass;
  external?: boolean;
};

const MAIN_NAV: NavItem[] = [
  { href: "/", label: "Browser", hint: "Unblocked home", icon: Compass },
  { href: "/activities", label: "Activities", hint: `${ACTIVITIES.length} short breaks`, icon: LayoutGrid },
  { href: "/streamx", label: "StreamX", hint: "Live redirect", icon: Tv },
  { href: "/mirrors", label: "Mirrors", hint: "Clone this site", icon: Waypoints },
  { href: "/settings", label: "Settings", hint: "Tune your room", icon: Settings2 },
  { href: "/groups", label: "Groups", hint: "Private chats", icon: Users },
  { href: "/banners", label: "Banners", hint: "Header studio", icon: Sparkles },
  { href: "/account", label: "Account", hint: "Save across visits", icon: CircleUserRound },
];

function isActive(pathname: string, href: string) {
  if (href === "/") return pathname === "/" || pathname.startsWith("/browse") || pathname.startsWith("/m/");
  return pathname === href || pathname.startsWith(`${href}/`);
}

function QuickMirror() {
  const { notify } = useSettings();
  const [state, setState] = useState<{ status: "idle" | "working" | "created"; code?: string }>({
    status: "idle",
  });

  const make = async () => {
    setState({ status: "working" });
    try {
      const response = await fetch("/api/mirrors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ label: "Quick mirror", target: "/" }),
      });
      const data = (await response.json()) as { mirror?: { code: string }; error?: string };
      if (!response.ok || !data.mirror) {
        notify(data.error ?? "Could not make that mirror");
        setState({ status: "idle" });
        return;
      }
      try {
        await navigator.clipboard.writeText(`${window.location.origin}/m/${data.mirror.code}`);
        notify("Mirror link copied");
      } catch {
        notify("Mirror made — copy it from the Mirrors page");
      }
      setState({ status: "created", code: data.mirror.code });
    } catch {
      notify("Could not make that mirror");
      setState({ status: "idle" });
    }
  };

  return (
    <div className="flex items-center gap-1.5 rounded-xl border border-dashed border-[var(--accent-line)] bg-[var(--accent-soft)] px-2.5 py-2">
      <button
        type="button"
        onClick={() => void make()}
        disabled={state.status === "working"}
        className="flex min-w-0 flex-1 items-center gap-2 text-left disabled:opacity-60"
      >
        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-[var(--accent-line)] bg-black/30 text-[var(--accent)]">
          {state.status === "working" ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : state.status === "created" ? (
            <Check className="h-3.5 w-3.5" />
          ) : (
            <Waypoints className="h-3.5 w-3.5" />
          )}
        </span>
        <span className="min-w-0">
          <span className="block text-[0.74rem] font-semibold text-pumpkin-50">
            {state.status === "created" ? "Mirror ready" : "Quick mirror"}
          </span>
          <span className="hidden truncate text-[0.62rem] text-pumpkin-50/45 lg:block">
            {state.status === "created" && state.code
              ? `/m/${state.code} · copied`
              : "Auto-generate a new link"}
          </span>
        </span>
      </button>
      {state.status === "created" && state.code ? (
        <Link
          href={`/m/${state.code}`}
          className="shrink-0 rounded-md border border-white/10 bg-black/30 px-1.5 py-1 text-[0.6rem] font-semibold text-pumpkin-50/70 hover:text-pumpkin-50"
        >
          Open
        </Link>
      ) : null}
    </div>
  );
}

export function Sidebar() {
  const pathname = usePathname();
  const { user } = useAccount();
  return (
    <aside className="lg:sticky lg:top-4 lg:self-start">
      <div className="glass rounded-[22px] p-2.5">
        <div className="mb-2 hidden items-center gap-2 px-2.5 pt-1.5 lg:flex">
          <PumpkinMark className="h-5 w-5" />
          <span className="section-label">Navigate</span>
        </div>
        <nav aria-label="Main" className="flex gap-1.5 overflow-x-auto lg:flex-col lg:overflow-visible">
          {MAIN_NAV.map((item) => {
            const active = isActive(pathname, item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`group flex shrink-0 items-center gap-2.5 rounded-xl border px-3 py-2.5 text-sm transition lg:w-full ${
                  active
                    ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                    : "border-transparent text-pumpkin-50/70 hover:border-white/10 hover:bg-white/[0.05] hover:text-pumpkin-50"
                }`}
              >
                <span
                  className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg border transition ${
                    active
                      ? "border-[var(--accent-line)] bg-black/30 text-[var(--accent)]"
                      : "border-white/10 bg-black/25 text-pumpkin-50/60 group-hover:text-[var(--accent)]"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[0.82rem] font-semibold leading-tight">{item.label}</span>
                  <span className="hidden truncate text-[0.68rem] text-pumpkin-50/40 lg:block">
                    {item.href === "/account"
                      ? user
                        ? `@${user.username} · saved`
                        : "Sign in to save"
                      : item.hint}
                  </span>
                </span>
                <ChevronRight className="hidden h-3.5 w-3.5 shrink-0 text-pumpkin-50/25 lg:block" />
              </Link>
            );
          })}
        </nav>

        <div className="mt-2 border-t border-white/10 pt-2">
          <QuickMirror />
        </div>

        <div className="mt-2 border-t border-white/10 pt-2">
          <div className="mb-1.5 hidden items-center justify-between px-2.5 pt-1 lg:flex">
            <span className="section-label">Community</span>
            <span className="flex items-center gap-1 text-[0.62rem] font-medium text-emerald-300/80">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
              live
            </span>
          </div>
          <Link
            href="/friends"
            className={`mb-1.5 flex shrink-0 items-center gap-2.5 rounded-xl border px-3 py-2.5 text-sm transition lg:w-full ${
              isActive(pathname, "/friends")
                ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                : "border-transparent text-pumpkin-50/70 hover:border-white/10 hover:bg-white/[0.05] hover:text-pumpkin-50"
            }`}
          >
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-white/10 bg-black/30 text-[var(--accent)]">
              <Users className="h-4 w-4" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[0.82rem] font-semibold leading-tight">Friends</span>
              <span className="hidden truncate text-[0.68rem] text-pumpkin-50/40 lg:block">
                Requests &amp; private chat
              </span>
            </span>
            <ChevronRight className="hidden h-3.5 w-3.5 shrink-0 text-pumpkin-50/25 lg:block" />
          </Link>
          <Link
            href="/chat"
            className={`flex shrink-0 items-center gap-2.5 rounded-xl border px-3 py-2.5 text-sm transition lg:w-full ${
              isActive(pathname, "/chat")
                ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                : "border-transparent text-pumpkin-50/70 hover:border-white/10 hover:bg-white/[0.05] hover:text-pumpkin-50"
            }`}
          >
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-white/10 bg-black/30 text-[var(--accent)]">
              <MessagesSquare className="h-4 w-4" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[0.82rem] font-semibold leading-tight">Chatroom</span>
              <span className="hidden truncate text-[0.68rem] text-pumpkin-50/40 lg:block">
                {CHAT_ROOMS.length} rooms · always on
              </span>
            </span>
            <ChevronRight className="hidden h-3.5 w-3.5 shrink-0 text-pumpkin-50/25 lg:block" />
          </Link>
        </div>
      </div>

      <div className="mt-2 hidden items-center gap-2 rounded-xl border border-dashed border-white/10 px-3 py-2 text-[0.66rem] leading-snug text-pumpkin-50/35 lg:flex">
        <Bookmark className="h-3.5 w-3.5 shrink-0" />
        Bookmarks save to your pumpkin profile automatically.
      </div>
    </aside>
  );
}

function TopBar() {
  const { settings, ready } = useSettings();
  const { user, loading: accountLoading } = useAccount();
  const panic = () => {
    const dest = isSafeHttpUrl(settings.panicUrl) ? settings.panicUrl : "https://classroom.google.com/";
    window.location.replace(dest);
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-xl border border-[var(--accent-line)] bg-black/40 shadow-lg">
          {settings.disguiseEnabled ? (
            <GraduationCap className="h-5 w-5 text-sky-300" />
          ) : (
            <PumpkinMark className="h-5 w-5" />
          )}
        </span>
        <div className="leading-tight">
          <p className="text-[0.7rem] font-semibold uppercase tracking-[0.22em] text-pumpkin-50/45">
            private space
          </p>
          <p className="text-sm font-semibold text-pumpkin-50/90">
            {settings.disguiseEnabled ? settings.disguiseTitle : "pumpkin browser"}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <span className="hidden items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-2.5 py-1 text-[0.68rem] font-medium text-emerald-200 sm:flex">
          <Sparkles className="h-3 w-3" />
          {settings.disguiseEnabled ? "disguise active" : "all systems ready"}
        </span>
        <span className="hidden rounded-full border border-white/10 bg-black/30 px-2.5 py-1 font-mono text-[0.68rem] text-pumpkin-50/50 md:block">
          panic: {ready && settings.panicKey ? prettyCombo(settings.panicKey) : "not set"}
        </span>
        <Link
          href="/account"
          className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1.5 text-[0.7rem] font-semibold transition ${
            user
              ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50 hover:brightness-110"
              : "border-white/12 bg-white/[0.05] text-pumpkin-50/65 hover:text-pumpkin-50"
          }`}
        >
          {accountLoading ? (
            <CircleUserRound className="h-3.5 w-3.5 opacity-50" />
          ) : user ? (
            <AvatarView
              avatar={user.avatar}
              name={user.displayName}
              size={18}
              ring={false}
              effect={user.effect}
            />
          ) : (
            <LogIn className="h-3.5 w-3.5" />
          )}
          <span className="max-w-[110px] truncate">{user ? user.displayName : "Sign in"}</span>
        </Link>
        <button
          type="button"
          onClick={panic}
          className="group inline-flex items-center gap-1.5 rounded-full border border-red-400/30 bg-red-500/10 px-3 py-1.5 text-[0.7rem] font-semibold text-red-200 transition hover:border-red-400/60 hover:bg-red-500/20"
        >
          <ShieldAlert className="h-3.5 w-3.5" />
          Panic
        </button>
      </div>
    </div>
  );
}

function Hero() {
  const { settings, notify } = useSettings();

  return (
    <header className="relative mt-4 overflow-hidden rounded-[26px] border border-white/[0.07] bg-gradient-to-b from-black/55 via-black/20 to-transparent px-5 pb-6 pt-6 sm:px-8 sm:pb-8 sm:pt-8">
      <div
        className="animate-glow pointer-events-none absolute -right-16 -top-24 h-72 w-72 rounded-full blur-[90px]"
        style={{ background: "var(--accent-glow)" }}
      />
      <div className="pointer-events-none absolute -left-10 bottom-0 h-40 w-40 rounded-full bg-orange-500/20 blur-[70px]" />

      {settings.banner ? (
        <div className="-mx-5 -mt-6 mb-5 sm:-mx-8 sm:-mt-8 sm:mb-6">
          <BannerView banner={settings.banner} rounded={false} className="border-x-0 border-t-0" />
        </div>
      ) : null}

      <div className="relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="accent-chip rounded-full px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.2em]">
              unblocked
            </span>
            <span className="text-[0.66rem] font-medium uppercase tracking-[0.22em] text-pumpkin-50/40">
              browser · activities · chat
            </span>
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <h1 className="pumpkin-title select-none text-[clamp(3.6rem,15vw,11rem)]">pumpkin</h1>
            <OnlineCounter className="mb-2 self-end sm:mb-4" />
          </div>
          <p className="mt-4 max-w-xl text-sm leading-relaxed text-pumpkin-50/60 sm:text-[0.95rem]">
            A quiet corner of the internet that stays open. Browse in an embedded tab, launch the
            a short break activity, spin up a mirror, and talk in the rooms — all behind one little pumpkin.
          </p>
        </div>

        <div className="flex flex-col gap-2 lg:min-w-[260px]">
          <div className="grid grid-cols-3 gap-2">
            {[
              { k: "Activities", v: String(ACTIVITIES.length).padStart(2, "0") },
              { k: "Rooms", v: String(CHAT_ROOMS.length).padStart(2, "0") },
              { k: "Uptime", v: "24/7" },
            ].map((stat) => (
              <div key={stat.k} className="glass-soft rounded-xl px-2.5 py-2 text-center">
                <p className="text-base font-bold text-pumpkin-50">{stat.v}</p>
                <p className="text-[0.6rem] uppercase tracking-[0.14em] text-pumpkin-50/40">{stat.k}</p>
              </div>
            ))}
          </div>
          <Link
            href="/"
            className="btn-ghost flex items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-semibold text-pumpkin-50/85"
          >
            <span className="flex items-center gap-2">
              <Compass className="h-4 w-4 text-[var(--accent)]" />
              Open the browser
            </span>
            <ChevronRight className="h-4 w-4 text-pumpkin-50/35" />
          </Link>
          <Link
            href="/banners"
            className="flex items-center justify-between rounded-xl border border-white/[0.07] bg-black/25 px-3.5 py-2.5 text-xs font-semibold text-pumpkin-50/60 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50/90"
          >
            <span className="flex items-center gap-2">
              <Sparkles className="h-3.5 w-3.5 text-[var(--accent)]" />
              Customize the banner
            </span>
            <ChevronRight className="h-3.5 w-3.5 text-pumpkin-50/35" />
          </Link>
          <button
            type="button"
            onClick={() =>
              settings.disguiseEnabled
                ? notify("Disguise already active — tab looks like a class portal")
                : notify("Disguise is off. Turn it on in Settings.")
            }
            className="flex items-center justify-between rounded-xl border border-white/[0.07] bg-black/25 px-3.5 py-2.5 text-xs font-semibold text-pumpkin-50/60 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50/90"
          >
            <span className="flex items-center gap-2">
              <ShieldAlert className="h-3.5 w-3.5 text-pumpkin-50/45" />
              {settings.disguiseEnabled ? "Class-portal disguise on" : "Class-portal disguise off"}
            </span>
            <span className="font-mono text-[0.6rem] uppercase tracking-widest text-pumpkin-50/30">
              {settings.disguiseEnabled ? "on" : "off"}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative z-10 mx-auto w-full max-w-[1560px] px-3 pb-10 pt-4 sm:px-5">
      <TopBar />
      <Hero />
      <div className="mt-4 grid gap-4 lg:grid-cols-[248px_minmax(0,1fr)]">
        <Sidebar />
        <main className="min-w-0">{children}</main>
      </div>
      <footer className="mt-8 flex flex-col items-center justify-between gap-2 border-t border-white/10 pt-4 text-[0.68rem] text-pumpkin-50/35 sm:flex-row">
        <p className="flex items-center gap-2">
          <PumpkinMark className="h-3.5 w-3.5" />
          pumpkin · made for one person, shared with a few
        </p>
        <p>Your bookmarks, mirrors and messages live in this instance.</p>
      </footer>
    </div>
  );
}
