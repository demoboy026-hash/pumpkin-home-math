"use client";

import { useEffect, useRef, useState } from "react";
import {
  Check,
  Download,
  EyeOff,
  Home,
  Keyboard,
  Loader2,
  RotateCcw,
  Save,
  ShieldAlert,
  ShieldCheck,
  SlidersHorizontal,
} from "lucide-react";
import Link from "next/link";
import { useSettings } from "@/components/providers";
import { useAccount } from "@/lib/account";
import { ACCENTS, comboFromEvent, isSafeHttpUrl, prettyCombo } from "@/lib/settings";
import { DEFAULT_SETTINGS, type Settings } from "@/lib/types";
import { STREAMX_URL } from "@/lib/constants";

function Toggle({
  checked,
  onChange,
  label,
  hint,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  hint: string;
}) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/[0.07] bg-black/25 px-3 py-2.5">
      <div className="min-w-0">
        <p className="text-[0.78rem] font-semibold text-pumpkin-50">{label}</p>
        <p className="mt-0.5 text-[0.66rem] leading-relaxed text-pumpkin-50/40">{hint}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={() => onChange(!checked)}
        className={`relative mt-0.5 h-5 w-9 shrink-0 rounded-full border transition ${
          checked ? "border-[var(--accent-line)] bg-[var(--accent)]" : "border-white/15 bg-white/10"
        }`}
      >
        <span
          className={`absolute top-0.5 h-3.5 w-3.5 rounded-full bg-[#180d06] transition-all ${
            checked ? "left-[18px]" : "left-0.5 bg-white/60"
          }`}
        />
      </button>
    </div>
  );
}

export function SettingsPanel() {
  const { settings, ready, saving, save, notify } = useSettings();
  const { user } = useAccount();
  const [draft, setDraft] = useState<Settings>(settings);
  const [capturing, setCapturing] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const keyBoxRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!ready || hydrated) return;
    setDraft(settings);
    setHydrated(true);
  }, [ready, settings, hydrated]);

  useEffect(() => {
    document.documentElement.dataset.accent = draft.accent;
    return () => {
      document.documentElement.dataset.accent = settings.accent;
    };
  }, [draft.accent, settings.accent]);

  const update = <K extends keyof Settings>(key: K, value: Settings[K]) =>
    setDraft((previous) => ({ ...previous, [key]: value }));

  const dirty = JSON.stringify(draft) !== JSON.stringify(settings);
  const panicUrlValid = isSafeHttpUrl(draft.panicUrl);

  const onSave = async () => {
    if (!panicUrlValid) {
      notify("The panic redirect needs a full http(s) link");
      return;
    }
    await save(draft);
  };

  return (
    <div className="space-y-4">
      <section className="glass rounded-[26px] px-5 py-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="section-label">settings · experience</p>
            <h2 className="mt-1 text-2xl font-black tracking-tight text-pumpkin-50 sm:text-3xl">
              Make pumpkin yours
            </h2>
            <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-pumpkin-50/50">
              Panic key, disguise, colors and browser defaults. Saved to this profile in the database
              and mirrored into this device.
            </p>
          </div>
          <button
            type="button"
            onClick={onSave}
            disabled={saving || !ready}
            className="btn-accent flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save changes
          </button>
        </div>
      </section>

      <p className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/[0.07] bg-black/25 px-3.5 py-2.5 text-[0.7rem] text-pumpkin-50/50">
        <span className="flex items-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5 text-[var(--accent)]" />
          {user
            ? `Saved to your account @${user.username} — this setup loads on every visit.`
            : "Saving on this browser only."}
        </span>
        <Link href="/account" className="font-semibold text-[var(--accent)] hover:underline">
          {user ? "Manage account" : "Create an account to keep it"}
        </Link>
      </p>

      <div className="grid gap-4 xl:grid-cols-2">
        <section className="glass rounded-2xl p-4">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-black/30 text-[var(--accent)]">
              <ShieldAlert className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-pumpkin-50">Panic key</h3>
              <p className="text-[0.66rem] text-pumpkin-50/40">One keystroke, gone.</p>
            </div>
          </div>

          <div className="mt-3 space-y-3">
            <div>
              <span className="section-label">step 1 — record the key bind</span>
              <input
                ref={keyBoxRef}
                readOnly
                value={capturing ? "Press any key combination…" : prettyCombo(draft.panicKey)}
                onFocus={() => setCapturing(true)}
                onBlur={() => setCapturing(false)}
                onKeyDown={(event) => {
                  event.preventDefault();
                  if (event.key === "Backspace" || event.key === "Delete") {
                    update("panicKey", "");
                    notify("Panic key cleared");
                    return;
                  }
                  const combo = comboFromEvent(event);
                  if (!combo) return;
                  update("panicKey", combo);
                  setCapturing(false);
                  keyBoxRef.current?.blur();
                  notify(`Panic key set to ${prettyCombo(combo)}`);
                }}
                placeholder="Click, then press your key"
                aria-label="Panic key bind"
                className={`field mt-1.5 cursor-pointer text-center font-mono text-sm font-bold tracking-wide ${
                  capturing ? "border-[var(--accent-line)] text-[var(--accent)]" : ""
                }`}
              />
              <p className="mt-1 flex items-center gap-1 text-[0.62rem] text-pumpkin-50/35">
                <Keyboard className="h-3 w-3" /> Click the box and press the combo. Backspace clears.
              </p>
            </div>

            <div>
              <span className="section-label">step 2 — where it sends you</span>
              <input
                value={draft.panicUrl}
                onChange={(event) => update("panicUrl", event.target.value)}
                placeholder="https://classroom.google.com/"
                aria-label="Panic redirect link"
                className={`field mt-1.5 font-mono text-[0.78rem] ${
                  panicUrlValid ? "" : "border-red-400/50"
                }`}
              />
              <div className="mt-1.5 flex flex-wrap gap-1">
                {[
                  { label: "Classroom", url: "https://classroom.google.com/" },
                  { label: "Canvas", url: "https://canvas.instructure.com/" },
                  { label: "Khan", url: "https://www.khanacademy.org/" },
                  { label: "StreamX", url: STREAMX_URL },
                ].map((preset) => (
                  <button
                    key={preset.url}
                    type="button"
                    onClick={() => update("panicUrl", preset.url)}
                    className="rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[0.62rem] text-pumpkin-50/55 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            <Toggle
              checked={draft.panicEnabled}
              onChange={(value) => update("panicEnabled", value)}
              label="Arm the panic key everywhere"
              hint="Listens on every page, even while the embedded browser is open."
            />

            <button
              type="button"
              onClick={() => {
                if (!panicUrlValid) {
                  notify("Add a valid link first");
                  return;
                }
                window.open(draft.panicUrl, "_blank", "noopener,noreferrer");
                notify("Opened your panic destination in a test tab");
              }}
              className="btn-ghost w-full rounded-xl px-3 py-2 text-[0.72rem] font-semibold text-pumpkin-50/75"
            >
              Test panic destination
            </button>
          </div>
        </section>

        <section className="glass rounded-2xl p-4">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-black/30 text-[var(--accent)]">
              <EyeOff className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-pumpkin-50">Educational disguise</h3>
              <p className="text-[0.66rem] text-pumpkin-50/40">Tab icon and name cover story.</p>
            </div>
          </div>

          <div className="mt-3 space-y-3">
            <Toggle
              checked={draft.disguiseEnabled}
              onChange={(value) => update("disguiseEnabled", value)}
              label="Hide the pumpkin icon & name"
              hint="Swaps the favicon and browser tab title for a class-portal look."
            />

            <label className="block">
              <span className="section-label">disguised tab name</span>
              <input
                value={draft.disguiseTitle}
                onChange={(event) => update("disguiseTitle", event.target.value)}
                maxLength={120}
                className="field mt-1.5"
                aria-label="Disguised tab name"
              />
            </label>

            <div className="flex flex-wrap gap-1">
              {["Canvas — Course Dashboard", "Google Classroom", "Khan Academy | Math", "Study Portal"].map(
                (preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => update("disguiseTitle", preset)}
                    className="rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[0.62rem] text-pumpkin-50/55 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50"
                  >
                    {preset}
                  </button>
                ),
              )}
            </div>

            <div className="rounded-xl border border-white/[0.07] bg-black/25 p-3">
              <p className="section-label mb-2">tab preview</p>
              <div className="flex items-center gap-2 rounded-lg border border-white/10 bg-[#1b1b1f] px-2.5 py-1.5">
                <span className="grid h-4 w-4 place-items-center rounded-sm bg-[#1d4ed8] text-[0.5rem] font-black text-white">
                  🎓
                </span>
                <span className="truncate text-[0.7rem] text-white/80">
                  {draft.disguiseEnabled ? draft.disguiseTitle || "Canvas — Course Dashboard" : "pumpkin — your private browser"}
                </span>
              </div>
              <p className="mt-1.5 text-[0.6rem] leading-relaxed text-pumpkin-50/35">
                The preview updates immediately. Press save so the disguise is remembered.
              </p>
            </div>
          </div>
        </section>

        <section className="glass rounded-2xl p-4">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-black/30 text-[var(--accent)]">
              <SlidersHorizontal className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-pumpkin-50">Appearance</h3>
              <p className="text-[0.66rem] text-pumpkin-50/40">Set the glow of the room.</p>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2">
            {ACCENTS.map((accent) => (
              <button
                key={accent.id}
                type="button"
                onClick={() => update("accent", accent.id)}
                className={`flex items-center gap-2 rounded-xl border px-2.5 py-2 text-left transition ${
                  draft.accent === accent.id
                    ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                    : "border-white/[0.07] bg-black/25 hover:border-white/15"
                }`}
              >
                <span className="h-6 w-6 shrink-0 rounded-full border border-white/20" style={{ background: accent.swatch }} />
                <span className="min-w-0">
                  <span className="flex items-center gap-1 text-[0.74rem] font-semibold text-pumpkin-50">
                    {accent.name}
                    {draft.accent === accent.id ? <Check className="h-3 w-3 text-[var(--accent)]" /> : null}
                  </span>
                  <span className="block truncate text-[0.6rem] text-pumpkin-50/40">{accent.hint}</span>
                </span>
              </button>
            ))}
          </div>
          <p className="mt-2 text-[0.62rem] text-pumpkin-50/35">
            Accent colors drive buttons, chips and the glow behind the pumpkin title.
          </p>
        </section>

        <section className="glass rounded-2xl p-4">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-black/30 text-[var(--accent)]">
              <Home className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-pumpkin-50">Browser defaults</h3>
              <p className="text-[0.66rem] text-pumpkin-50/40">How a new session begins.</p>
            </div>
          </div>

          <div className="mt-3 space-y-3">
            <label className="block">
              <span className="section-label">start page link (optional)</span>
              <input
                value={draft.homepage}
                onChange={(event) => update("homepage", event.target.value)}
                placeholder="Leave blank for the pumpkin start page"
                className="field mt-1.5 font-mono text-[0.76rem]"
                aria-label="Browser homepage"
              />
            </label>

            <Toggle
              checked={draft.proxyDefault}
              onChange={(value) => update("proxyDefault", value)}
              label="Shield on by default"
              hint="New tabs route pages through pumpkin when a site blocks embedding."
            />
            <Toggle
              checked={draft.openExternalNewTab}
              onChange={(value) => update("openExternalNewTab", value)}
              label="Open external links in a new tab"
              hint="Keeps the embedded window in place when you pop something out."
            />

            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setDraft(DEFAULT_SETTINGS);
                  notify("Draft reset — press save to keep it");
                }}
                className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.68rem] font-semibold text-pumpkin-50/70"
              >
                <RotateCcw className="h-3 w-3" /> Reset draft
              </button>
              <button
                type="button"
                onClick={() => {
                  const blob = new Blob([JSON.stringify(draft, null, 2)], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const anchor = document.createElement("a");
                  anchor.href = url;
                  anchor.download = "pumpkin-settings.json";
                  anchor.click();
                  URL.revokeObjectURL(url);
                  notify("Settings exported");
                }}
                className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.68rem] font-semibold text-pumpkin-50/70"
              >
                <Download className="h-3 w-3" /> Export JSON
              </button>
            </div>
          </div>
        </section>
      </div>

      <div className="glass sticky bottom-3 flex flex-wrap items-center justify-between gap-2 rounded-2xl px-4 py-3">
        <p className="text-[0.7rem] text-pumpkin-50/50">
          {dirty ? "You have unsaved changes." : "Everything here is saved."}
        </p>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setDraft(settings)}
            disabled={!dirty}
            className="btn-ghost rounded-xl px-3 py-2 text-[0.72rem] font-semibold text-pumpkin-50/75 disabled:opacity-40"
          >
            Discard
          </button>
          <button
            type="button"
            onClick={onSave}
            disabled={saving || !dirty}
            className="btn-accent flex items-center gap-2 rounded-xl px-3.5 py-2 text-[0.72rem] font-bold disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
