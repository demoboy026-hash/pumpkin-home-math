"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { Check, Loader2, Sparkles, Trash2, Upload } from "lucide-react";
import { AvatarView } from "@/components/avatar-view";
import { useSettings } from "@/components/providers";
import { useAccount } from "@/lib/account";
import { AVATAR_EFFECTS, AVATAR_PRESETS, parseAvatar, parseEffect, type AvatarConfig } from "@/lib/avatars";
import { IMAGE_TYPES, MEDIA_LIMITS, VIDEO_TYPES } from "@/lib/banners";

type UploadRow = { id: string; mime: string; kind: "video" | "image"; name: string; bytes: number };

export function AvatarPicker() {
  const { user, setUser, loading } = useAccount();
  const { notify } = useSettings();
  const [config, setConfig] = useState<AvatarConfig>({ kind: "preset", presetId: AVATAR_PRESETS[0].id });
  const [effect, setEffect] = useState("glow");
  const [uploads, setUploads] = useState<UploadRow[]>([]);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const loadUploads = useCallback(async () => {
    try {
      const response = await fetch("/api/media", { cache: "no-store" });
      const data = (await response.json()) as { uploads?: UploadRow[] };
      if (data.uploads) setUploads(data.uploads);
    } catch {
      // no uploads available
    }
  }, []);

  useEffect(() => {
    if (user?.avatar) setConfig(parseAvatar(user.avatar));
    if (user?.effect) setEffect(parseEffect(user.effect));
  }, [user?.avatar, user?.effect]);

  useEffect(() => {
    if (user) void loadUploads();
  }, [loadUploads, user]);

  const persist = async (nextAvatar?: AvatarConfig, nextEffect?: string) => {
    setSaving(true);
    if (nextAvatar) setConfig(nextAvatar);
    if (nextEffect) setEffect(nextEffect);
    try {
      const response = await fetch("/api/auth/avatar", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          avatar: nextAvatar ?? config,
          effect: nextEffect ?? effect,
        }),
      });
      const data = (await response.json()) as {
        avatar?: AvatarConfig;
        effect?: string;
        error?: string;
      };
      if (!response.ok || !data.avatar) {
        notify(data.error ?? "Could not save that avatar");
        return;
      }
      setConfig(data.avatar);
      setEffect(parseEffect(data.effect));
      if (user) {
        setUser({
          ...user,
          avatar: JSON.stringify(data.avatar),
          effect: parseEffect(data.effect),
        });
      }
      notify(nextEffect ? "Profile effect updated" : "Profile picture updated");
    } catch {
      notify("Could not save that avatar");
    } finally {
      setSaving(false);
    }
  };

  const uploadFile = async (file: File) => {
    setUploading(true);
    try {
      const body = new FormData();
      body.append("file", file);
      const response = await fetch("/api/media", { method: "POST", body });
      const data = (await response.json()) as { media?: UploadRow; error?: string };
      if (!response.ok || !data.media) {
        notify(data.error ?? "Upload failed");
        return;
      }
      setUploads((previous) => [data.media as UploadRow, ...previous]);
      await persist({
        kind: "media",
        mediaId: data.media.id,
        animated: data.media.kind === "video" || data.media.mime === "image/gif",
      });
    } catch {
      notify("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const removeUpload = async (row: UploadRow) => {
    setUploads((previous) => previous.filter((item) => item.id !== row.id));
    if (config.kind === "media" && config.mediaId === row.id) {
      await persist({ kind: "preset", presetId: AVATAR_PRESETS[0].id });
    }
    try {
      await fetch(`/api/media?id=${row.id}`, { method: "DELETE" });
      notify("Upload removed");
    } catch {
      notify("Could not remove that upload");
    }
  };

  if (loading) {
    return (
      <div className="glass flex items-center justify-center gap-2 rounded-2xl px-4 py-10 text-xs text-pumpkin-50/45">
        <Loader2 className="h-4 w-4 animate-spin" /> loading your profile picture
      </div>
    );
  }

  if (!user) {
    return (
      <div className="glass rounded-2xl p-4">
        <p className="section-label flex items-center gap-1.5">
          <Sparkles className="h-3 w-3" /> profile picture
        </p>
        <p className="mt-2 text-[0.74rem] leading-relaxed text-pumpkin-50/50">
          Animated profile pictures are stored on your account. Create one to pick a moving avatar and
          have it follow you into the chat rooms.
        </p>
        <Link
          href="/account"
          className="btn-accent mt-3 inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold"
        >
          Create an account
        </Link>
      </div>
    );
  }

  return (
    <div className="glass rounded-2xl p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <AvatarView avatar={config} name={user.displayName} size={56} effect={effect} />
          <div>
            <p className="text-sm font-bold text-pumpkin-50">Animated profile picture</p>
            <p className="text-[0.66rem] text-pumpkin-50/45">
              {config.kind === "preset"
                ? "Preset animation"
                : config.kind === "media"
                  ? "Your uploaded media"
                  : "Your initials"}{" "}
              · {effect} effect
            </p>
          </div>
        </div>
        {saving ? (
          <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-black/30 px-2 py-1 text-[0.62rem] text-pumpkin-50/50">
            <Loader2 className="h-3 w-3 animate-spin" /> saving
          </span>
        ) : (
          <span className="flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-2 py-1 text-[0.62rem] text-emerald-200/80">
            <Check className="h-3 w-3" /> synced
          </span>
        )}
      </div>

      <p className="section-label mt-4">preset animations</p>
      <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-5">
        {AVATAR_PRESETS.map((preset) => {
          const active = config.kind === "preset" && config.presetId === preset.id;
          return (
            <button
              key={preset.id}
              type="button"
              onClick={() => void persist({ kind: "preset", presetId: preset.id })}
              className={`group flex flex-col items-center gap-1.5 rounded-xl border px-1.5 py-2 transition ${
                active
                  ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                  : "border-white/[0.07] bg-black/25 hover:border-white/20"
              }`}
            >
              <AvatarView avatar={{ kind: "preset", presetId: preset.id }} name={user.displayName} size={40} ring={false} />
              <span className="w-full truncate text-center text-[0.6rem] font-semibold text-pumpkin-50/70">
                {preset.name}
              </span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => void persist({ kind: "initials" })}
          className={`flex flex-col items-center gap-1.5 rounded-xl border px-1.5 py-2 transition ${
            config.kind === "initials"
              ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
              : "border-white/[0.07] bg-black/25 hover:border-white/20"
          }`}
        >
          <span className="grid h-10 w-10 place-items-center rounded-full border border-white/10 bg-white/[0.05] text-sm font-black text-pumpkin-50">
            {user.displayName.slice(0, 1).toUpperCase()}
          </span>
          <span className="text-[0.6rem] font-semibold text-pumpkin-50/70">Initials</span>
        </button>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <p className="section-label">profile picture effects</p>
        <span className="text-[0.6rem] text-pumpkin-50/35">animated around your picture</span>
      </div>
      <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-5">
        {AVATAR_EFFECTS.map((item) => {
          const active = effect === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => void persist(undefined, item.id)}
              title={item.description}
              className={`flex flex-col items-center gap-1 rounded-xl border px-1 py-2 transition ${
                active
                  ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                  : "border-white/[0.07] bg-black/25 hover:border-white/20"
              }`}
            >
              <span className="py-1.5">
                <AvatarView avatar={config} name={user.displayName} size={34} ring={false} effect={item.id} />
              </span>
              <span className="w-full truncate text-center text-[0.58rem] font-semibold text-pumpkin-50/70">
                {item.name}
              </span>
            </button>
          );
        })}
      </div>

      <p className="section-label mt-4">your animated uploads</p>
      <div className="mt-2 flex flex-wrap items-center gap-2">
        {uploads.map((row) => {
          const active = config.kind === "media" && config.mediaId === row.id;
          return (
            <div
              key={row.id}
              className={`group relative rounded-full border p-0.5 ${
                active ? "border-[var(--accent-line)]" : "border-white/10"
              }`}
            >
              <button
                type="button"
                onClick={() =>
                  void persist({
                    kind: "media",
                    mediaId: row.id,
                    animated: row.kind === "video" || row.mime === "image/gif",
                  })
                }
                title={row.name}
              >
                <AvatarView
                  avatar={{
                    kind: "media",
                    mediaId: row.id,
                    animated: row.kind === "video" || row.mime === "image/gif",
                  }}
                  name={user.displayName}
                  size={44}
                  ring={false}
                />
              </button>
              <button
                type="button"
                onClick={() => void removeUpload(row)}
                aria-label={`Delete ${row.name}`}
                className="absolute -right-1 -top-1 hidden h-4 w-4 place-items-center rounded-full bg-red-500 text-white group-hover:grid"
              >
                <Trash2 className="h-2.5 w-2.5" />
              </button>
            </div>
          );
        })}

        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="flex h-12 items-center gap-1.5 rounded-full border border-dashed border-white/20 px-3 text-[0.66rem] font-semibold text-pumpkin-50/55 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50 disabled:opacity-50"
        >
          {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
          {uploading ? "Uploading" : "Upload GIF / video"}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept={[...VIDEO_TYPES, ...IMAGE_TYPES].join(",")}
          className="hidden"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void uploadFile(file);
            event.target.value = "";
          }}
        />
      </div>
      <p className="mt-2 text-[0.6rem] leading-relaxed text-pumpkin-50/35">
        GIFs animate automatically. Videos loop muted, up to{" "}
        {Math.round(MEDIA_LIMITS.video / (1024 * 1024))}MB. Your picture appears in the header, on your
        account card and beside your chat messages.
      </p>
    </div>
  );
}
