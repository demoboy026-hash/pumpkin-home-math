"use client";

import { bannerHeightClass, presetById, type Banner, type Preset } from "@/lib/banners";

function Scene({ preset }: { preset: Preset }) {
  const { palette } = preset;
  const scene = "scene" in preset ? preset.scene : null;
  const animation = "animation" in preset ? preset.animation : "none";

  return (
    <svg
      viewBox="0 0 1200 240"
      preserveAspectRatio="xMidYMid slice"
      className="absolute inset-0 h-full w-full"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`sky-${preset.id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={palette.sky} />
          <stop offset="100%" stopColor={palette.hill} />
        </linearGradient>
        <radialGradient id={`glow-${preset.id}`}>
          <stop offset="0%" stopColor={palette.glow} stopOpacity="0.85" />
          <stop offset="100%" stopColor={palette.glow} stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`drip-${preset.id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={palette.glow} />
          <stop offset="45%" stopColor={palette.accent} />
          <stop offset="100%" stopColor={palette.sky} />
        </linearGradient>
      </defs>

      <rect width="1200" height="240" fill={`url(#sky-${preset.id})`} />

      {scene === null ? (
        <>
          <rect width="1200" height="240" fill={`url(#drip-${preset.id})`} opacity="0.6" />
          <circle cx="980" cy="70" r="150" fill={`url(#glow-${preset.id})`} />
          {animation !== "none" ? (
            <g style={{ animation, transformOrigin: "600px 240px" }}>
              <path d="M0 200 Q300 150 600 195 T1200 185 V240 H0 Z" fill={palette.hill} opacity="0.85" />
            </g>
          ) : null}
          <path d="M0 214 Q300 178 600 210 T1200 202 V240 H0 Z" fill={palette.sky} opacity="0.8" />
        </>
      ) : null}

      {scene === "haunted-hills" ? (
        <>
          <circle cx="930" cy="80" r="140" fill={`url(#glow-${preset.id})`} />
          <circle cx="930" cy="80" r="46" fill={palette.accent} opacity="0.9">
            <animate attributeName="r" values="44;50;44" dur="6s" repeatCount="indefinite" />
          </circle>
          <g opacity="0.5">
            <path d="M0 200 Q220 140 470 190 T1200 170 V240 H0 Z" fill={palette.hill} />
            <path d="M0 215 Q280 178 620 208 T1200 196 V240 H0 Z" fill="#080510" />
          </g>
          <g opacity="0.25" fill="#fff">
            <ellipse cx="200" cy="150" rx="220" ry="18">
              <animate attributeName="cx" values="120;320;120" dur="18s" repeatCount="indefinite" />
            </ellipse>
            <ellipse cx="800" cy="120" rx="180" ry="14">
              <animate attributeName="cx" values="880;640;880" dur="22s" repeatCount="indefinite" />
            </ellipse>
          </g>
          <g fill={palette.hill}>
            <path d="M150 214 l16 -34 l16 34 z" />
            <path d="M1050 210 l14 -30 l14 30 z" />
          </g>
          <g fill={palette.glow} opacity="0.9">
            <circle cx="166" cy="192" r="7" />
            <circle cx="1064" cy="190" r="6" />
          </g>
        </>
      ) : null}

      {scene === "moon-bats" ? (
        <>
          <circle cx="600" cy="110" r="170" fill={`url(#glow-${preset.id})`} opacity="0.7" />
          <circle cx="600" cy="96" r="62" fill="#f7f3ff" opacity="0.92" />
          <circle cx="576" cy="82" r="10" fill="#d8cdea" opacity="0.7" />
          <circle cx="622" cy="112" r="7" fill="#d8cdea" opacity="0.6" />
          {[0, 1, 2, 3, 4].map((index) => (
            <g key={index} fill={palette.accent} opacity={0.65 - index * 0.08}>
              <path d="M0 0 l22 -8 l-6 12 l12 -2 l-28 22 l8 -16 z">
                <animateTransform
                  attributeName="transform"
                  type="translate"
                  values={`-60 ${60 + index * 26};1260 ${28 + index * 30}`}
                  dur={`${16 + index * 4}s`}
                  repeatCount="indefinite"
                />
              </path>
            </g>
          ))}
          <path d="M0 218 Q320 176 640 212 T1200 196 V240 H0 Z" fill={palette.hill} />
        </>
      ) : null}

      {scene === "candy-swirl" ? (
        <>
          <rect width="1200" height="240" fill={`url(#drip-${preset.id})`} opacity="0.55" />
          <g opacity="0.6">
            {Array.from({ length: 10 }).map((_, index) => (
              <rect
                key={index}
                x={index * 140 - 200}
                y={-60}
                width="70"
                height="420"
                fill={index % 2 === 0 ? palette.glow : palette.accent}
                opacity="0.35"
                transform="rotate(18 600 120)"
              >
                <animateTransform
                  attributeName="transform"
                  type="translate"
                  additive="sum"
                  values="0 0;140 0;0 0"
                  dur="14s"
                  repeatCount="indefinite"
                />
              </rect>
            ))}
          </g>
          <circle cx="980" cy="90" r="150" fill={`url(#glow-${preset.id})`} />
        </>
      ) : null}

      {scene === "ember-rain" ? (
        <>
          <circle cx="240" cy="60" r="170" fill={`url(#glow-${preset.id})`} opacity="0.7" />
          {Array.from({ length: 26 }).map((_, index) => {
            const x = (index * 47 + 20) % 1200;
            const radius = 1.6 + (index % 4) * 0.9;
            return (
              <circle key={index} cx={x} cy={-20} r={radius} fill={index % 3 === 0 ? palette.accent : palette.glow}>
                <animate
                  attributeName="cy"
                  values="-20;250"
                  dur={`${6 + (index % 7)}s`}
                  begin={`${(index % 9) * 0.7}s`}
                  repeatCount="indefinite"
                />
                <animate
                  attributeName="opacity"
                  values="0;0.9;0"
                  dur={`${6 + (index % 7)}s`}
                  begin={`${(index % 9) * 0.7}s`}
                  repeatCount="indefinite"
                />
              </circle>
            );
          })}
          <path d="M0 205 Q400 160 760 200 T1200 186 V240 H0 Z" fill={palette.hill} opacity="0.9" />
        </>
      ) : null}

      {scene === "ghost-fog" ? (
        <>
          <circle cx="880" cy="70" r="160" fill={`url(#glow-${preset.id})`} opacity="0.55" />
          {[0, 1, 2].map((index) => (
            <g key={index} opacity={0.24 - index * 0.05} fill={palette.accent}>
              {[0, 1, 2, 3, 4, 5].map((lobe) => (
                <circle key={lobe} cx={lobe * 210 + index * 70} cy={170 + index * 18} r={64 - index * 6}>
                  <animate
                    attributeName="cx"
                    values={`${lobe * 210 + index * 70};${lobe * 210 + index * 70 + 160};${lobe * 210 + index * 70}`}
                    dur={`${20 + index * 6}s`}
                    repeatCount="indefinite"
                  />
                </circle>
              ))}
            </g>
          ))}
          <path d="M0 222 Q300 190 640 216 T1200 204 V240 H0 Z" fill={palette.hill} />
        </>
      ) : null}

      {scene === "pumpkin-patch" ? (
        <>
          <g fill={palette.accent} opacity="0.16">
            {Array.from({ length: 40 }).map((_, index) => (
              <circle key={index} cx={(index * 97) % 1200} cy={(index * 61) % 150} r={1.4}>
                <animate
                  attributeName="opacity"
                  values="0.2;0.9;0.2"
                  dur={`${3 + (index % 5)}s`}
                  repeatCount="indefinite"
                />
              </circle>
            ))}
          </g>
          <circle cx="900" cy="70" r="150" fill={`url(#glow-${preset.id})`} opacity="0.6" />
          {[
            { x: 150, r: 34 },
            { x: 260, r: 24 },
            { x: 420, r: 30 },
            { x: 720, r: 26 },
            { x: 1010, r: 36 },
            { x: 1120, r: 22 },
          ].map((pumpkin, index) => (
            <g key={pumpkin.x} transform={`translate(${pumpkin.x} 216)`}>
              <ellipse cx="0" cy="0" rx={pumpkin.r} ry={pumpkin.r * 0.86} fill={palette.glow} opacity={0.85}>
                <animate
                  attributeName="opacity"
                  values="0.65;1;0.65"
                  dur={`${4 + index}s`}
                  repeatCount="indefinite"
                />
              </ellipse>
              <rect x="-3" y={-pumpkin.r - 10} width="6" height="10" rx="2" fill="#5b8f34" />
              <path
                d={`M ${-pumpkin.r * 0.5} ${-pumpkin.r * 0.1} l ${pumpkin.r * 0.34} 0 l ${-pumpkin.r * 0.16} ${pumpkin.r * 0.3} z`}
                fill={palette.sky}
              />
              <path
                d={`M ${pumpkin.r * 0.5} ${-pumpkin.r * 0.1} l ${-pumpkin.r * 0.34} 0 l ${pumpkin.r * 0.16} ${pumpkin.r * 0.3} z`}
                fill={palette.sky}
              />
            </g>
          ))}
          <path d="M0 218 Q380 196 720 214 T1200 206 V240 H0 Z" fill={palette.hill} />
        </>
      ) : null}

    </svg>
  );
}

export function BannerView({
  banner,
  className = "",
  rounded = true,
}: {
  banner: Banner;
  className?: string;
  rounded?: boolean;
}) {
  const preset = presetById(banner.presetId);
  const src =
    banner.kind === "upload" && banner.mediaId
      ? `/api/media/${banner.mediaId}`
      : banner.kind === "url" && banner.url
        ? banner.url
        : null;

  return (
    <div
      className={`relative w-full overflow-hidden border border-white/10 ${
        rounded ? "rounded-xl" : ""
      } ${bannerHeightClass(banner.height)} ${className}`}
      style={{ background: preset.palette.sky }}
    >
      {src ? (
        banner.kind === "upload" && banner.animated === false ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={src}
            alt="Custom pumpkin banner"
            className={`absolute inset-0 h-full w-full ${banner.fit === "contain" ? "object-contain" : "object-cover"}`}
          />
        ) : (
          <video
            src={src}
            autoPlay={banner.animated !== false}
            loop
            muted
            playsInline
            controls={banner.animated === false}
            className={`absolute inset-0 h-full w-full ${banner.fit === "contain" ? "object-contain" : "object-cover"}`}
          />
        )
      ) : (
        banner.kind === "url" && banner.url ? (
          <div className="absolute inset-0 grid place-items-center bg-black/60 px-4 text-center text-xs text-pumpkin-50/60">
            This banner link could not be previewed.
          </div>
        ) : (
          <Scene preset={preset} />
        )
      )}

      <div
        className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent"
        style={{ opacity: 0.55 + banner.overlay * 0.45 }}
      />

      {(banner.title || banner.subtitle) && (
        <div className="absolute inset-x-0 bottom-0 px-4 pb-3 pt-8 sm:px-6">
          {banner.title ? (
            <p className="truncate text-lg font-black tracking-tight text-white drop-shadow sm:text-2xl">
              {banner.title}
            </p>
          ) : null}
          {banner.subtitle ? (
            <p className="truncate text-[0.72rem] text-white/75 drop-shadow sm:text-xs">
              {banner.subtitle}
            </p>
          ) : null}
        </div>
      )}
    </div>
  );
}
