"use client";

import { avatarPreset, effectById, initialsFor, parseAvatar, parseEffect, type AvatarConfig } from "@/lib/avatars";

function PresetArt({ presetId, glow, ink }: { presetId: string; glow: string; ink: string }) {
  switch (presetId) {
    case "ghost-drift":
      return (
        <g>
          <circle cx="32" cy="20" r="26" fill={glow} opacity="0.16">
            <animate attributeName="r" values="22;28;22" dur="5s" repeatCount="indefinite" />
          </circle>
          <g>
            <animateTransform attributeName="transform" type="translate" values="-3 0;3 0;-3 0" dur="4s" repeatCount="indefinite" />
            <path
              d="M32 16c-9 0-15 7-15 16v14l5-4 5 4 5-4 5 4 5-4 5 4V32c0-9-6-16-15-16Z"
              fill="#f8f5ff"
              opacity="0.92"
            />
            <ellipse cx="26" cy="33" rx="3" ry="4" fill="#241b33" />
            <ellipse cx="38" cy="33" rx="3" ry="4" fill="#241b33" />
            <ellipse cx="32" cy="42" rx="3.4" ry="2.4" fill="#241b33">
              <animate attributeName="ry" values="2.4;1.2;2.4" dur="3s" repeatCount="indefinite" />
            </ellipse>
          </g>
        </g>
      );
    case "bat-flap":
      return (
        <g>
          <circle cx="32" cy="30" r="24" fill={glow} opacity="0.12" />
          <g fill={ink}>
            <path d="M32 26c-7-8-18-10-24-5 5 0 6 3 8 6-4 0-6 2-7 4 6-1 9 2 12 5 2-4 5-6 11-6Z">
              <animateTransform attributeName="transform" type="scale" values="1 1;1 0.72;1 1" dur="0.9s" repeatCount="indefinite" additive="sum" />
            </path>
            <path d="M32 26c7-8 18-10 24-5-5 0-6 3-8 6 4 0 6 2 7 4-6-1-9 2-12 5-2-4-5-6-11-6Z">
              <animateTransform attributeName="transform" type="scale" values="1 1;1 0.72;1 1" dur="0.9s" repeatCount="indefinite" additive="sum" />
            </path>
            <ellipse cx="32" cy="30" rx="7" ry="8" />
          </g>
          <circle cx="29" cy="28" r="1.6" fill={glow} />
          <circle cx="35" cy="28" r="1.6" fill={glow} />
        </g>
      );
    case "candy-swirl":
      return (
        <g>
          {Array.from({ length: 8 }).map((_, index) => (
            <rect
              key={index}
              x={index * 10 - 20}
              y={-20}
              width="6"
              height="90"
              fill={index % 2 === 0 ? ink : glow}
              opacity="0.5"
              transform="rotate(20 32 32)"
            >
              <animateTransform
                attributeName="transform"
                type="translate"
                additive="sum"
                values="0 0;10 0;0 0"
                dur="6s"
                repeatCount="indefinite"
              />
            </rect>
          ))}
          <circle cx="32" cy="32" r="17" fill="#2a0f1d" opacity="0.75" />
          <circle cx="32" cy="32" r="13" fill="none" stroke={glow} strokeWidth="2.5" strokeDasharray="8 6">
            <animateTransform attributeName="transform" type="rotate" values="0 32 32;360 32 32" dur="7s" repeatCount="indefinite" />
          </circle>
        </g>
      );
    case "ember-eye":
      return (
        <g>
          <circle cx="32" cy="32" r="22" fill={glow} opacity="0.14">
            <animate attributeName="opacity" values="0.1;0.28;0.1" dur="2.6s" repeatCount="indefinite" />
          </circle>
          <path d="M12 32c6-10 14-15 20-15s14 5 20 15c-6 10-14 15-20 15S18 42 12 32Z" fill="none" stroke={ink} strokeWidth="2.5" />
          <circle cx="32" cy="32" r="7" fill={ink}>
            <animate attributeName="r" values="6;8;6" dur="2.6s" repeatCount="indefinite" />
          </circle>
          <circle cx="32" cy="32" r="3" fill="#150a05" />
          {[0, 1, 2].map((index) => (
            <circle key={index} cx={26 + index * 6} cy={52} r="1.6" fill={glow}>
              <animate attributeName="cy" values="52;16" dur={`${2.4 + index * 0.6}s`} repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.9;0" dur={`${2.4 + index * 0.6}s`} repeatCount="indefinite" />
            </circle>
          ))}
        </g>
      );
    case "moon-wisp":
      return (
        <g>
          <circle cx="32" cy="30" r="26" fill={glow} opacity="0.14" />
          <path
            d="M38 14a18 18 0 1 0 0 34 15 15 0 1 1 0-34Z"
            fill="#f6f4ff"
          >
            <animateTransform attributeName="transform" type="rotate" values="-6 32 32;6 32 32;-6 32 32" dur="6s" repeatCount="indefinite" />
          </path>
          {[
            { x: 16, y: 20 },
            { x: 48, y: 26 },
            { x: 22, y: 48 },
          ].map((star, index) => (
            <circle key={index} cx={star.x} cy={star.y} r="1.8" fill={glow}>
              <animate attributeName="opacity" values="0.3;1;0.3" dur={`${2 + index}s`} repeatCount="indefinite" />
            </circle>
          ))}
        </g>
      );
    case "skull-spin":
      return (
        <g>
          <circle cx="32" cy="32" r="24" fill={glow} opacity="0.12" />
          <g>
            <animateTransform attributeName="transform" type="rotate" values="-8 32 32;8 32 32;-8 32 32" dur="3.4s" repeatCount="indefinite" />
            <ellipse cx="32" cy="29" rx="15" ry="14" fill="#f4f0ea" />
            <rect x="24" y="39" width="16" height="8" rx="3" fill="#f4f0ea" />
            <ellipse cx="26" cy="29" rx="4" ry="5" fill="#241b1e" />
            <ellipse cx="38" cy="29" rx="4" ry="5" fill="#241b1e" />
            <path d="M32 34l-2 4h4z" fill="#241b1e" />
            <path d="M26 43v4M32 43v4M38 43v4" stroke="#241b1e" strokeWidth="1.6" />
          </g>
        </g>
      );
    case "raven":
      return (
        <g fill={ink}>
          <path d="M14 40c4-12 12-20 20-20 6 0 10 3 12 8l8-6-4 9c3 3 4 6 4 9-6-3-10-2-14 2-4 4-8 6-14 6-6 0-10-3-12-8Z">
            <animateTransform attributeName="transform" type="translate" values="0 0;0 -2;0 0" dur="2.8s" repeatCount="indefinite" />
          </path>
          <circle cx="38" cy="27" r="1.8" fill={glow} />
          <path d="M46 30l6 2-6 2z" fill={glow} />
        </g>
      );
    case "static":
      return null;
    case "pumpkin-glow":
    default:
      return (
        <g>
          <circle cx="32" cy="34" r="25" fill={glow} opacity="0.18">
            <animate attributeName="opacity" values="0.12;0.3;0.12" dur="3.4s" repeatCount="indefinite" />
          </circle>
          <ellipse cx="32" cy="35" rx="19" ry="16" fill={ink} />
          <ellipse cx="32" cy="35" rx="7" ry="16" fill={glow} opacity="0.35" />
          <ellipse cx="22" cy="35" rx="4" ry="13" fill="#a83a05" opacity="0.5" />
          <ellipse cx="42" cy="35" rx="4" ry="13" fill="#a83a05" opacity="0.5" />
          <rect x="30" y="14" width="4" height="7" rx="2" fill="#6baa3a" />
          <path d="M25 30l4 3-4 2zM39 30l-4 3 4 2z" fill="#2a1206" />
          <path d="M26 40l3 3 3-3 3 3 3-3" stroke="#2a1206" strokeWidth="2" fill="none" strokeLinecap="round" />
          {[0, 1].map((index) => (
            <circle key={index} cx={20 + index * 24} cy={18} r="1.6" fill={glow}>
              <animate attributeName="opacity" values="0.2;1;0.2" dur={`${2 + index}s`} repeatCount="indefinite" />
            </circle>
          ))}
        </g>
      );
  }
}


function EffectLayer({ effectId, accent, size }: { effectId: string; accent: string; size: number }) {
  if (effectId === "none") return null;
  const bleed = Math.max(34, size * 0.34);

  const common = "pointer-events-none absolute";

  return (
    <span
      className={common}
      aria-hidden="true"
      style={{ inset: -bleed / 2, width: size + bleed, height: size + bleed }}
    >
      <svg viewBox="0 0 100 100" className="h-full w-full overflow-visible">
        {effectId === "glow" ? (
          <circle cx="50" cy="50" r="38" fill="none" stroke={accent} strokeWidth="4" opacity="0.5">
            <animate attributeName="r" values="34;42;34" dur="3.6s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.3;0.75;0.3" dur="3.6s" repeatCount="indefinite" />
          </circle>
        ) : null}

        {effectId === "flame" ? (
          <g>
            <circle cx="50" cy="50" r="40" fill="none" stroke={accent} strokeWidth="2" opacity="0.35" />
            {[
              { x: 22, delay: "0s" },
              { x: 50, delay: "0.7s" },
              { x: 78, delay: "1.4s" },
              { x: 36, delay: "2s" },
              { x: 64, delay: "2.6s" },
            ].map((ember, index) => (
              <path
                key={index}
                d={`M${ember.x} 84 q3 -7 0 -12 q-3 5 0 12z`}
                fill={index % 2 === 0 ? accent : "#ffd166"}
              >
                <animate attributeName="transform" type="translate" values="0 6;0 -46" dur="3.4s" begin={ember.delay} repeatCount="indefinite" />
                <animate attributeName="opacity" values="0;0.95;0" dur="3.4s" begin={ember.delay} repeatCount="indefinite" />
              </path>
            ))}
          </g>
        ) : null}

        {effectId === "sparkle" ? (
          <g fill={accent}>
            {[
              { x: 16, y: 28, d: "0s" },
              { x: 84, y: 34, d: "0.8s" },
              { x: 26, y: 76, d: "1.5s" },
              { x: 74, y: 72, d: "2.2s" },
              { x: 50, y: 12, d: "2.9s" },
            ].map((star, index) => (
              <path key={index} d={`M${star.x} ${star.y - 4} l1.6 2.6 2.9 0.7 -2.1 2.1 0.4 3 -2.8 -1.5 -2.8 1.5 0.4 -3 -2.1 -2.1 2.9 -0.7z`}>
                <animate attributeName="opacity" values="0;1;0" dur="2.8s" begin={star.d} repeatCount="indefinite" />
                <animateTransform
                  attributeName="transform"
                  type="scale"
                  values="0.6;1.25;0.6"
                  dur="2.8s"
                  begin={star.d}
                  repeatCount="indefinite"
                  additive="sum"
                />
              </path>
            ))}
          </g>
        ) : null}

        {effectId === "ring" ? (
          <g>
            <circle cx="50" cy="50" r="42" fill="none" stroke={accent} strokeWidth="2.4" strokeDasharray="9 7" opacity="0.85">
              <animateTransform attributeName="transform" type="rotate" values="0 50 50;360 50 50" dur="9s" repeatCount="indefinite" />
            </circle>
            <circle cx="50" cy="50" r="45" fill="none" stroke={accent} strokeWidth="1" opacity="0.3" />
          </g>
        ) : null}

        {effectId === "orbit" ? (
          <g>
            <circle cx="50" cy="50" r="42" fill="none" stroke={accent} strokeWidth="1" opacity="0.25" />
            {[0, 1, 2].map((index) => (
              <circle key={index} cx="50" cy="8" r="4.5" fill={index === 0 ? "#fff4e6" : accent} opacity="0.9">
                <animateTransform
                  attributeName="transform"
                  type="rotate"
                  values={`${index * 120} 50 50;${index * 120 + 360} 50 50`}
                  dur={`${6 + index * 2}s`}
                  repeatCount="indefinite"
                />
              </circle>
            ))}
          </g>
        ) : null}

        {effectId === "bat" ? (
          <g fill={accent}>
            {[0, 1, 2].map((index) => (
              <g key={index}>
                <animateTransform
                  attributeName="transform"
                  type="rotate"
                  values={`${index * 120} 50 50;${index * 120 + 360} 50 50`}
                  dur={`${7 + index * 2.5}s`}
                  repeatCount="indefinite"
                />
                <g transform={`translate(${50 + (index % 2 === 0 ? 0 : 4)} 8)`}>
                  <path d="M0 0 l-7 -5 q3 0 4 2 q-2 -1 -3 1 q3 0 5 3 q2 -3 5 -3 q-1 -2 -3 -1 q1 -2 4 -2 z">
                    <animateTransform attributeName="transform" type="scale" values="1 1;1 0.6;1 1" dur="0.7s" repeatCount="indefinite" additive="sum" />
                  </path>
                </g>
              </g>
            ))}
          </g>
        ) : null}

        {effectId === "bolt" ? (
          <g stroke={accent} strokeWidth="2" fill="none" strokeLinecap="round">
            {[
              { d: "M14 34 l8 -6 l-3 9 l8 -3", delay: "0s" },
              { d: "M86 60 l-8 6 l3 -9 l-8 3", delay: "1.1s" },
              { d: "M30 88 l4 -8 l4 6", delay: "2.2s" },
            ].map((bolt, index) => (
              <path key={index} d={bolt.d} opacity="0">
                <animate attributeName="opacity" values="0;1;0;0.7;0" dur="2.6s" begin={bolt.delay} repeatCount="indefinite" />
              </path>
            ))}
            <circle cx="50" cy="50" r="43" fill="none" stroke={accent} strokeWidth="1.5" opacity="0.35">
              <animate attributeName="opacity" values="0.15;0.6;0.15" dur="2.6s" repeatCount="indefinite" />
            </circle>
          </g>
        ) : null}

        {effectId === "frost" ? (
          <g fill={accent}>
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <circle key={index} cx={12 + index * 15} cy={0} r={1.6 + (index % 2)} opacity="0.9">
                <animate attributeName="cy" values="-6;104" dur={`${4 + (index % 4)}s`} begin={`${index * 0.6}s`} repeatCount="indefinite" />
                <animate attributeName="opacity" values="0;0.9;0" dur={`${4 + (index % 4)}s`} begin={`${index * 0.6}s`} repeatCount="indefinite" />
              </circle>
            ))}
            <circle cx="50" cy="50" r="41" fill="none" stroke={accent} strokeWidth="1.5" opacity="0.3" />
          </g>
        ) : null}

        {effectId === "candy" ? (
          <g>
            <g>
              <animateTransform attributeName="transform" type="rotate" values="0 50 50;360 50 50" dur="12s" repeatCount="indefinite" />
              {Array.from({ length: 12 }).map((_, index) => (
                <path
                  key={index}
                  d="M50 50 m0 -43 a43 43 0 0 1 14 3"
                  fill="none"
                  stroke={index % 2 === 0 ? accent : "#ffd166"}
                  strokeWidth="5"
                  strokeLinecap="butt"
                  transform={`rotate(${index * 30} 50 50)`}
                  opacity="0.85"
                />
              ))}
            </g>
            <circle cx="50" cy="50" r="38" fill="none" stroke="#150a05" strokeWidth="1.5" opacity="0.4" />
          </g>
        ) : null}
      </svg>
    </span>
  );
}

export function AvatarView({
  avatar,
  name,
  size = 40,
  className = "",
  ring = true,
  effect,
}: {
  avatar?: AvatarConfig | string | null;
  name?: string;
  size?: number;
  className?: string;
  ring?: boolean;
  effect?: string | null;
}) {
  const config: AvatarConfig =
    typeof avatar === "string" || avatar == null ? parseAvatar(avatar ?? "") : avatar;
  const presetId = config.kind === "preset" ? config.presetId : "static";
  const preset = avatarPreset(presetId);
  const dimension = { width: size, height: size };
  const effectId = parseEffect(effect ?? "");
  const effectMeta = effectById(effectId);

  const shell = `relative block shrink-0 overflow-hidden rounded-full border ${
    ring ? "border-[var(--accent-line)]" : "border-white/10"
  } ${className}`;

  const wrap = (inner: React.ReactNode) => (
    <span className="relative inline-flex shrink-0" style={dimension}>
      {inner}
      <EffectLayer effectId={effectId} accent={effectMeta.accent} size={size} />
    </span>
  );

  if (config.kind === "media") {
    return wrap(
      <span className={shell} style={dimension}>
        {config.animated ? (
          <video
            src={`/api/media/${config.mediaId}`}
            autoPlay
            loop
            muted
            playsInline
            className="h-full w-full object-cover"
          />
        ) : (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={`/api/media/${config.mediaId}`}
            alt={name ? `${name}'s avatar` : "avatar"}
            className="h-full w-full object-cover"
          />
        )}
      </span>,
    );
  }

  if (config.kind === "initials") {
    return wrap(
      <span
        className={`${shell} grid place-items-center font-black uppercase text-[var(--accent)]`}
        style={{ ...dimension, background: "var(--accent-soft)", fontSize: size * 0.36 }}
      >
        {initialsFor(name ?? "pumpkin")}
      </span>,
    );
  }

  return wrap(
    <span className={shell} style={{ ...dimension, background: preset.colors.bg }}>
      <svg viewBox="0 0 64 64" className="h-full w-full" role="img" aria-label={`${preset.name} avatar`}>
        <PresetArt presetId={preset.id} glow={preset.colors.glow} ink={preset.colors.ink} />
      </svg>
    </span>,
  );
}
