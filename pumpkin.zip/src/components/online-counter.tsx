"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { Clock3, Loader2, Users, X } from "lucide-react";
import { AvatarView } from "@/components/avatar-view";

const VISITOR_KEY = "pumpkin.visitor";
const HEARTBEAT_MS = 25_000;
const POLL_MS = 20_000;

export type OnlinePerson = {
  key: string;
  name: string;
  displayName: string;
  path: string;
  lastSeenAt: string;
  avatar: string | null;
  effect: string | null;
  member: boolean;
};

type Presence = {
  online: number;
  members: number;
  guests: number;
  people?: OnlinePerson[];
};

const PAGE_LABELS: Record<string, string> = {
  "/": "Browser",
  "/account": "Account",
  "/friends": "Friends",
  "/chat": "Chatroom",
  "/activities": "Study break",
  "/mirrors": "Mirrors",
  "/settings": "Settings",
  "/banners": "Banners",
  "/streamx": "StreamX",
  "/browse": "Browsing",
};

function pageLabel(path: string) {
  if (PAGE_LABELS[path]) return PAGE_LABELS[path];
  if (path.startsWith("/activities/")) return "On a break";
  if (path.startsWith("/m/")) return "On a mirror";
  return path === "/" ? "Browser" : path.replace("/", "").slice(0, 18) || "Browser";
}

function makeVisitorId() {
  const random = Math.random().toString(36).slice(2, 10);
  return `v${Date.now().toString(36)}${random}`;
}

function visitorId() {
  try {
    const existing = window.localStorage.getItem(VISITOR_KEY);
    if (existing && /^[A-Za-z0-9_-]{8,64}$/.test(existing)) return existing;
    const created = makeVisitorId();
    window.localStorage.setItem(VISITOR_KEY, created);
    return created;
  } catch {
    return makeVisitorId();
  }
}

function seenLabel(iso: string) {
  const seconds = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (seconds < 10) return "just now";
  if (seconds < 60) return `${seconds}s ago`;
  return `${Math.round(seconds / 60)}m ago`;
}

export function OnlineCounter({ className = "" }: { className?: string }) {
  const [presence, setPresence] = useState<Presence | null>(null);
  const [open, setOpen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [pulse, setPulse] = useState(false);
  const [me, setMe] = useState<string | null>(null);
  const previous = useRef<number | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const buttonRef = useRef<HTMLButtonElement | null>(null);

  const apply = useCallback((data: Presence) => {
    setPresence(data);
    if (previous.current !== null && data.online > previous.current) setPulse(true);
    previous.current = data.online;
  }, []);

  useEffect(() => {
    const id = visitorId();
    setMe(id);

    const beat = async () => {
      try {
        const response = await fetch("/api/presence", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ visitorId: id, path: window.location.pathname }),
          cache: "no-store",
        });
        if (!response.ok) return;
        apply((await response.json()) as Presence);
      } catch {
        // Presence is decorative; ignore network hiccups.
      }
    };

    const poll = async () => {
      try {
        const response = await fetch("/api/presence", { cache: "no-store" });
        if (!response.ok) return;
        apply((await response.json()) as Presence);
      } catch {
        // ignore
      }
    };

    void beat();
    const beatTimer = setInterval(() => void beat(), HEARTBEAT_MS);
    const pollTimer = setInterval(() => void poll(), POLL_MS);

    const onVisible = () => {
      if (document.visibilityState === "visible") void beat();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", onVisible);

    return () => {
      clearInterval(beatTimer);
      clearInterval(pollTimer);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", onVisible);
    };
  }, [apply]);

  useEffect(() => {
    if (!pulse) return;
    const timer = setTimeout(() => setPulse(false), 1200);
    return () => clearTimeout(timer);
  }, [pulse]);

  // Refresh immediately when the list opens, and close on outside click / Escape.
  useEffect(() => {
    if (!open) return;

    void (async () => {
      setRefreshing(true);
      try {
        const response = await fetch("/api/presence", { cache: "no-store" });
        if (response.ok) apply((await response.json()) as Presence);
      } catch {
        // keep the last list
      } finally {
        setRefreshing(false);
      }
    })();

    const onPointerDown = (event: MouseEvent) => {
      const target = event.target as Node;
      if (panelRef.current?.contains(target) || buttonRef.current?.contains(target)) return;
      setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };

    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [apply, open]);

  const online = presence?.online ?? 0;
  const people = presence?.people ?? [];
  const displayPeople = people.length > 0 ? people : [];

  return (
    <div className={`relative inline-block ${className}`}>
      <button
        ref={buttonRef}
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        aria-haspopup="dialog"
        title="See everyone who is online right now"
        className="inline-flex items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-400/[0.08] px-2.5 py-1 backdrop-blur-sm transition hover:border-emerald-300/50 hover:bg-emerald-400/[0.14] focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300/60"
      >
        <span className="relative flex h-2 w-2 items-center justify-center">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-300" />
        </span>
        <span className="flex items-baseline gap-1 font-mono text-[0.7rem] font-semibold uppercase tracking-[0.12em] text-emerald-100/90">
          <span
            className={`tabular-nums transition-transform duration-300 ${
              pulse ? "scale-125 text-white" : "scale-100"
            }`}
          >
            {presence === null ? "—" : online}
          </span>
          <span className="text-[0.58rem] font-medium tracking-[0.16em] text-emerald-200/60">
            {presence === null ? "connecting" : "online"}
          </span>
        </span>
        <Users className="h-3 w-3 text-emerald-200/60" />
      </button>

      {open ? (
        <div
          ref={panelRef}
          role="dialog"
          aria-label="Players online"
          className="glass animate-rise absolute left-0 top-[calc(100%+8px)] z-50 w-[280px] rounded-2xl p-3 text-left shadow-2xl sm:w-[320px]"
        >
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="section-label flex items-center gap-1.5">
                <Users className="h-3 w-3" /> online now
              </p>
              <p className="mt-1 text-[0.7rem] text-pumpkin-50/55">
                <strong className="text-pumpkin-50">{online}</strong> here ·{" "}
                {presence?.members ?? 0} signed in · {presence?.guests ?? 0} guest
                {(presence?.guests ?? 0) === 1 ? "" : "s"}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close online list"
              className="rounded-md p-1 text-pumpkin-50/40 transition hover:bg-white/10 hover:text-pumpkin-50"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="mt-2 max-h-[260px] space-y-1 overflow-y-auto pr-0.5">
            {refreshing && displayPeople.length === 0 ? (
              <p className="flex items-center justify-center gap-1.5 py-6 text-[0.68rem] text-pumpkin-50/40">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> checking who is here
              </p>
            ) : displayPeople.length === 0 ? (
              <p className="py-6 text-center text-[0.68rem] leading-relaxed text-pumpkin-50/40">
                Nobody else is online right now.
                <br />
                Keep this tab open and you will count as online.
              </p>
            ) : (
              displayPeople.map((person) => {
                const isMe = person.key === me;
                return (
                  <div
                    key={person.key}
                    className="flex items-center gap-2 rounded-xl border border-white/[0.06] bg-black/30 px-2 py-1.5"
                  >
                    <AvatarView
                      avatar={person.avatar ?? JSON.stringify({ kind: "initials" })}
                      name={person.displayName}
                      size={28}
                      effect={person.effect ?? "none"}
                      ring={Boolean(person.avatar)}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-1 truncate text-[0.74rem] font-semibold text-pumpkin-50">
                        {person.displayName}
                        {isMe ? (
                          <span className="rounded-full bg-[var(--accent-soft)] px-1.5 text-[0.55rem] font-bold uppercase tracking-wider text-[var(--accent)]">
                            you
                          </span>
                        ) : null}
                      </p>
                      <p className="flex items-center gap-1 truncate text-[0.6rem] text-pumpkin-50/40">
                        <span
                          className={`h-1 w-1 rounded-full ${
                            person.member ? "bg-emerald-400" : "bg-amber-300/70"
                          }`}
                        />
                        {person.member ? "member" : "guest"} · {pageLabel(person.path)}
                      </p>
                    </div>
                    <span
                      className="shrink-0 text-[0.55rem] text-pumpkin-50/25"
                      title={new Date(person.lastSeenAt).toLocaleTimeString()}
                    >
                      <Clock3 className="mr-0.5 inline h-2.5 w-2.5" />
                      {seenLabel(person.lastSeenAt)}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          <div className="mt-2 flex items-center justify-between border-t border-white/10 pt-2">
            <Link
              href="/chat"
              onClick={() => setOpen(false)}
              className="text-[0.64rem] font-semibold text-[var(--accent)] hover:underline"
            >
              Open the chatroom
            </Link>
            <button
              type="button"
              onClick={async () => {
                setRefreshing(true);
                try {
                  const response = await fetch("/api/presence", { cache: "no-store" });
                  if (response.ok) apply((await response.json()) as Presence);
                } finally {
                  setRefreshing(false);
                }
              }}
              className="flex items-center gap-1 text-[0.62rem] font-semibold text-pumpkin-50/45 transition hover:text-pumpkin-50"
            >
              {refreshing ? <Loader2 className="h-3 w-3 animate-spin" /> : null}
              Refresh
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
