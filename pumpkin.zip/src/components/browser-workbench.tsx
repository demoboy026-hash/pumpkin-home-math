"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  LayoutGrid,
  Globe,
  Home,
  Loader2,
  MessagesSquare,
  Plus,
  RotateCw,
  Search,
  Shield,
  ShieldCheck,
  Sparkles,
  Trash2,
  Tv,
  Waypoints,
  X,
} from "lucide-react";
import { useSettings } from "@/components/providers";
import { ACTIVITIES } from "@/lib/activities";
import { HISTORY_KEY, looksLikeUrl, normalizeTarget, prettyHost, readStoredSettings } from "@/lib/settings";
import { STREAMX_URL } from "@/lib/constants";
import type { Bookmark as BookmarkItem } from "@/lib/types";

type Tab = {
  id: string;
  stack: string[];
  index: number;
};

type HistoryEntry = { url: string; title: string; at: number };

const MAX_TABS = 7;

const SHORTCUTS: { label: string; target: string; hint: string; icon: typeof Tv; internal?: boolean }[] = [
  { label: "StreamX", target: STREAMX_URL, hint: "live redirect", icon: Tv },
  { label: "Activities", target: "/activities", hint: `${ACTIVITIES.length} built in`, icon: LayoutGrid, internal: true },
  { label: "Mirrors", target: "/mirrors", hint: "clone the site", icon: Waypoints, internal: true },
  { label: "Chatroom", target: "/chat", hint: "3 rooms", icon: MessagesSquare, internal: true },
];

const POPULAR = [
  { label: "YouTube", url: "https://www.youtube.com" },
  { label: "Twitch", url: "https://www.twitch.tv" },
  { label: "Reddit", url: "https://www.reddit.com" },
  { label: "itch.io", url: "https://itch.io" },
  { label: "Wikipedia", url: "https://en.wikipedia.org" },
  { label: "Wikipedia", url: "https://en.wikipedia.org" },
];

function newTab(): Tab {
  return { id: `tab-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, stack: [], index: -1 };
}

function resolveInput(raw: string) {
  const trimmed = raw.trim();
  if (!trimmed) return null;
  if (looksLikeUrl(trimmed)) return normalizeTarget(trimmed);
  return `https://duckduckgo.com/?q=${encodeURIComponent(trimmed)}`;
}

function timeAgo(input: string | number) {
  const value = typeof input === "number" ? input : new Date(input).getTime();
  const seconds = Math.max(1, Math.round((Date.now() - value) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

export function BrowserWorkbench({
  initialUrl = null,
  mirror,
}: {
  initialUrl?: string | null;
  mirror?: { code: string; label: string };
}) {
  const { settings, ready, notify } = useSettings();
  const [tabs, setTabs] = useState<Tab[]>(() => {
    if (initialUrl) return [{ ...newTab(), stack: [initialUrl], index: 0 }];
    return [newTab()];
  });
  const [activeId, setActiveId] = useState(() => tabs[0].id);
  const [input, setInput] = useState(initialUrl ?? "");
  const [proxy, setProxy] = useState(false);
  const [proxyReady, setProxyReady] = useState(false);
  const [loading, setLoading] = useState(Boolean(initialUrl));
  const [slow, setSlow] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const activeTab = tabs.find((tab) => tab.id === activeId) ?? tabs[0];
  const currentUrl = activeTab && activeTab.index >= 0 ? activeTab.stack[activeTab.index] : null;

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(HISTORY_KEY);
      if (raw) setHistory(JSON.parse(raw) as HistoryEntry[]);
    } catch {
      setHistory([]);
    }
  }, []);

  useEffect(() => {
    if (!ready || proxyReady) return;
    setProxy(readStoredSettings().proxyDefault || settings.proxyDefault);
    setProxyReady(true);
  }, [ready, proxyReady, settings.proxyDefault]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const response = await fetch("/api/bookmarks", { cache: "no-store" });
        if (!response.ok) return;
        const data = (await response.json()) as { bookmarks?: BookmarkItem[] };
        if (!cancelled && data.bookmarks) setBookmarks(data.bookmarks);
      } catch {
        // Bookmarks remain usable from memory even if the API hiccups.
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    setInput(currentUrl ?? "");
    setSlow(false);
    if (currentUrl) setLoading(true);
    if (timerRef.current) clearTimeout(timerRef.current);
    if (currentUrl) {
      timerRef.current = setTimeout(() => setSlow(true), 5200);
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [currentUrl, reloadKey]);

  const remember = useCallback((url: string) => {
    setHistory((previous) => {
      const next = [
        { url, title: prettyHost(url), at: Date.now() },
        ...previous.filter((entry) => entry.url !== url),
      ].slice(0, 18);
      try {
        window.localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
      } catch {
        // ignore quota errors
      }
      return next;
    });
  }, []);

  const navigate = useCallback(
    (raw: string) => {
      const destination = resolveInput(raw);
      if (!destination) {
        notify("Type a link or a search to go anywhere");
        return;
      }
      setTabs((previous) =>
        previous.map((tab) => {
          if (tab.id !== activeId) return tab;
          const stack = [...tab.stack.slice(0, tab.index + 1), destination].slice(-40);
          return { ...tab, stack, index: stack.length - 1 };
        }),
      );
      setLoading(true);
      setSlow(false);
      remember(destination);
    },
    [activeId, notify, remember],
  );

  const startupRef = useRef(false);
  useEffect(() => {
    if (!ready || !proxyReady || startupRef.current || initialUrl) return;
    const startup = normalizeTarget(settings.homepage || "");
    if (!startup) return;
    startupRef.current = true;
    navigate(startup);
  }, [ready, proxyReady, initialUrl, settings.homepage, navigate]);

  const step = (direction: -1 | 1) => {
    setTabs((previous) =>
      previous.map((tab) => {
        if (tab.id !== activeId) return tab;
        const index = Math.min(tab.stack.length - 1, Math.max(-1, tab.index + direction));
        return { ...tab, index };
      }),
    );
  };

  const startPage = () =>
    setTabs((previous) => previous.map((tab) => (tab.id === activeId ? { ...tab, index: -1 } : tab)));

  const addTab = () => {
    if (tabs.length >= MAX_TABS) {
      notify(`Browser is capped at ${MAX_TABS} tabs`);
      return;
    }
    const tab = newTab();
    setTabs((previous) => [...previous, tab]);
    setActiveId(tab.id);
  };

  const closeTab = (id: string) => {
    const remaining = tabs.filter((tab) => tab.id !== id);
    if (remaining.length === 0) {
      const tab = newTab();
      setTabs([tab]);
      setActiveId(tab.id);
      return;
    }
    setTabs(remaining);
    if (id === activeId) setActiveId(remaining[remaining.length - 1].id);
  };

  const toggleProxy = () => {
    setProxy((value) => {
      const next = !value;
      notify(next ? "Shield on — pages load through pumpkin" : "Shield off — direct embed");
      return next;
    });
    setReloadKey((key) => key + 1);
  };

  const frameSrc = useMemo(() => {
    if (!currentUrl) return null;
    if (proxy) return `/api/proxy?url=${encodeURIComponent(currentUrl)}`;
    return currentUrl;
  }, [currentUrl, proxy]);

  const isBookmarked = currentUrl ? bookmarks.some((bookmark) => bookmark.url === currentUrl) : false;

  const toggleBookmark = async () => {
    if (!currentUrl) return;
    const existing = bookmarks.find((bookmark) => bookmark.url === currentUrl);

    if (existing) {
      setBookmarks((previous) => previous.filter((bookmark) => bookmark.id !== existing.id));
      try {
        await fetch(`/api/bookmarks?id=${existing.id}`, { method: "DELETE" });
        notify("Removed from favorites");
      } catch {
        notify("Could not remove that favorite");
      }
      return;
    }

    try {
      const response = await fetch("/api/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: currentUrl, label: prettyHost(currentUrl) }),
      });
      const data = (await response.json()) as { bookmark?: BookmarkItem; error?: string };
      if (!response.ok || !data.bookmark) {
        notify(data.error ?? "Could not save this favorite");
        return;
      }
      setBookmarks((previous) => [...previous, data.bookmark as BookmarkItem]);
      notify("Saved to favorites");
    } catch {
      notify("Could not save this favorite");
    }
  };

  const removeBookmark = async (bookmark: BookmarkItem) => {
    setBookmarks((previous) => previous.filter((item) => item.id !== bookmark.id));
    try {
      await fetch(`/api/bookmarks?id=${bookmark.id}`, { method: "DELETE" });
    } catch {
      notify("Could not remove that favorite");
    }
  };

  const canGoBack = Boolean(activeTab && (activeTab.index > -1 || activeTab.stack.length > 0));
  const canGoForward = Boolean(activeTab && activeTab.index < activeTab.stack.length - 1);

  return (
    <section className="glass animate-rise overflow-hidden rounded-[26px]">
      {mirror ? (
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-[var(--accent-soft)] px-4 py-2 text-[0.7rem] text-pumpkin-50/75">
          <span className="flex items-center gap-2">
            <Waypoints className="h-3.5 w-3.5 text-[var(--accent)]" />
            Mirror <strong className="font-semibold text-pumpkin-50">{mirror.label}</strong>
            <span className="font-mono text-pumpkin-50/40">/m/{mirror.code}</span>
          </span>
          <Link href="/mirrors" className="flex items-center gap-1 font-semibold text-[var(--accent)] hover:underline">
            Make another <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
      ) : null}

      <div className="border-b border-white/10 bg-black/35 px-2.5 pt-2.5">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2">
          {tabs.map((tab) => {
            const tabUrl = tab.index >= 0 ? tab.stack[tab.index] : null;
            const active = tab.id === activeId;
            return (
              <div
                key={tab.id}
                className={`group flex min-w-[140px] max-w-[220px] items-center gap-2 rounded-t-xl border border-b-0 px-2.5 py-1.5 text-xs transition ${
                  active
                    ? "border-white/12 bg-[#150e0a] text-pumpkin-50"
                    : "border-transparent bg-white/[0.03] text-pumpkin-50/50 hover:bg-white/[0.06]"
                }`}
              >
                <button
                  type="button"
                  onClick={() => setActiveId(tab.id)}
                  className="flex min-w-0 flex-1 items-center gap-1.5 text-left"
                >
                  <Globe className={`h-3 w-3 shrink-0 ${active ? "text-[var(--accent)]" : ""}`} />
                  <span className="truncate">{tabUrl ? prettyHost(tabUrl) : "New tab"}</span>
                </button>
                <button
                  type="button"
                  aria-label="Close tab"
                  onClick={() => closeTab(tab.id)}
                  className="rounded p-0.5 text-pumpkin-50/35 transition hover:bg-white/10 hover:text-pumpkin-50"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            );
          })}
          <button
            type="button"
            aria-label="New tab"
            onClick={addTab}
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-white/10 bg-white/[0.04] text-pumpkin-50/60 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50"
          >
            <Plus className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 pb-2.5 sm:flex-nowrap">
          <div className="flex items-center gap-1">
            <button
              type="button"
              aria-label="Back"
              disabled={!canGoBack}
              onClick={() => step(-1)}
              className="grid h-8 w-8 place-items-center rounded-lg text-pumpkin-50/60 transition hover:bg-white/10 hover:text-pumpkin-50 disabled:opacity-30"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              aria-label="Forward"
              disabled={!canGoForward}
              onClick={() => step(1)}
              className="grid h-8 w-8 place-items-center rounded-lg text-pumpkin-50/60 transition hover:bg-white/10 hover:text-pumpkin-50 disabled:opacity-30"
            >
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              aria-label="Reload"
              onClick={() => setReloadKey((key) => key + 1)}
              className="grid h-8 w-8 place-items-center rounded-lg text-pumpkin-50/60 transition hover:bg-white/10 hover:text-pumpkin-50"
            >
              <RotateCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            </button>
            <button
              type="button"
              aria-label="Home"
              onClick={startPage}
              className="grid h-8 w-8 place-items-center rounded-lg text-pumpkin-50/60 transition hover:bg-white/10 hover:text-pumpkin-50"
            >
              <Home className="h-4 w-4" />
            </button>
          </div>

          <form
            className="order-last flex min-w-0 flex-1 basis-full items-center gap-1.5 sm:order-none sm:basis-auto"
            onSubmit={(event) => {
              event.preventDefault();
              navigate(input);
            }}
          >
            <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-white/10 bg-black/50 px-2.5 py-1.5 focus-within:border-[var(--accent-line)]">
              {proxy ? (
                <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-[var(--accent)]" />
              ) : (
                <Search className="h-3.5 w-3.5 shrink-0 text-pumpkin-50/35" />
              )}
              <input
                value={input}
                onChange={(event) => setInput(event.target.value)}
                placeholder="Search or type a link — the shield is one tap away"
                spellCheck={false}
                aria-label="Address bar"
                className="min-w-0 flex-1 bg-transparent text-xs text-pumpkin-50 outline-none placeholder:text-pumpkin-50/30 sm:text-[0.8rem]"
              />
              {input ? (
                <button
                  type="button"
                  aria-label="Clear address"
                  onClick={() => setInput("")}
                  className="rounded p-0.5 text-pumpkin-50/35 hover:text-pumpkin-50"
                >
                  <X className="h-3 w-3" />
                </button>
              ) : null}
            </div>
            <button
              type="submit"
              className="btn-accent rounded-lg px-2.5 py-2 text-[0.7rem] font-bold sm:px-3"
            >
              Go
            </button>
          </form>

          <div className="ml-auto flex items-center gap-1">
            <button
              type="button"
              onClick={toggleProxy}
              title="Shield mode fetches pages through pumpkin so frame-blocked sites still load"
              className={`flex items-center gap-1.5 rounded-lg border px-2 py-1.5 text-[0.68rem] font-semibold transition ${
                proxy
                  ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                  : "border-white/10 bg-white/[0.04] text-pumpkin-50/55 hover:text-pumpkin-50"
              }`}
            >
              <Shield className="h-3.5 w-3.5" />
              Shield {proxy ? "on" : "off"}
            </button>
            <button
              type="button"
              onClick={toggleBookmark}
              disabled={!currentUrl}
              title={isBookmarked ? "Remove favorite" : "Add favorite"}
              className={`grid h-8 w-8 place-items-center rounded-lg border transition disabled:opacity-30 ${
                isBookmarked
                  ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-[var(--accent)]"
                  : "border-white/10 bg-white/[0.04] text-pumpkin-50/60 hover:text-pumpkin-50"
              }`}
            >
              {isBookmarked ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
            </button>
            {currentUrl ? (
              <a
                href={currentUrl}
                target="_blank"
                rel="noreferrer noopener"
                title="Open outside the browser"
                className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/[0.04] text-pumpkin-50/60 transition hover:text-pumpkin-50"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            ) : null}
          </div>
        </div>
      </div>

      {bookmarks.length > 0 ? (
        <div className="flex items-center gap-1.5 overflow-x-auto border-b border-white/[0.07] bg-black/20 px-3 py-1.5">
          <span className="flex shrink-0 items-center gap-1 pr-1 text-[0.62rem] font-semibold uppercase tracking-widest text-pumpkin-50/35">
            <Bookmark className="h-3 w-3" /> favorites
          </span>
          {bookmarks.map((bookmark) => (
            <span
              key={bookmark.id}
              className="group flex shrink-0 items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[0.68rem] text-pumpkin-50/70"
            >
              <button
                type="button"
                onClick={() => navigate(bookmark.url)}
                className="max-w-[150px] truncate transition hover:text-pumpkin-50"
                title={bookmark.url}
              >
                {bookmark.label}
              </button>
              <button
                type="button"
                aria-label={`Remove ${bookmark.label}`}
                onClick={() => removeBookmark(bookmark)}
                className="text-pumpkin-50/25 transition hover:text-red-300"
              >
                <X className="h-2.5 w-2.5" />
              </button>
            </span>
          ))}
        </div>
      ) : null}

      <div className="relative min-h-[460px] bg-[#0b0806] sm:min-h-[560px]">
        {currentUrl && frameSrc ? (
          <>
            <iframe
              key={`${frameSrc}-${reloadKey}`}
              src={frameSrc}
              title="pumpkin browser viewport"
              onLoad={() => {
                setLoading(false);
                setSlow(false);
              }}
              referrerPolicy="no-referrer"
              sandbox={`allow-scripts allow-forms allow-popups allow-presentation allow-downloads${proxy ? "" : " allow-same-origin"}`}
              className="h-[460px] w-full border-0 bg-white sm:h-[560px]"
            />
            {loading ? (
              <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-center gap-2 bg-black/70 py-2 text-[0.7rem] text-pumpkin-50/70 backdrop-blur">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-[var(--accent)]" />
                loading {prettyHost(currentUrl)}
              </div>
            ) : null}
            {slow ? (
              <div className="absolute inset-x-3 bottom-3 z-10 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[var(--accent-line)] bg-[#150e09]/95 px-3 py-2.5 text-[0.7rem] text-pumpkin-50/75 shadow-xl backdrop-blur">
                <span className="flex items-center gap-2">
                  <Shield className="h-3.5 w-3.5 shrink-0 text-[var(--accent)]" />
                  Site looking blank? Some servers refuse to be embedded.
                </span>
                <span className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={toggleProxy}
                    className="btn-accent rounded-lg px-2.5 py-1.5 text-[0.68rem] font-bold"
                  >
                    {proxy ? "Retry shield" : "Use shield"}
                  </button>
                  <a
                    href={currentUrl}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="btn-ghost rounded-lg px-2.5 py-1.5 text-[0.68rem] font-semibold text-pumpkin-50"
                  >
                    Open directly
                  </a>
                  <button
                    type="button"
                    onClick={() => setSlow(false)}
                    aria-label="Dismiss"
                    className="text-pumpkin-50/40 hover:text-pumpkin-50"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </span>
              </div>
            ) : null}
          </>
        ) : (
          <div className="relative overflow-hidden px-4 py-7 sm:px-7">
            <div
              className="pointer-events-none absolute -right-10 top-0 h-48 w-48 rounded-full blur-[70px]"
              style={{ background: "var(--accent-glow)", opacity: 0.35 }}
            />
            <div className="relative mx-auto max-w-2xl text-center">
              <span className="accent-chip inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.16em]">
                <Sparkles className="h-3 w-3" />
                unblocked browser
              </span>
              <h2 className="mt-3 text-2xl font-bold tracking-tight text-pumpkin-50 sm:text-3xl">
                Where do you want to go?
              </h2>
              <p className="mx-auto mt-1.5 max-w-md text-xs leading-relaxed text-pumpkin-50/50 sm:text-sm">
                Search, paste a link, or jump into something below. Shield mode tunnels pages through
                this site when a server blocks embedding.
              </p>

              <form
                className="mx-auto mt-4 flex max-w-lg items-center gap-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  navigate(input);
                }}
              >
                <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-white/12 bg-black/50 px-3 py-2.5 focus-within:border-[var(--accent-line)]">
                  <Search className="h-4 w-4 shrink-0 text-pumpkin-50/35" />
                  <input
                    value={input}
                    onChange={(event) => setInput(event.target.value)}
                    placeholder="Search the web or enter an address"
                    spellCheck={false}
                    aria-label="Search or address"
                    className="min-w-0 flex-1 bg-transparent text-sm text-pumpkin-50 outline-none placeholder:text-pumpkin-50/30"
                  />
                </div>
                <button type="submit" className="btn-accent rounded-xl px-4 py-2.5 text-sm font-bold">
                  Go
                </button>
              </form>

              <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
                {SHORTCUTS.map((shortcut) => {
                  const Icon = shortcut.icon;
                  const body = (
                    <>
                      <Icon className="h-4 w-4 text-[var(--accent)]" />
                      <span className="mt-1.5 block text-[0.78rem] font-semibold text-pumpkin-50">
                        {shortcut.label}
                      </span>
                      <span className="block text-[0.62rem] text-pumpkin-50/35">{shortcut.hint}</span>
                    </>
                  );
                  return shortcut.internal ? (
                    <Link
                      key={shortcut.label}
                      href={shortcut.target}
                      className="glass-soft panel-hover rounded-xl px-3 py-3 text-left"
                    >
                      {body}
                    </Link>
                  ) : (
                    <button
                      key={shortcut.label}
                      type="button"
                      onClick={() => navigate(shortcut.target)}
                      className="glass-soft panel-hover rounded-xl px-3 py-3 text-left"
                    >
                      {body}
                    </button>
                  );
                })}
              </div>

              <div className="mt-5 grid gap-3 text-left sm:grid-cols-2">
                <div className="rounded-xl border border-white/[0.07] bg-black/25 p-3">
                  <p className="section-label flex items-center gap-1.5">
                    <Bookmark className="h-3 w-3" /> favorites
                  </p>
                  {bookmarks.length === 0 ? (
                    <p className="mt-2 text-[0.72rem] leading-relaxed text-pumpkin-50/40">
                      Hit the bookmark icon in the address bar on any page to pin it here forever.
                    </p>
                  ) : (
                    <ul className="mt-2 space-y-1">
                      {bookmarks.slice(0, 6).map((bookmark) => (
                        <li key={bookmark.id} className="group flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => navigate(bookmark.url)}
                            className="flex min-w-0 flex-1 items-center justify-between gap-2 rounded-lg px-1.5 py-1 text-[0.74rem] text-pumpkin-50/75 transition hover:bg-white/5 hover:text-pumpkin-50"
                          >
                            <span className="truncate">{bookmark.label}</span>
                            <span className="shrink-0 text-[0.6rem] text-pumpkin-50/25">
                              {prettyHost(bookmark.url)}
                            </span>
                          </button>
                          <button
                            type="button"
                            aria-label={`Remove ${bookmark.label}`}
                            onClick={() => removeBookmark(bookmark)}
                            className="text-pumpkin-50/20 transition hover:text-red-300"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <div className="rounded-xl border border-white/[0.07] bg-black/25 p-3">
                  <p className="section-label">recent</p>
                  {history.length === 0 ? (
                    <p className="mt-2 text-[0.72rem] leading-relaxed text-pumpkin-50/40">
                      Your browsing trail lands here, on this device only.
                    </p>
                  ) : (
                    <ul className="mt-2 space-y-0.5">
                      {history.slice(0, 6).map((entry) => (
                        <li key={`${entry.url}-${entry.at}`}>
                          <button
                            type="button"
                            onClick={() => navigate(entry.url)}
                            className="flex w-full items-center justify-between gap-2 rounded-lg px-1.5 py-1 text-[0.74rem] text-pumpkin-50/70 transition hover:bg-white/5 hover:text-pumpkin-50"
                          >
                            <span className="truncate">{entry.title}</span>
                            <span className="shrink-0 text-[0.6rem] text-pumpkin-50/25">
                              {timeAgo(entry.at)}
                            </span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5">
                <span className="text-[0.6rem] uppercase tracking-[0.16em] text-pumpkin-50/25">popular</span>
                {POPULAR.map((site) => (
                  <button
                    key={site.url}
                    type="button"
                    onClick={() => navigate(site.url)}
                    className="rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[0.68rem] text-pumpkin-50/60 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50"
                  >
                    {site.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/10 bg-black/30 px-3 py-2 text-[0.64rem] text-pumpkin-50/40">
        <span className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
          {currentUrl ? prettyHost(currentUrl) : "start page"} · {tabs.length} tab
          {tabs.length === 1 ? "" : "s"} · {proxy ? "shield tunnel" : "direct connection"}
        </span>
        <span className="hidden items-center gap-1.5 sm:flex">
          <Shield className="h-3 w-3" />
          {bookmarks.length} favorite{bookmarks.length === 1 ? "" : "s"} saved to your profile
        </span>
      </div>
    </section>
  );
}
