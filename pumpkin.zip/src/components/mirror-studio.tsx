"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import {
  ArrowUpRight,
  Copy,
  ExternalLink,
  Loader2,
  Plus,
  RefreshCw,
  Trash2,
  Waypoints,
} from "lucide-react";
import { useSettings } from "@/components/providers";
import type { MirrorRecord } from "@/lib/types";

const TARGETS = [
  { value: "/", label: "Browser home" },
  { value: "/activities", label: "Study break" },
  { value: "/streamx", label: "StreamX redirect" },
  { value: "/chat", label: "Chatroom" },
  { value: "/settings", label: "Settings" },
];

export function MirrorStudio() {
  const { notify } = useSettings();
  const [label, setLabel] = useState("");
  const [target, setTarget] = useState("/");
  const [mirrors, setMirrors] = useState<MirrorRecord[]>([]);
  const [origin, setOrigin] = useState("");
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/mirrors", { cache: "no-store" });
      const data = (await response.json()) as { mirrors?: MirrorRecord[] };
      if (data.mirrors) setMirrors(data.mirrors);
    } catch {
      notify("Mirror registry is offline");
    } finally {
      setLoading(false);
    }
  }, [notify]);

  useEffect(() => {
    setOrigin(window.location.origin);
    void load();
  }, [load]);

  const mirrorUrl = (code: string) => `${origin || ""}/m/${code}`;

  const create = async () => {
    setCreating(true);
    try {
      const response = await fetch("/api/mirrors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ label: label.trim() || `pumpkin ${target}`, target }),
      });
      const data = (await response.json()) as { mirror?: MirrorRecord; error?: string };
      if (!response.ok || !data.mirror) {
        notify(data.error ?? "Could not make that mirror");
        return;
      }
      setMirrors((previous) => [data.mirror as MirrorRecord, ...previous]);
      setLabel("");
      notify("Mirror created — link copied to your clipboard");
      try {
        await navigator.clipboard.writeText(`${window.location.origin}/m/${data.mirror.code}`);
      } catch {
        // Clipboard permission is optional.
      }
    } catch {
      notify("Could not make that mirror");
    } finally {
      setCreating(false);
    }
  };

  const copy = async (code: string) => {
    try {
      await navigator.clipboard.writeText(mirrorUrl(code));
      setCopied(code);
      notify("Mirror link copied");
      setTimeout(() => setCopied(null), 1800);
    } catch {
      notify("Clipboard blocked — select the link manually");
    }
  };

  const remove = async (mirror: MirrorRecord) => {
    setMirrors((previous) => previous.filter((item) => item.id !== mirror.id));
    try {
      await fetch(`/api/mirrors?id=${mirror.id}`, { method: "DELETE" });
      notify("Mirror retired");
    } catch {
      notify("Could not retire that mirror");
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
      <section className="glass rounded-2xl p-4">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl border border-[var(--accent-line)] bg-[var(--accent-soft)] text-[var(--accent)]">
            <Waypoints className="h-4 w-4" />
          </span>
          <div>
            <h3 className="text-sm font-bold text-pumpkin-50">Mirror generator</h3>
            <p className="text-[0.66rem] text-pumpkin-50/40">Same site, a fresh address</p>
          </div>
        </div>

        <div className="mt-4 space-y-3">
          <label className="block">
            <span className="section-label">label</span>
            <input
              value={label}
              onChange={(event) => setLabel(event.target.value)}
              placeholder="Study mirror"
              className="field mt-1.5"
              maxLength={60}
            />
          </label>

          <label className="block">
            <span className="section-label">starting point</span>
            <select
              value={target}
              onChange={(event) => setTarget(event.target.value)}
              className="field mt-1.5 appearance-none"
            >
              {TARGETS.map((item) => (
                <option key={item.value} value={item.value} className="bg-[#140d09]">
                  {item.label}
                </option>
              ))}
            </select>
          </label>

          <button
            type="button"
            onClick={create}
            disabled={creating}
            className="btn-accent flex w-full items-center justify-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-bold disabled:opacity-60"
          >
            {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            {creating ? "Forging link" : "Generate mirror link"}
          </button>

          <div className="rounded-xl border border-white/[0.07] bg-black/25 p-3 text-[0.68rem] leading-relaxed text-pumpkin-50/45">
            <p className="mb-1 flex items-center gap-1.5 font-semibold text-pumpkin-50/70">
              <RefreshCw className="h-3 w-3 text-[var(--accent)]" /> how it works
            </p>
            Each mirror is a short random path on this same app —{" "}
            <code className="rounded bg-black/40 px-1">/m/abc1234</code>. It renders the identical
            pumpkin interface with a mirror ribbon and its own visit counter, so you can hand out a
            link that does not look like the usual one.
          </div>
        </div>
      </section>

      <section className="glass rounded-2xl p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-bold text-pumpkin-50">Your mirrors</h3>
            <p className="text-[0.66rem] text-pumpkin-50/40">
              {mirrors.length} link{mirrors.length === 1 ? "" : "s"} · visits counted per open
            </p>
          </div>
          <button
            type="button"
            onClick={() => void load()}
            className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.68rem] font-semibold text-pumpkin-50/70"
          >
            <RefreshCw className="h-3 w-3" /> Refresh
          </button>
        </div>

        {loading ? (
          <div className="mt-6 flex items-center justify-center gap-2 py-10 text-xs text-pumpkin-50/40">
            <Loader2 className="h-4 w-4 animate-spin" /> loading registry
          </div>
        ) : mirrors.length === 0 ? (
          <div className="mt-4 rounded-xl border border-dashed border-white/10 px-4 py-10 text-center">
            <Waypoints className="mx-auto h-6 w-6 text-pumpkin-50/20" />
            <p className="mt-2 text-xs text-pumpkin-50/45">No mirrors yet. Generate your first one.</p>
          </div>
        ) : (
          <ul className="mt-3 space-y-2">
            {mirrors.map((mirror) => (
              <li
                key={mirror.id}
                className="rounded-xl border border-white/[0.07] bg-black/25 p-3 transition hover:border-[var(--accent-line)]"
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="truncate text-sm font-semibold text-pumpkin-50">{mirror.label}</p>
                      <span className="rounded-full border border-white/10 bg-white/[0.05] px-1.5 py-0.5 text-[0.58rem] text-pumpkin-50/45">
                        {mirror.visits} visit{mirror.visits === 1 ? "" : "s"}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center gap-1.5">
                      <code className="truncate text-[0.68rem] text-pumpkin-50/45">
                        {mirrorUrl(mirror.code)}
                      </code>
                      <span className="shrink-0 rounded border border-white/10 px-1 py-0.5 text-[0.56rem] uppercase tracking-wider text-pumpkin-50/30">
                        {mirror.target}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => void copy(mirror.code)}
                      className="btn-ghost flex items-center gap-1 rounded-lg px-2 py-1.5 text-[0.66rem] font-semibold text-pumpkin-50/75"
                    >
                      <Copy className="h-3 w-3" />
                      {copied === mirror.code ? "Copied" : "Copy"}
                    </button>
                    <Link
                      href={`/m/${mirror.code}`}
                      target="_blank"
                      className="btn-ghost flex items-center gap-1 rounded-lg px-2 py-1.5 text-[0.66rem] font-semibold text-pumpkin-50/75"
                    >
                      <ExternalLink className="h-3 w-3" /> Open
                    </Link>
                    <button
                      type="button"
                      onClick={() => void remove(mirror)}
                      aria-label={`Delete ${mirror.label}`}
                      className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 bg-white/[0.04] text-pumpkin-50/40 transition hover:border-red-400/40 hover:text-red-300"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}

        <div className="mt-4 flex items-center justify-between gap-2 rounded-xl border border-[var(--accent-line)] bg-[var(--accent-soft)] px-3 py-2.5 text-[0.7rem] text-pumpkin-50/70">
          <span>Want the browser at a mirror address right now?</span>
          <Link href="/" className="flex items-center gap-1 font-semibold text-[var(--accent)] hover:underline">
            Open home <ArrowUpRight className="h-3 w-3" />
          </Link>
        </div>
      </section>
    </div>
  );
}
