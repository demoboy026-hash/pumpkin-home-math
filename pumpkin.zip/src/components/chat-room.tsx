"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Loader2, MessageSquare, Send, User, Wifi } from "lucide-react";
import { NICKNAME_KEY } from "@/lib/settings";
import { useAccount } from "@/lib/account";
import { AvatarView } from "@/components/avatar-view";
import { CHAT_ROOMS, type ChatMessage, type ChatRoomId } from "@/lib/types";

function clock(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export function ChatRoom() {
  const { user } = useAccount();
  const [room, setRoom] = useState<ChatRoomId>("main");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [nickname, setNickname] = useState("");
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const load = useCallback(async (target: ChatRoomId, silent = false) => {
    if (!silent) setLoading(true);
    try {
      const response = await fetch(`/api/chat?room=${target}`, { cache: "no-store" });
      const data = (await response.json()) as { messages?: ChatMessage[]; error?: string };
      if (!response.ok) throw new Error(data.error ?? "Chat unavailable");
      setMessages(data.messages ?? []);
      setError(null);
    } catch {
      if (!silent) setError("Could not reach the room. It will retry automatically.");
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(NICKNAME_KEY);
      if (stored) {
        setNickname(stored);
      } else if (user) {
        setNickname(user.displayName);
      }
    } catch {
      // ignore storage errors
    }
  }, [user]);

  useEffect(() => {
    void load(room);
    const interval = setInterval(() => void load(room, true), 4500);
    return () => clearInterval(interval);
  }, [load, room]);

  useEffect(() => {
    const node = scrollRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages]);

  const persistNickname = (value: string) => {
    setNickname(value);
    try {
      window.localStorage.setItem(NICKNAME_KEY, value);
    } catch {
      // ignore storage errors
    }
  };

  const send = async () => {
    const body = text.trim();
    if (!body || sending) return;
    const author = nickname.trim().slice(0, 24) || "anonymous";
    const tempId = -Date.now();
    const optimistic: ChatMessage = {
      id: tempId,
      room,
      author,
      body,
      createdAt: new Date().toISOString(),
    };

    setMessages((previous) => [...previous, optimistic]);
    setText("");
    setSending(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ room, author, body }),
      });
      const data = (await response.json()) as { message?: ChatMessage; error?: string };
      if (!response.ok || !data.message) throw new Error(data.error ?? "Message failed");
      setMessages((previous) =>
        previous.map((message) => (message.id === tempId ? (data.message as ChatMessage) : message)),
      );
      setError(null);
    } catch {
      setMessages((previous) => previous.filter((message) => message.id !== tempId));
      setText(body);
      setError("That message did not send. Try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <section className="glass overflow-hidden rounded-2xl">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-black/30 px-3 py-2.5">
        <div className="flex flex-wrap items-center gap-1.5">
          {CHAT_ROOMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setRoom(item.id);
                setMessages([]);
              }}
              className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[0.72rem] font-semibold transition ${
                room === item.id
                  ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                  : "border-transparent text-pumpkin-50/55 hover:bg-white/5 hover:text-pumpkin-50"
              }`}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: item.dot }} />
              {item.name}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/35 px-2 py-1">
          <User className="h-3 w-3 text-pumpkin-50/35" />
          <input
            value={nickname}
            onChange={(event) => persistNickname(event.target.value)}
            placeholder="your name"
            maxLength={24}
            aria-label="Your display name"
            className="w-24 bg-transparent text-[0.7rem] text-pumpkin-50 outline-none placeholder:text-pumpkin-50/30"
          />
          <span className="flex items-center gap-1 text-[0.58rem] text-emerald-300/70">
            <Wifi className="h-2.5 w-2.5" /> live
          </span>
          {user ? (
            <span
              title={`Signed in as @${user.username}`}
              className="flex items-center gap-1 rounded-md border border-[var(--accent-line)] bg-[var(--accent-soft)] px-1.5 py-0.5 text-[0.56rem] font-semibold text-pumpkin-50/80"
            >
              @{user.username}
            </span>
          ) : null}
        </div>
      </div>

      <div ref={scrollRef} className="h-[420px] space-y-2.5 overflow-y-auto bg-black/20 px-3 py-3 sm:h-[460px]">
        {loading ? (
          <div className="flex h-full items-center justify-center gap-2 text-xs text-pumpkin-50/40">
            <Loader2 className="h-4 w-4 animate-spin" /> joining the room
          </div>
        ) : messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <MessageSquare className="h-6 w-6 text-pumpkin-50/20" />
            <p className="mt-2 text-sm font-semibold text-pumpkin-50/60">Quiet in here</p>
            <p className="mt-1 max-w-[220px] text-[0.7rem] text-pumpkin-50/35">
              Be the first to say something in {CHAT_ROOMS.find((item) => item.id === room)?.name}.
            </p>
          </div>
        ) : (
          messages.map((message) => {
            const mine =
              nickname.trim().length > 0 &&
              message.author.toLowerCase() === nickname.trim().toLowerCase();
            const stableAuthor = message.author.toLowerCase() === "pumpkin";
            return (
              <div key={message.id} className={`flex gap-2 ${mine ? "flex-row-reverse" : ""}`}>
                <span className="mt-0.5">
                  <AvatarView
                    avatar={message.avatar ?? JSON.stringify({ kind: "initials" })}
                    name={message.author}
                    size={28}
                    ring={stableAuthor || Boolean(message.avatar)}
                    effect={message.authorEffect ?? (stableAuthor ? "glow" : "none")}
                  />
                </span>
                <div className={`max-w-[82%] ${mine ? "text-right" : ""}`}>
                  <div className={`flex items-center gap-1.5 text-[0.6rem] text-pumpkin-50/35 ${mine ? "justify-end" : ""}`}>
                    <span className="font-semibold text-pumpkin-50/60">{mine ? "you" : message.author}</span>
                    <span>{clock(message.createdAt)}</span>
                  </div>
                  <p
                    className={`mt-1 inline-block whitespace-pre-wrap break-words rounded-xl border px-2.5 py-1.5 text-left text-[0.78rem] leading-relaxed ${
                      mine
                        ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                        : "border-white/[0.07] bg-white/[0.04] text-pumpkin-50/80"
                    }`}
                  >
                    {message.body}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>

      {error ? (
        <p className="border-t border-red-400/20 bg-red-500/10 px-3 py-1.5 text-[0.68rem] text-red-200/80">
          {error}
        </p>
      ) : null}

      <form
        onSubmit={(event) => {
          event.preventDefault();
          void send();
        }}
        className="flex items-center gap-2 border-t border-white/10 bg-black/30 px-3 py-2.5"
      >
        <input
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder={`Message the ${CHAT_ROOMS.find((item) => item.id === room)?.name.toLowerCase()} room…`}
          maxLength={600}
          aria-label="Message"
          className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/45 px-3 py-2.5 text-xs text-pumpkin-50 outline-none transition placeholder:text-pumpkin-50/30 focus:border-[var(--accent-line)]"
        />
        <span className="hidden text-[0.6rem] text-pumpkin-50/25 sm:block">{text.length}/600</span>
        <button
          type="submit"
          disabled={sending || !text.trim()}
          className="btn-accent flex items-center gap-1.5 rounded-xl px-3.5 py-2.5 text-xs font-bold disabled:opacity-50"
        >
          {sending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
          Send
        </button>
      </form>
    </section>
  );
}
