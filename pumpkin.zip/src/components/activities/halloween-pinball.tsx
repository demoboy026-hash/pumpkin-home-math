"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Flame, Pause, Play, RotateCcw, Sparkles, Trophy } from "lucide-react";

const W = 360;
const H = 580;
const BALL_R = 7;
const GRAVITY = 0.26;
const MAX_SPEED = 24;
const SUB_STEPS = 3;
const HIGH_KEY = "pumpkin.highscore.pinball";
const BALL_REST = { x: 323, y: 528 };

type Point = { x: number; y: number };
type BallState = { x: number; y: number; vx: number; vy: number; trail: Point[] };
type Seg = {
  a: Point;
  b: Point;
  thickness: number;
  restitution: number;
  kick: number;
  sling?: boolean;
};
type BumperKind = "pumpkin" | "ghost" | "bat" | "skull";
type Bumper = { x: number; y: number; r: number; kind: BumperKind; flash: number };
type Target = { x: number; y: number; w: number; h: number; alive: boolean; flash: number };
type Popup = { x: number; y: number; text: string; life: number; tone: string };
type Flipper = {
  pivot: Point;
  length: number;
  rest: number;
  active: number;
  angle: number;
  omega: number;
  engaged: boolean;
};
type Mode = "idle" | "launch" | "play" | "paused" | "over";

const WALLS: Seg[] = [
  { a: { x: 16, y: 120 }, b: { x: 16, y: 470 }, thickness: 4, restitution: 0.42, kick: 0 },
  { a: { x: 16, y: 470 }, b: { x: 74, y: 516 }, thickness: 4, restitution: 0.42, kick: 0 },
  { a: { x: 302, y: 120 }, b: { x: 302, y: 540 }, thickness: 4, restitution: 0.42, kick: 0 },
  { a: { x: 302, y: 470 }, b: { x: 246, y: 516 }, thickness: 4, restitution: 0.42, kick: 0 },
  { a: { x: 16, y: 120 }, b: { x: 100, y: 44 }, thickness: 4, restitution: 0.42, kick: 0 },
  { a: { x: 100, y: 44 }, b: { x: 240, y: 44 }, thickness: 4, restitution: 0.42, kick: 0 },
  { a: { x: 240, y: 44 }, b: { x: 300, y: 58 }, thickness: 4, restitution: 0.42, kick: 0 },
  { a: { x: 300, y: 58 }, b: { x: 344, y: 90 }, thickness: 4, restitution: 0.5, kick: 0 },
  { a: { x: 344, y: 90 }, b: { x: 344, y: 540 }, thickness: 4, restitution: 0.42, kick: 0 },
  { a: { x: 302, y: 540 }, b: { x: 344, y: 540 }, thickness: 4, restitution: 0.2, kick: 0 },
];

const SLINGS: Seg[] = [
  { a: { x: 36, y: 418 }, b: { x: 92, y: 452 }, thickness: 6, restitution: 0.95, kick: 5.4, sling: true },
  { a: { x: 282, y: 418 }, b: { x: 226, y: 452 }, thickness: 6, restitution: 0.95, kick: 5.4, sling: true },
];

const BUMPER_LAYOUT: { x: number; y: number; r: number; kind: BumperKind }[] = [
  { x: 158, y: 118, r: 17, kind: "bat" },
  { x: 104, y: 206, r: 20, kind: "pumpkin" },
  { x: 212, y: 190, r: 19, kind: "ghost" },
  { x: 254, y: 274, r: 16, kind: "skull" },
];

const TARGET_LAYOUT = [
  { x: 34, y: 336, w: 52, h: 14 },
  { x: 126, y: 336, w: 52, h: 14 },
  { x: 218, y: 336, w: 52, h: 14 },
];

function makeFlippers(): { left: Flipper; right: Flipper } {
  return {
    left: {
      pivot: { x: 96, y: 498 },
      length: 64,
      rest: 0.55,
      active: -0.55,
      angle: 0.55,
      omega: 0,
      engaged: false,
    },
    right: {
      pivot: { x: 224, y: 498 },
      length: 64,
      rest: Math.PI - 0.55,
      active: Math.PI + 0.55,
      angle: Math.PI - 0.55,
      omega: 0,
      engaged: false,
    },
  };
}

function closestOnSegment(px: number, py: number, a: Point, b: Point): Point {
  const abx = b.x - a.x;
  const aby = b.y - a.y;
  const lengthSq = abx * abx + aby * aby || 1;
  const t = Math.max(0, Math.min(1, ((px - a.x) * abx + (py - a.y) * aby) / lengthSq));
  return { x: a.x + abx * t, y: a.y + aby * t };
}

/* ------------------------------- drawing ------------------------------- */

function drawPumpkin(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
  ctx.save();
  ctx.translate(cx, cy);
  const grad = ctx.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.15, 0, 0, r);
  grad.addColorStop(0, "#ffc98a");
  grad.addColorStop(0.55, "#ff7a18");
  grad.addColorStop(1, "#a83a05");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.ellipse(0, 1, r, r * 0.92, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(96,32,0,0.45)";
  ctx.lineWidth = 1.2;
  for (const offset of [-0.48, 0, 0.48]) {
    ctx.beginPath();
    ctx.ellipse(offset * r, 1, r * 0.3, r * 0.86, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.fillStyle = "#6baa3a";
  ctx.beginPath();
  ctx.roundRect(-2.5, -r - 5, 5, 8, 2);
  ctx.fill();
  ctx.fillStyle = "#2a1206";
  ctx.beginPath();
  ctx.moveTo(-r * 0.52, -r * 0.12);
  ctx.lineTo(-r * 0.16, -r * 0.12);
  ctx.lineTo(-r * 0.34, r * 0.18);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(r * 0.52, -r * 0.12);
  ctx.lineTo(r * 0.16, -r * 0.12);
  ctx.lineTo(r * 0.34, r * 0.18);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-r * 0.36, r * 0.32);
  ctx.lineTo(-r * 0.15, r * 0.48);
  ctx.lineTo(0, r * 0.32);
  ctx.lineTo(r * 0.15, r * 0.48);
  ctx.lineTo(r * 0.36, r * 0.32);
  ctx.lineWidth = 2;
  ctx.strokeStyle = "#2a1206";
  ctx.lineCap = "round";
  ctx.stroke();
  ctx.restore();
}

function drawGhost(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
  ctx.save();
  ctx.translate(cx, cy);
  const grad = ctx.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.15, 0, 0, r * 1.1);
  grad.addColorStop(0, "#f6f1ff");
  grad.addColorStop(0.7, "#cbb8ea");
  grad.addColorStop(1, "#7c5fa8");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(0, -r * 0.12, r * 0.88, Math.PI, 0);
  ctx.lineTo(r * 0.88, r * 0.5);
  for (let index = 0; index < 3; index += 1) {
    const step = (r * 1.76) / 3;
    const start = r * 0.88 - index * step;
    ctx.quadraticCurveTo(start - step / 2, r * 0.9, start - step, r * 0.5);
  }
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#2b1b3d";
  ctx.beginPath();
  ctx.ellipse(-r * 0.3, -r * 0.12, r * 0.15, r * 0.22, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(r * 0.3, -r * 0.12, r * 0.15, r * 0.22, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(0, r * 0.28, r * 0.16, r * 0.12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawBat(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
  ctx.save();
  ctx.translate(cx, cy);
  const grad = ctx.createRadialGradient(-r * 0.3, -r * 0.4, r * 0.1, 0, 0, r);
  grad.addColorStop(0, "#c084fc");
  grad.addColorStop(0.6, "#8b3ddb");
  grad.addColorStop(1, "#4c1d80");
  ctx.fillStyle = grad;
  for (const side of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(side * r * 0.25, -r * 0.15);
    ctx.quadraticCurveTo(side * r * 1.5, -r * 0.9, side * r * 1.62, r * 0.05);
    ctx.quadraticCurveTo(side * r * 1.15, -r * 0.05, side * r * 0.95, r * 0.4);
    ctx.quadraticCurveTo(side * r * 0.7, r * 0.02, side * r * 0.3, r * 0.32);
    ctx.closePath();
    ctx.fill();
  }
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 0.55, r * 0.62, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#2b0f4a";
  ctx.beginPath();
  ctx.moveTo(-r * 0.4, -r * 0.5);
  ctx.lineTo(-r * 0.18, -r * 0.22);
  ctx.lineTo(-r * 0.5, -r * 0.1);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(r * 0.4, -r * 0.5);
  ctx.lineTo(r * 0.18, -r * 0.22);
  ctx.lineTo(r * 0.5, -r * 0.1);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#ffd166";
  ctx.beginPath();
  ctx.arc(-r * 0.2, -r * 0.05, r * 0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(r * 0.2, -r * 0.05, r * 0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawSkull(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
  ctx.save();
  ctx.translate(cx, cy);
  const grad = ctx.createRadialGradient(-r * 0.3, -r * 0.4, r * 0.1, 0, 0, r);
  grad.addColorStop(0, "#fff6e8");
  grad.addColorStop(0.75, "#d9c9b6");
  grad.addColorStop(1, "#8f7f6e");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(0, -r * 0.1, r * 0.82, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.roundRect(-r * 0.42, r * 0.35, r * 0.84, r * 0.5, 3);
  ctx.fill();
  ctx.fillStyle = "#3b1f2a";
  ctx.beginPath();
  ctx.ellipse(-r * 0.3, -r * 0.14, r * 0.22, r * 0.26, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(r * 0.3, -r * 0.14, r * 0.22, r * 0.26, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(0, r * 0.1);
  ctx.lineTo(-r * 0.12, r * 0.28);
  ctx.lineTo(r * 0.12, r * 0.28);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "#3b1f2a";
  ctx.lineWidth = 1.4;
  for (const offset of [-r * 0.2, 0, r * 0.2]) {
    ctx.beginPath();
    ctx.moveTo(offset, r * 0.5);
    ctx.lineTo(offset, r * 0.8);
    ctx.stroke();
  }
  ctx.restore();
}

const BUMPER_PAINTERS: Record<BumperKind, (ctx: CanvasRenderingContext2D, x: number, y: number, r: number) => void> = {
  pumpkin: drawPumpkin,
  ghost: drawGhost,
  bat: drawBat,
  skull: drawSkull,
};

/* ------------------------------- component ------------------------------- */

export function HalloweenPinball() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [high, setHigh] = useState(0);
  const [hud, setHud] = useState({ score: 0, balls: 3, combo: 0, multiplier: 1 });
  const [mode, setMode] = useState<Mode>("idle");

  const ballRef = useRef<BallState>({ ...BALL_REST, vx: 0, vy: 0, trail: [] });
  const flippersRef = useRef(makeFlippers());
  const bumpersRef = useRef<Bumper[]>(
    BUMPER_LAYOUT.map((item) => ({ ...item, flash: 0 })),
  );
  const targetsRef = useRef<Target[]>(TARGET_LAYOUT.map((item) => ({ ...item, alive: true, flash: 0 })));
  const popupsRef = useRef<Popup[]>([]);
  const modeRef = useRef<Mode>("idle");
  const scoreRef = useRef(0);
  const ballsRef = useRef(3);
  const highRef = useRef(0);
  const comboRef = useRef(0);
  const comboTimerRef = useRef(0);
  const chargeRef = useRef(0);
  const launchPowerRef = useRef(19);
  const chargingRef = useRef(false);
  const stuckRef = useRef(0);
  const timeRef = useRef(0);
  const targetRespawnRef = useRef(0);
  const targetRunRef = useRef(0);

  const resetMatch = useCallback(() => {
    const ball = ballRef.current;
    ball.x = BALL_REST.x;
    ball.y = BALL_REST.y;
    ball.vx = 0;
    ball.vy = 0;
    ball.trail = [];
    comboTimerRef.current = 0;
    chargeRef.current = 0;
    chargingRef.current = false;
    stuckRef.current = 0;
    targetRespawnRef.current = 0;
    targetRunRef.current = 0;
    flippersRef.current.left.engaged = false;
    flippersRef.current.right.engaged = false;
    flippersRef.current.left.angle = flippersRef.current.left.rest;
    flippersRef.current.right.angle = flippersRef.current.right.rest;
    bumpersRef.current.forEach((bumper) => {
      bumper.flash = 0;
    });
    targetsRef.current.forEach((target) => {
      target.alive = true;
      target.flash = 0;
    });
    popupsRef.current = [];
    scoreRef.current = 0;
    ballsRef.current = 3;
    comboRef.current = 0;
    modeRef.current = "launch";
    setMode("launch");
    setHud({ score: 0, balls: 3, combo: 0, multiplier: 1 });
  }, []);

  const launch = useCallback(() => {
    const ball = ballRef.current;
    const power = 16 + chargeRef.current * 7;
    launchPowerRef.current = power;
    ball.x = BALL_REST.x;
    ball.y = BALL_REST.y;
    ball.vx = -1.8;
    ball.vy = -power;
    ball.trail = [];
    chargeRef.current = 0;
    chargingRef.current = false;
    stuckRef.current = 0;
    modeRef.current = "play";
    setMode("play");
  }, []);

  const pressFlipper = useCallback((side: "left" | "right", down: boolean) => {
    flippersRef.current[side].engaged = down;
  }, []);

  const startCharge = useCallback(() => {
    if (modeRef.current === "launch") chargingRef.current = true;
  }, []);

  const endCharge = useCallback(() => {
    if (modeRef.current === "launch" && chargingRef.current) launch();
  }, [launch]);

  const togglePause = useCallback(() => {
    if (modeRef.current === "play") {
      modeRef.current = "paused";
      setMode("paused");
    } else if (modeRef.current === "paused") {
      modeRef.current = "play";
      setMode("play");
    }
  }, []);

  useEffect(() => {
    try {
      const stored = Number(window.localStorage.getItem(HIGH_KEY) ?? "0");
      if (Number.isFinite(stored)) {
        highRef.current = stored;
        setHigh(stored);
      }
    } catch {
      highRef.current = 0;
    }
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let frame = 0;
    let last = performance.now();

    const syncHud = () => {
      setHud({
        score: scoreRef.current,
        balls: ballsRef.current,
        combo: comboRef.current,
        multiplier: Math.min(5, 1 + Math.floor(comboRef.current / 4)),
      });
    };

    const addScore = (base: number, x: number, y: number, tone = "#ffd6a5") => {
      const multiplier = Math.min(5, 1 + Math.floor(comboRef.current / 4));
      const gained = base * multiplier;
      scoreRef.current += gained;
      popupsRef.current.push({
        x,
        y,
        text: `+${gained}${multiplier > 1 ? ` ×${multiplier}` : ""}`,
        life: 1,
        tone,
      });
      if (popupsRef.current.length > 14) popupsRef.current.shift();
    };

    const registerHit = () => {
      comboRef.current += 1;
      comboTimerRef.current = 150;
    };

    const resetToLane = () => {
      const ball = ballRef.current;
      ball.x = BALL_REST.x;
      ball.y = BALL_REST.y;
      ball.vx = 0;
      ball.vy = 0;
      ball.trail = [];
      chargeRef.current = 0;
      modeRef.current = "launch";
      setMode("launch");
    };

    const drain = () => {
      ballsRef.current -= 1;
      popupsRef.current.push({
        x: 160,
        y: 470,
        text: "BALL LOST",
        life: 1.4,
        tone: "#fca5a5",
      });
      if (ballsRef.current <= 0) {
        ballsRef.current = 0;
        modeRef.current = "over";
        setMode("over");
        if (scoreRef.current > highRef.current) {
          highRef.current = scoreRef.current;
          setHigh(scoreRef.current);
          try {
            window.localStorage.setItem(HIGH_KEY, String(scoreRef.current));
          } catch {
            // ignore storage failures
          }
        }
      } else {
        resetToLane();
      }
      comboRef.current = 0;
      syncHud();
    };

    const collideCircle = (cx: number, cy: number, cr: number, restitution: number, kick: number) => {
      const ball = ballRef.current;
      const dx = ball.x - cx;
      const dy = ball.y - cy;
      const distance = Math.hypot(dx, dy);
      const minimum = cr + BALL_R;
      if (distance >= minimum || distance === 0) return false;
      const nx = dx / distance;
      const ny = dy / distance;
      ball.x = cx + nx * minimum;
      ball.y = cy + ny * minimum;
      const normal = ball.vx * nx + ball.vy * ny;
      if (normal < 0) {
        ball.vx -= (1 + restitution) * normal * nx;
        ball.vy -= (1 + restitution) * normal * ny;
      }
      ball.vx += nx * kick;
      ball.vy += ny * kick;
      return true;
    };

    const collideSegment = (segment: Seg) => {
      const ball = ballRef.current;
      const point = closestOnSegment(ball.x, ball.y, segment.a, segment.b);
      const dx = ball.x - point.x;
      const dy = ball.y - point.y;
      const distance = Math.hypot(dx, dy);
      const minimum = segment.thickness + BALL_R;
      if (distance >= minimum) return false;
      const nx = distance === 0 ? 0 : dx / distance;
      const ny = distance === 0 ? -1 : dy / distance;
      ball.x = point.x + nx * minimum;
      ball.y = point.y + ny * minimum;
      const normal = ball.vx * nx + ball.vy * ny;
      if (normal < 0) {
        ball.vx -= (1 + segment.restitution) * normal * nx;
        ball.vy -= (1 + segment.restitution) * normal * ny;
      }
      ball.vx += nx * segment.kick;
      ball.vy += ny * segment.kick;
      return true;
    };

    const collideRect = (target: Target) => {
      const ball = ballRef.current;
      const cx = Math.max(target.x, Math.min(ball.x, target.x + target.w));
      const cy = Math.max(target.y, Math.min(ball.y, target.y + target.h));
      const dx = ball.x - cx;
      const dy = ball.y - cy;
      const distance = Math.hypot(dx, dy);
      if (distance >= BALL_R) return false;
      const nx = distance === 0 ? 0 : dx / distance;
      const ny = distance === 0 ? -1 : dy / distance;
      ball.x = cx + nx * BALL_R;
      ball.y = cy + ny * BALL_R;
      const normal = ball.vx * nx + ball.vy * ny;
      if (normal < 0) {
        ball.vx -= 1.5 * normal * nx;
        ball.vy -= 1.5 * normal * ny;
      }
      return true;
    };

    const collideFlipper = (flipper: Flipper) => {
      const ball = ballRef.current;
      const tip = {
        x: flipper.pivot.x + Math.cos(flipper.angle) * flipper.length,
        y: flipper.pivot.y + Math.sin(flipper.angle) * flipper.length,
      };
      const point = closestOnSegment(ball.x, ball.y, flipper.pivot, tip);
      const dx = ball.x - point.x;
      const dy = ball.y - point.y;
      const distance = Math.hypot(dx, dy);
      const minimum = 6 + BALL_R;
      if (distance >= minimum) return;
      const nx = distance === 0 ? 0 : dx / distance;
      const ny = distance === 0 ? -1 : dy / distance;
      ball.x = point.x + nx * minimum;
      ball.y = point.y + ny * minimum;
      const rx = point.x - flipper.pivot.x;
      const ry = point.y - flipper.pivot.y;
      const surfaceX = -flipper.omega * ry;
      const surfaceY = flipper.omega * rx;
      const normal = ball.vx * nx + ball.vy * ny;
      if (normal < 0) {
        ball.vx -= 1.35 * normal * nx;
        ball.vy -= 1.35 * normal * ny;
      }
      ball.vx += surfaceX * 0.9 + nx * 1.1;
      ball.vy += surfaceY * 0.9 + ny * 1.1;
    };

    const updateFlipper = (flipper: Flipper, dt: number) => {
      const target = flipper.engaged ? flipper.active : flipper.rest;
      const previous = flipper.angle;
      const speed = (flipper.engaged ? 0.34 : 0.2) * dt;
      const difference = target - flipper.angle;
      if (Math.abs(difference) <= speed) flipper.angle = target;
      else flipper.angle += Math.sign(difference) * speed;
      flipper.omega = (flipper.angle - previous) / dt;
    };

    const step = (dt: number) => {
      const ball = ballRef.current;
      const state = modeRef.current;

      if (state === "launch" && chargingRef.current) {
        chargeRef.current = Math.min(1, chargeRef.current + 0.016 * dt);
      }

      if (state !== "play") {
        if (state === "over" || state === "idle") {
          ball.trail = [];
        }
        return;
      }

      updateFlipper(flippersRef.current.left, dt);
      updateFlipper(flippersRef.current.right, dt);

      ball.vy += GRAVITY * dt;
      ball.vx *= 0.9993;
      ball.vy *= 0.9993;
      ball.x += ball.vx * dt;
      ball.y += ball.vy * dt;

      if (ball.x > 302 && ball.y < 132) {
        const exitSpeed = 8 + launchPowerRef.current * 0.32;
        ball.x = 288;
        ball.y = 104;
        ball.vx = -exitSpeed;
        ball.vy = 1.6;
      }

      for (const wall of WALLS) collideSegment(wall);

      for (const sling of SLINGS) {
        if (collideSegment(sling)) {
          registerHit();
          addScore(50, sling.a.x + 12, sling.a.y + 18, "#fdba74");
        }
      }

      for (const bumper of bumpersRef.current) {
        if (collideCircle(bumper.x, bumper.y, bumper.r, 0.82, 5.6)) {
          bumper.flash = 1;
          registerHit();
          addScore(bumper.kind === "bat" ? 150 : 100, bumper.x, bumper.y - bumper.r - 6);
        }
      }

      for (const target of targetsRef.current) {
        if (!target.alive) continue;
        if (collideRect(target)) {
          target.alive = false;
          target.flash = 1;
          targetRunRef.current += 1;
          registerHit();
          addScore(250, target.x + target.w / 2, target.y - 8, "#fde68a");
          if (targetRunRef.current >= targetsRef.current.length) {
            addScore(1500, 160, 300, "#f0abfc");
            targetRespawnRef.current = 90;
            targetRunRef.current = 0;
          }
        }
      }

      if (targetRespawnRef.current > 0) {
        targetRespawnRef.current -= dt;
        if (targetRespawnRef.current <= 0) {
          targetsRef.current.forEach((target) => {
            target.alive = true;
          });
        }
      }

      collideFlipper(flippersRef.current.left);
      collideFlipper(flippersRef.current.right);

      const speed = Math.hypot(ball.vx, ball.vy);
      if (speed > MAX_SPEED) {
        const scale = MAX_SPEED / speed;
        ball.vx *= scale;
        ball.vy *= scale;
      }

      if (speed < 0.45) {
        stuckRef.current += dt;
        if (stuckRef.current > 220) {
          ball.vx += (Math.random() - 0.5) * 3.4;
          ball.vy -= 2.2;
          stuckRef.current = 0;
        }
      } else {
        stuckRef.current = 0;
      }

      if (ball.x > 306 && ball.y > 498 && speed < 0.7) {
        resetToLane();
        return;
      }

      if (ball.y > H - 14) {
        if (ball.x > 306) resetToLane();
        else drain();
      }
    };

    const draw = () => {
      const ball = ballRef.current;
      const time = timeRef.current;

      const background = ctx.createLinearGradient(0, 0, 0, H);
      background.addColorStop(0, "#0a0610");
      background.addColorStop(0.55, "#150b16");
      background.addColorStop(1, "#1d0a08");
      ctx.fillStyle = background;
      ctx.fillRect(0, 0, W, H);

      ctx.save();
      ctx.globalAlpha = 0.55;
      const moon = ctx.createRadialGradient(158, 96, 8, 158, 96, 96);
      moon.addColorStop(0, "rgba(253,230,180,0.22)");
      moon.addColorStop(1, "rgba(253,230,180,0)");
      ctx.fillStyle = moon;
      ctx.fillRect(0, 0, W, 260);
      ctx.restore();

      ctx.save();
      ctx.globalAlpha = 0.16;
      ctx.fillStyle = "#c084fc";
      for (let index = 0; index < 3; index += 1) {
        const drift = (time * (0.14 + index * 0.05) + index * 120) % (W + 160) - 80;
        ctx.beginPath();
        ctx.ellipse(drift, 250 + index * 60, 90, 16, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      ctx.save();
      ctx.strokeStyle = "rgba(255,122,24,0.1)";
      ctx.lineWidth = 1;
      for (let y = 70; y < H; y += 26) {
        ctx.beginPath();
        ctx.moveTo(12, y);
        ctx.lineTo(348, y);
        ctx.stroke();
      }
      ctx.restore();

      const bats = [
        { x: 60, y: 92, s: 0.7 },
        { x: 268, y: 128, s: 0.55 },
        { x: 206, y: 300, s: 0.45 },
      ];
      ctx.save();
      ctx.fillStyle = "rgba(196,132,252,0.35)";
      bats.forEach((bat, index) => {
        const bob = Math.sin(time * 0.03 + index) * 6;
        ctx.beginPath();
        ctx.ellipse(bat.x, bat.y + bob, 9 * bat.s, 4 * bat.s, 0, 0, Math.PI * 2);
        ctx.ellipse(bat.x - 10 * bat.s, bat.y + bob - 3 * bat.s, 7 * bat.s, 3 * bat.s, -0.5, 0, Math.PI * 2);
        ctx.ellipse(bat.x + 10 * bat.s, bat.y + bob - 3 * bat.s, 7 * bat.s, 3 * bat.s, 0.5, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.restore();

      targetsRef.current.forEach((target) => {
        if (!target.alive) return;
        const gradient = ctx.createLinearGradient(target.x, target.y, target.x, target.y + target.h);
        gradient.addColorStop(0, "#9ca3af");
        gradient.addColorStop(1, "#4b5563");
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.roundRect(target.x, target.y, target.w, target.h, 5);
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.22)";
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = "rgba(24,18,26,0.85)";
        ctx.font = "700 8px ui-sans-serif, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("R.I.P.", target.x + target.w / 2, target.y + target.h / 2 + 0.5);
      });

      SLINGS.forEach((sling) => {
        const pulse = 0.4 + Math.sin(time * 0.04) * 0.08;
        ctx.save();
        ctx.fillStyle = `rgba(255,122,24,${pulse * 0.35})`;
        ctx.strokeStyle = `rgba(255,160,80,${pulse + 0.3})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(sling.a.x, sling.a.y);
        ctx.lineTo(sling.b.x, sling.b.y);
        ctx.lineTo(
          sling.sling && sling.a.x < W / 2 ? sling.a.x - 4 : sling.a.x + 4,
          sling.a.y + 44,
        );
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      });

      bumpersRef.current.forEach((bumper) => {
        const painter = BUMPER_PAINTERS[bumper.kind];
        if (bumper.flash > 0) {
          ctx.save();
          ctx.globalAlpha = bumper.flash * 0.7;
          ctx.strokeStyle = "#ffd6a5";
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(bumper.x, bumper.y, bumper.r + 5 + (1 - bumper.flash) * 8, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }
        painter(ctx, bumper.x, bumper.y, bumper.r);
      });

      WALLS.forEach((wall) => {
        const isLane = wall.a.x >= 300 || wall.b.x >= 340;
        ctx.save();
        ctx.strokeStyle = isLane ? "rgba(160,140,255,0.55)" : "rgba(255,170,110,0.6)";
        ctx.lineWidth = 3.5;
        ctx.lineCap = "round";
        ctx.shadowColor = isLane ? "rgba(160,140,255,0.5)" : "rgba(255,140,60,0.55)";
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.moveTo(wall.a.x, wall.a.y);
        ctx.lineTo(wall.b.x, wall.b.y);
        ctx.stroke();
        ctx.restore();
      });

      ctx.save();
      ctx.strokeStyle = "rgba(196,132,252,0.8)";
      ctx.lineWidth = 2.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(306, 128);
      ctx.lineTo(340, 128);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "rgba(196,132,252,0.65)";
      ctx.font = "600 8px ui-sans-serif, system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("RAMP", 323, 140);
      ctx.restore();

      const charge = chargeRef.current;
      ctx.save();
      ctx.strokeStyle = "rgba(196,132,252,0.75)";
      ctx.lineWidth = 3;
      const springTop = 540 - 26 - charge * 14;
      ctx.beginPath();
      ctx.moveTo(323, 540);
      for (let index = 0; index <= 6; index += 1) {
        const y = 540 - (index * (540 - springTop)) / 6;
        ctx.lineTo(323 + (index % 2 === 0 ? -9 : 9), y);
      }
      ctx.lineTo(323, springTop);
      ctx.stroke();
      ctx.fillStyle = "#f59e0b";
      ctx.beginPath();
      ctx.roundRect(310, springTop - 6, 26, 7, 3);
      ctx.fill();
      ctx.restore();

      if (modeRef.current === "launch") {
        ctx.save();
        ctx.globalAlpha = 0.85;
        ctx.fillStyle = "#fde68a";
        ctx.font = "700 10px ui-sans-serif, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("HOLD + RELEASE", 323, 318);
        ctx.fillStyle = "rgba(255,255,255,0.22)";
        ctx.fillRect(312, 328, 22, 92);
        ctx.fillStyle = "rgba(196,132,252,0.9)";
        ctx.fillRect(312, 328 + 92 * (1 - charge), 22, 92 * charge);
        ctx.restore();
      }

      const flippers = flippersRef.current;
      [flippers.left, flippers.right].forEach((flipper) => {
        const tip = {
          x: flipper.pivot.x + Math.cos(flipper.angle) * flipper.length,
          y: flipper.pivot.y + Math.sin(flipper.angle) * flipper.length,
        };
        const gradient = ctx.createLinearGradient(flipper.pivot.x, flipper.pivot.y, tip.x, tip.y);
        gradient.addColorStop(0, "#ffb46b");
        gradient.addColorStop(1, "#e35c05");
        ctx.save();
        ctx.strokeStyle = "rgba(0,0,0,0.5)";
        ctx.lineWidth = 12;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(flipper.pivot.x, flipper.pivot.y);
        ctx.lineTo(tip.x, tip.y);
        ctx.stroke();
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 10;
        ctx.beginPath();
        ctx.moveTo(flipper.pivot.x, flipper.pivot.y);
        ctx.lineTo(tip.x, tip.y);
        ctx.stroke();
        ctx.fillStyle = "#fde68a";
        ctx.beginPath();
        ctx.arc(flipper.pivot.x, flipper.pivot.y, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      if (modeRef.current === "play" || modeRef.current === "paused" || modeRef.current === "launch") {
        ctx.save();
        ctx.fillStyle = "rgba(255,120,40,0.12)";
        ctx.beginPath();
        ctx.ellipse(160, H - 12, 88, 16, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        ball.trail.forEach((point, index) => {
          const alpha = (index / Math.max(1, ball.trail.length)) * 0.3;
          ctx.fillStyle = `rgba(255,190,120,${alpha})`;
          ctx.beginPath();
          ctx.arc(point.x, point.y, BALL_R * (0.4 + index / ball.trail.length / 1.6), 0, Math.PI * 2);
          ctx.fill();
        });

        const ballGradient = ctx.createRadialGradient(
          ball.x - BALL_R * 0.4,
          ball.y - BALL_R * 0.4,
          1,
          ball.x,
          ball.y,
          BALL_R,
        );
        ballGradient.addColorStop(0, "#ffffff");
        ballGradient.addColorStop(0.45, "#ffe6c7");
        ballGradient.addColorStop(1, "#ff9a3d");
        ctx.save();
        ctx.shadowColor = "rgba(255,160,80,0.9)";
        ctx.shadowBlur = 16;
        ctx.fillStyle = ballGradient;
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, BALL_R, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      popupsRef.current.forEach((popup) => {
        ctx.save();
        ctx.globalAlpha = Math.min(1, popup.life);
        ctx.fillStyle = popup.tone;
        ctx.font = "700 12px ui-sans-serif, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(popup.text, popup.x, popup.y);
        ctx.restore();
      });
    };

    const loop = (now: number) => {
      const elapsed = Math.min(2.5, (now - last) / 16.6667);
      last = now;
      timeRef.current += elapsed;

      if (modeRef.current !== "paused") {
        for (let index = 0; index < SUB_STEPS; index += 1) {
          step(elapsed / SUB_STEPS);
        }
        if (comboTimerRef.current > 0) {
          comboTimerRef.current -= elapsed;
          if (comboTimerRef.current <= 0) {
            comboRef.current = 0;
            syncHud();
          }
        }
        bumpersRef.current.forEach((bumper) => {
          bumper.flash = Math.max(0, bumper.flash - 0.045 * elapsed);
        });
        popupsRef.current = popupsRef.current
          .map((popup) => ({ ...popup, life: popup.life - 0.012 * elapsed, y: popup.y - 0.35 * elapsed }))
          .filter((popup) => popup.life > 0);
        const ball = ballRef.current;
        if (modeRef.current === "play") {
          ball.trail.push({ x: ball.x, y: ball.y });
          if (ball.trail.length > 8) ball.trail.shift();
        }
      }

      draw();
      frame = requestAnimationFrame(loop);
    };

    const previousHud = { score: -1, combo: -1, multiplier: -1, balls: -1 };
    const hudTimer = setInterval(() => {
      const multiplier = Math.min(5, 1 + Math.floor(comboRef.current / 4));
      if (
        previousHud.score !== scoreRef.current ||
        previousHud.balls !== ballsRef.current ||
        previousHud.combo !== comboRef.current ||
        previousHud.multiplier !== multiplier
      ) {
        previousHud.score = scoreRef.current;
        previousHud.balls = ballsRef.current;
        previousHud.combo = comboRef.current;
        previousHud.multiplier = multiplier;
        syncHud();
      }
    }, 120);

    draw();
    frame = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(frame);
      clearInterval(hudTimer);
    };
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      const key = event.key.toLowerCase();
      if (key === "arrowleft" || key === "a" || key === "z") {
        event.preventDefault();
        pressFlipper("left", true);
        return;
      }
      if (key === "arrowright" || key === "/" || key === "l" || key === "d") {
        event.preventDefault();
        pressFlipper("right", true);
        return;
      }
      if (event.key === " " || key === "s" || key === "arrowdown") {
        event.preventDefault();
        if (modeRef.current === "over") resetMatch();
        else startCharge();
        return;
      }
      if (key === "p" || key === "escape") {
        event.preventDefault();
        togglePause();
      }
    };

    const onKeyUp = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (key === "arrowleft" || key === "a" || key === "z") pressFlipper("left", false);
      if (key === "arrowright" || key === "/" || key === "l" || key === "d") pressFlipper("right", false);
      if (event.key === " " || key === "s" || key === "arrowdown") endCharge();
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, [endCharge, pressFlipper, resetMatch, startCharge, togglePause]);

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-black/30 px-4 py-2.5">
        <div className="flex flex-wrap items-center gap-3 text-xs text-pumpkin-50/60">
          <span>
            Score <strong className="text-base font-bold text-pumpkin-50">{hud.score}</strong>
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span className="flex items-center gap-1">
            <Flame className="h-3.5 w-3.5 text-[var(--accent)]" />
            <strong className="font-bold text-pumpkin-50">×{hud.multiplier}</strong>
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span className="flex items-center gap-1">
            {Array.from({ length: Math.max(0, hud.balls) }).map((_, index) => (
              <span key={index} aria-hidden="true">
                🎃
              </span>
            ))}
            {hud.balls === 0 ? <span className="text-red-300">no balls</span> : null}
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span className="flex items-center gap-1">
            <Trophy className="h-3.5 w-3.5 text-[var(--accent)]" /> {high}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={togglePause}
            disabled={mode === "idle" || mode === "over" || mode === "launch"}
            className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.7rem] font-semibold text-pumpkin-50 disabled:opacity-40"
          >
            {mode === "paused" ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
            {mode === "paused" ? "Resume" : "Pause"}
          </button>
          <button
            type="button"
            onClick={resetMatch}
            aria-label="Restart"
            className="btn-ghost grid h-8 w-8 place-items-center rounded-lg text-pumpkin-50"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="relative bg-[#0a0610] p-2 sm:p-3">
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          className="mx-auto block w-full max-w-[400px] touch-none rounded-xl border border-white/10"
        />

        {mode === "idle" ? (
          <div className="absolute inset-2 grid place-items-center rounded-xl bg-black/65 backdrop-blur-[3px] sm:inset-3">
            <div className="max-w-[260px] px-3 text-center">
              <p className="text-3xl">🎃</p>
              <p className="mt-1 text-lg font-bold text-pumpkin-50">Halloween Pinball</p>
              <p className="mt-1 text-[0.7rem] leading-relaxed text-pumpkin-50/55">
                Three balls, four haunted bumpers and a very hungry drain. Hold space to charge the
                plunger, then release.
              </p>
              <button type="button" onClick={resetMatch} className="btn-accent mt-3 rounded-lg px-3.5 py-2 text-xs font-bold">
                Load the machine
              </button>
            </div>
          </div>
        ) : null}

        {mode === "over" ? (
          <div className="absolute inset-2 grid place-items-center rounded-xl bg-black/70 backdrop-blur-[3px] sm:inset-3">
            <div className="max-w-[260px] px-3 text-center">
              <p className="text-2xl">💀</p>
              <p className="mt-1 text-lg font-bold text-pumpkin-50">Out of balls</p>
              <p className="mt-1 text-[0.72rem] text-pumpkin-50/55">
                Final score {hud.score}. Personal best {high}.
              </p>
              <button type="button" onClick={resetMatch} className="btn-accent mt-3 rounded-lg px-3.5 py-2 text-xs font-bold">
                Play again
              </button>
            </div>
          </div>
        ) : null}
      </div>

      <div className="grid grid-cols-3 gap-1.5 border-t border-white/10 bg-black/30 px-2.5 py-2.5 sm:hidden">
        <button
          type="button"
          onPointerDown={() => pressFlipper("left", true)}
          onPointerUp={() => pressFlipper("left", false)}
          onPointerLeave={() => pressFlipper("left", false)}
          onPointerCancel={() => pressFlipper("left", false)}
          className="btn-ghost rounded-xl py-3 text-xs font-bold text-pumpkin-50"
        >
          ◀ Left
        </button>
        <button
          type="button"
          onPointerDown={() => {
            if (modeRef.current === "over") resetMatch();
            else startCharge();
          }}
          onPointerUp={endCharge}
          onPointerCancel={endCharge}
          className="btn-accent rounded-xl py-3 text-xs font-bold"
        >
          Launch
        </button>
        <button
          type="button"
          onPointerDown={() => pressFlipper("right", true)}
          onPointerUp={() => pressFlipper("right", false)}
          onPointerLeave={() => pressFlipper("right", false)}
          onPointerCancel={() => pressFlipper("right", false)}
          className="btn-ghost rounded-xl py-3 text-xs font-bold text-pumpkin-50"
        >
          Right ▶
        </button>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/10 bg-black/30 px-4 py-2 text-[0.66rem] text-pumpkin-50/40">
        <span className="flex items-center gap-1.5">
          <Sparkles className="h-3 w-3 text-[var(--accent)]" />
          Chain hits for up to ×5 · clear tombstones for 1,500
        </span>
        <span className="hidden font-mono sm:block">← / A · → / L · space to launch · P pauses</span>
        <span className="font-mono sm:hidden">flip left · launch · flip right</span>
      </div>
    </div>
  );
}
