"use client";

import { useCallback, useEffect, useState } from "react";
import { RotateCcw, Timer, Trophy } from "lucide-react";

const SYMBOLS = ["🎃", "🍬", "🕸️", "🌙", "🔥", "🦇", "🍂", "💀"];
const BEST_KEY = "pumpkin.best.memory";

type Card = { id: number; symbol: string; matched: boolean };

function buildDeck(): Card[] {
  const deck = [...SYMBOLS, ...SYMBOLS].map((symbol, index) => ({
    id: index,
    symbol,
    matched: false,
  }));
  for (let index = deck.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(Math.random() * (index + 1));
    [deck[index], deck[swap]] = [deck[swap], deck[index]];
  }
  return deck.map((card, index) => ({ ...card, id: index }));
}

function orderedDeck(): Card[] {
  return [...SYMBOLS, ...SYMBOLS].map((symbol, index) => ({ id: index, symbol, matched: false }));
}

export function PumpkinPairs() {
  const [deck, setDeck] = useState<Card[]>(orderedDeck);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  const [best, setBest] = useState<number | null>(null);

  useEffect(() => {
    setDeck(buildDeck());
    try {
      const stored = window.localStorage.getItem(BEST_KEY);
      if (stored) setBest(Number(stored));
    } catch {
      setBest(null);
    }
  }, []);

  useEffect(() => {
    if (!running) return;
    const interval = setInterval(() => setSeconds((value) => value + 1), 1000);
    return () => clearInterval(interval);
  }, [running]);

  const restart = useCallback(() => {
    setDeck(buildDeck());
    setFlipped([]);
    setMoves(0);
    setSeconds(0);
    setRunning(true);
  }, []);

  const complete = deck.length > 0 && deck.every((card) => card.matched);

  useEffect(() => {
    if (!complete) return;
    setRunning(false);
    setBest((currentBest) => {
      if (currentBest !== null && currentBest <= moves) return currentBest;
      try {
        window.localStorage.setItem(BEST_KEY, String(moves));
      } catch {
        // ignore storage failures
      }
      return moves;
    });
  }, [complete, moves]);

  const flip = (index: number) => {
    if (flipped.length >= 2 || deck[index].matched || flipped.includes(index)) return;
    if (!running) setRunning(true);
    const nextFlipped = [...flipped, index];
    setFlipped(nextFlipped);

    if (nextFlipped.length === 2) {
      const [first, second] = nextFlipped;
      setMoves((value) => value + 1);
      if (deck[first].symbol === deck[second].symbol) {
        setDeck((previous) =>
          previous.map((card, cardIndex) =>
            cardIndex === first || cardIndex === second ? { ...card, matched: true } : card,
          ),
        );
        setFlipped([]);
      } else {
        setTimeout(() => setFlipped([]), 720);
      }
    }
  };

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-black/30 px-4 py-2.5 text-xs text-pumpkin-50/60">
        <div className="flex items-center gap-3">
          <span>
            Moves <strong className="text-base font-bold text-pumpkin-50">{moves}</strong>
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span className="flex items-center gap-1">
            <Timer className="h-3.5 w-3.5 text-[var(--accent)]" /> {seconds}s
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span className="flex items-center gap-1">
            <Trophy className="h-3.5 w-3.5 text-[var(--accent)]" />
            {best === null ? "—" : `${best} moves`}
          </span>
        </div>
        <button
          type="button"
          onClick={restart}
          className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.7rem] font-semibold text-pumpkin-50"
        >
          <RotateCcw className="h-3.5 w-3.5" /> Shuffle
        </button>
      </div>

      <div className="p-3 sm:p-4">
        <div className="mx-auto grid max-w-[460px] grid-cols-4 gap-2 sm:gap-2.5">
          {deck.map((card, index) => {
            const revealed = card.matched || flipped.includes(index);
            return (
              <button
                key={card.id}
                type="button"
                onClick={() => flip(index)}
                aria-label={revealed ? card.symbol : "Hidden card"}
                className={`group relative aspect-square rounded-xl border text-2xl transition duration-200 sm:text-3xl ${
                  revealed
                    ? card.matched
                      ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                      : "border-white/20 bg-white/10"
                    : "border-white/10 bg-black/45 hover:border-[var(--accent-line)] hover:bg-white/[0.07]"
                }`}
              >
                <span
                  className={`absolute inset-0 grid place-items-center transition duration-200 ${
                    revealed ? "scale-100 opacity-100" : "scale-75 opacity-0"
                  }`}
                >
                  {card.symbol}
                </span>
                <span
                  className={`absolute inset-0 grid place-items-center font-black text-pumpkin-50/15 transition ${
                    revealed ? "opacity-0" : "opacity-100"
                  }`}
                >
                  ?
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-4 flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-black/25 px-3 py-2 text-[0.7rem] text-pumpkin-50/50">
          <span>
            {complete
              ? `Cleared in ${moves} moves and ${seconds}s.`
              : flipped.length === 2
                ? "No match — flip them back."
                : "Find all eight pairs."}
          </span>
          <button type="button" onClick={restart} className="btn-accent rounded-lg px-2.5 py-1.5 text-[0.68rem] font-bold">
            {complete ? "Play again" : running ? "Reset" : "Start"}
          </button>
        </div>
      </div>
    </div>
  );
}
