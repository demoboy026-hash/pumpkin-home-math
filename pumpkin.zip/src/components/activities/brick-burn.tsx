"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Heart, Pause, Play, RotateCcw } from "lucide-react";

const WIDTH = 440;
const HEIGHT = 300;
const PADDLE_W = 76;
const PADDLE_H = 10;
const BALL_R = 6;
const COLS = 7;
const ROWS = 4;
const PAD = 7;
const TOP = 34;
const BRICK_H = 15;
const BRICK_W = (WIDTH - PAD * (COLS + 1)) / COLS;

type Brick = { x: number; y: number; alive: boolean; row: number };

function makeBricks(): Brick[] {
  const bricks: Brick[] = [];
  for (let row = 0; row < ROWS; row += 1) {
    for (let col = 0; col < COLS; col += 1) {
      bricks.push({
        x: PAD + col * (BRICK_W + PAD),
        y: TOP + row * (BRICK_H + PAD),
        alive: true,
        row,
      });
    }
  }
  return bricks;
}

export function BrickBurn() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stateRef = useRef({
    paddleX: (WIDTH - PADDLE_W) / 2,
    ball: { x: WIDTH / 2, y: HEIGHT - 60, dx: 3.1, dy: -3.4 },
    bricks: makeBricks(),
    score: 0,
    lives: 3,
    level: 1,
    running: false,
    over: false,
  });
  const keysRef = useRef({ left: false, right: false });
  const [ui, setUi] = useState({ score: 0, lives: 3, level: 1, running: false, over: false });

  const sync = useCallback(() => {
    const state = stateRef.current;
    setUi({
      score: state.score,
      lives: state.lives,
      level: state.level,
      running: state.running,
      over: state.over,
    });
  }, []);

  const resetBall = useCallback((speedBoost = 1) => {
    const state = stateRef.current;
    state.ball = {
      x: state.paddleX + PADDLE_W / 2,
      y: HEIGHT - 58,
      dx: (Math.random() > 0.5 ? 1 : -1) * 3.1 * speedBoost,
      dy: -3.4 * speedBoost,
    };
  }, []);

  const reset = useCallback(() => {
    const state = stateRef.current;
    state.bricks = makeBricks();
    state.paddleX = (WIDTH - PADDLE_W) / 2;
    state.score = 0;
    state.lives = 3;
    state.level = 1;
    state.over = false;
    state.running = true;
    resetBall();
    sync();
  }, [resetBall, sync]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const state = stateRef.current;

    const background = ctx.createLinearGradient(0, 0, 0, HEIGHT);
    background.addColorStop(0, "#0b0705");
    background.addColorStop(1, "#160c06");
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    const colors = ["#ffd6a5", "#ffb46b", "#ff8a3d", "#e35c05"];
    state.bricks.forEach((brick) => {
      if (!brick.alive) return;
      ctx.fillStyle = colors[brick.row % colors.length];
      ctx.beginPath();
      ctx.roundRect(brick.x, brick.y, BRICK_W, BRICK_H, 4);
      ctx.fill();
      ctx.fillStyle = "rgba(0,0,0,0.18)";
      ctx.fillRect(brick.x + 3, brick.y + BRICK_H - 4, BRICK_W - 6, 2);
    });

    const paddleGradient = ctx.createLinearGradient(state.paddleX, 0, state.paddleX + PADDLE_W, 0);
    paddleGradient.addColorStop(0, "#ffb46b");
    paddleGradient.addColorStop(1, "#ff7a18");
    ctx.fillStyle = paddleGradient;
    ctx.beginPath();
    ctx.roundRect(state.paddleX, HEIGHT - 26, PADDLE_W, PADDLE_H, 5);
    ctx.fill();

    ctx.shadowColor = "#ffa657";
    ctx.shadowBlur = 18;
    ctx.fillStyle = "#fff3e2";
    ctx.beginPath();
    ctx.arc(state.ball.x, state.ball.y, BALL_R, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    ctx.fillStyle = "rgba(255,255,255,0.35)";
    ctx.font = "600 10px ui-sans-serif, system-ui";
    ctx.fillText(`LEVEL ${state.level}`, 10, 20);
    ctx.fillText(`SCORE ${state.score}`, WIDTH - 76, 20);
  }, []);

  useEffect(() => {
    let frame = 0;
    let last = performance.now();

    const loop = (now: number) => {
      const delta = Math.min(2.4, (now - last) / 16.666);
      last = now;
      const state = stateRef.current;

      if (state.running) {
        if (keysRef.current.left) state.paddleX -= 6.5 * delta;
        if (keysRef.current.right) state.paddleX += 6.5 * delta;
        state.paddleX = Math.max(0, Math.min(WIDTH - PADDLE_W, state.paddleX));

        const ball = state.ball;
        ball.x += ball.dx * delta;
        ball.y += ball.dy * delta;

        if (ball.x < BALL_R) {
          ball.x = BALL_R;
          ball.dx = Math.abs(ball.dx);
        }
        if (ball.x > WIDTH - BALL_R) {
          ball.x = WIDTH - BALL_R;
          ball.dx = -Math.abs(ball.dx);
        }
        if (ball.y < BALL_R) {
          ball.y = BALL_R;
          ball.dy = Math.abs(ball.dy);
        }

        const paddleTop = HEIGHT - 26;
        if (
          ball.y + BALL_R >= paddleTop &&
          ball.y + BALL_R <= paddleTop + PADDLE_H + 6 &&
          ball.x >= state.paddleX - BALL_R &&
          ball.x <= state.paddleX + PADDLE_W + BALL_R &&
          ball.dy > 0
        ) {
          const hit = (ball.x - (state.paddleX + PADDLE_W / 2)) / (PADDLE_W / 2);
          const speed = Math.min(7.6, Math.hypot(ball.dx, ball.dy) + 0.06);
          const angle = hit * (Math.PI / 3);
          ball.dx = Math.sin(angle) * speed;
          ball.dy = -Math.abs(Math.cos(angle) * speed);
          ball.y = paddleTop - BALL_R;
        }

        for (const brick of state.bricks) {
          if (!brick.alive) continue;
          if (
            ball.x + BALL_R > brick.x &&
            ball.x - BALL_R < brick.x + BRICK_W &&
            ball.y + BALL_R > brick.y &&
            ball.y - BALL_R < brick.y + BRICK_H
          ) {
            brick.alive = false;
            state.score += 10;
            const fromSide =
              ball.x < brick.x + 4 || ball.x > brick.x + BRICK_W - 4;
            if (fromSide) ball.dx = -ball.dx;
            else ball.dy = -ball.dy;
            sync();
            break;
          }
        }

        if (state.bricks.every((brick) => !brick.alive)) {
          state.level += 1;
          state.bricks = makeBricks();
          state.paddleX = (WIDTH - PADDLE_W) / 2;
          resetBall(1 + state.level * 0.08);
          state.score += 50;
          sync();
        }

        if (ball.y - BALL_R > HEIGHT) {
          state.lives -= 1;
          if (state.lives <= 0) {
            state.lives = 0;
            state.running = false;
            state.over = true;
          } else {
            resetBall(1 + state.level * 0.05);
          }
          sync();
        }

        draw();
      }

      frame = requestAnimationFrame(loop);
    };

    frame = requestAnimationFrame(loop);
    draw();
    return () => cancelAnimationFrame(frame);
  }, [draw, resetBall, sync]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") {
        event.preventDefault();
        keysRef.current.left = true;
      }
      if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") {
        event.preventDefault();
        keysRef.current.right = true;
      }
      if (event.key === " ") {
        event.preventDefault();
        const state = stateRef.current;
        if (state.over) reset();
        else {
          state.running = !state.running;
          sync();
        }
      }
    };
    const onKeyUp = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") keysRef.current.left = false;
      if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") keysRef.current.right = false;
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, [reset, sync]);

  const movePaddle = (clientX: number, element: HTMLCanvasElement) => {
    const rect = element.getBoundingClientRect();
    const ratio = (clientX - rect.left) / rect.width;
    const state = stateRef.current;
    state.paddleX = Math.max(0, Math.min(WIDTH - PADDLE_W, ratio * WIDTH - PADDLE_W / 2));
    if (state.over) return;
    draw();
  };

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-black/30 px-4 py-2.5">
        <div className="flex items-center gap-3 text-xs text-pumpkin-50/60">
          <span>
            Score <strong className="text-base font-bold text-pumpkin-50">{ui.score}</strong>
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span>
            Level <strong className="font-bold text-pumpkin-50">{ui.level}</strong>
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span className="flex items-center gap-1">
            {Array.from({ length: Math.max(0, ui.lives) }).map((_, index) => (
              <Heart key={index} className="h-3 w-3 fill-[var(--accent)] text-[var(--accent)]" />
            ))}
            {ui.lives === 0 ? <span className="text-red-300">no lives</span> : null}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => {
              const state = stateRef.current;
              if (state.over) reset();
              else {
                state.running = !state.running;
                sync();
              }
            }}
            className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.7rem] font-semibold text-pumpkin-50"
          >
            {ui.running ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            {ui.over ? "Play again" : ui.running ? "Pause" : "Resume"}
          </button>
          <button
            type="button"
            onClick={reset}
            aria-label="Restart"
            className="btn-ghost grid h-8 w-8 place-items-center rounded-lg text-pumpkin-50"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="relative bg-[#0b0705] p-3">
        <canvas
          ref={canvasRef}
          width={WIDTH}
          height={HEIGHT}
          onPointerMove={(event) => movePaddle(event.clientX, event.currentTarget)}
          onPointerDown={(event) => {
            const state = stateRef.current;
            if (state.over) reset();
            movePaddle(event.clientX, event.currentTarget);
          }}
          className="mx-auto block w-full max-w-[520px] cursor-none touch-none rounded-xl border border-white/10"
        />
        {!ui.running ? (
          <div className="absolute inset-3 grid place-items-center rounded-xl bg-black/55 backdrop-blur-[2px]">
            <div className="text-center">
              <p className="text-lg font-bold text-pumpkin-50">{ui.over ? "Out of lives" : "Brick Burn"}</p>
              <p className="mt-1 max-w-[260px] px-4 text-xs text-pumpkin-50/50">
                {ui.over
                  ? `Final score ${ui.score} on level ${ui.level}. The wall resets with a click.`
                  : "Move with your mouse, touch or the arrow keys. Space pauses."}
              </p>
              <button type="button" onClick={reset} className="btn-accent mt-3 rounded-lg px-3.5 py-2 text-xs font-bold">
                {ui.over ? "Try again" : "Start"}
              </button>
            </div>
          </div>
        ) : null}
      </div>

      <div className="flex items-center justify-between border-t border-white/10 bg-black/30 px-4 py-2 text-[0.66rem] text-pumpkin-50/40">
        <span>Clear the wall to level up</span>
        <span className="font-mono">mouse / arrows</span>
      </div>
    </div>
  );
}
