"use client";

import { useCallback, useEffect, useState } from "react";
import { Flame, Play, RotateCcw, Trophy } from "lucide-react";

const DURATION_MS = 30_000;
const BEST_KEY = "pumpkin.best.target-rush";
const TILES = 9;

export function TargetRush() {
  const [target, setTarget] = useState(4);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [remaining, setRemaining] = useState(DURATION_MS);
  const [running, setRunning] = useState(false);
  const [over, setOver] = useState(false);
  const [best, setBest] = useState<number | null>(null);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(BEST_KEY);
      if (stored) setBest(Number(stored));
    } catch {
      setBest(null);
    }
  }, []);

  const finish = useCallback(
    (finalScore: number) => {
      setRunning(false);
      setOver(true);
      setBest((currentBest) => {
        if (currentBest !== null && currentBest >= finalScore) return currentBest;
        try {
          window.localStorage.setItem(BEST_KEY, String(finalScore));
        } catch {
          // ignore storage failures
        }
        return finalScore;
      });
    },
    [],
  );

  useEffect(() => {
    if (!running) return;
    const started = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - started;
      const left = DURATION_MS - elapsed;
      if (left <= 0) {
        setRemaining(0);
        clearInterval(interval);
        setScore((current) => {
          finish(current);
          return current;
        });
      } else {
        setRemaining(left);
      }
    }, 90);
    return () => clearInterval(interval);
  }, [finish, running]);

  const start = useCallback(() => {
    setScore(0);
    setStreak(0);
    setBestStreak(0);
    setRemaining(DURATION_MS);
    setOver(false);
    setRunning(true);
    setTarget(Math.floor(Math.random() * TILES));
  }, []);

  const hit = (index: number) => {
    if (!running) {
      if (!over) start();
      return;
    }
    if (index === target) {
      const nextStreak = streak + 1;
      const bonus = Math.floor(nextStreak / 4);
      setScore((value) => value + 1 + bonus);
      setStreak(nextStreak);
      setBestStreak((value) => Math.max(value, nextStreak));
      let next = Math.floor(Math.random() * TILES);
      while (next === target) next = Math.floor(Math.random() * TILES);
      setTarget(next);
    } else {
      setStreak(0);
      setRemaining((value) => Math.max(0, value - 900));
    }
  };

  const seconds = (remaining / 1000).toFixed(1);
  const progress = Math.max(0, Math.min(100, (remaining / DURATION_MS) * 100));

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-black/30 px-4 py-2.5 text-xs text-pumpkin-50/60">
        <div className="flex items-center gap-3">
          <span>
            Score <strong className="text-base font-bold text-pumpkin-50">{score}</strong>
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span className="flex items-center gap-1">
            <Flame className="h-3.5 w-3.5 text-[var(--accent)]" /> {streak} streak
          </span>
          <span className="text-pumpkin-50/25">|</span>
          <span className="flex items-center gap-1">
            <Trophy className="h-3.5 w-3.5 text-[var(--accent)]" /> {best ?? "—"}
          </span>
        </div>
        <span className="font-mono text-sm font-bold text-pumpkin-50">{seconds}s</span>
      </div>

      <div className="h-1 w-full bg-black/40">
        <div
          className="h-full transition-[width] duration-100 ease-linear"
          style={{ width: `${progress}%`, background: "linear-gradient(90deg,#ffd6a5,var(--accent))" }}
        />
      </div>

      <div className="p-3 sm:p-4">
        <div className="mx-auto grid max-w-[420px] grid-cols-3 gap-2.5">
          {Array.from({ length: TILES }).map((_, index) => (
            <button
              key={index}
              type="button"
              onClick={() => hit(index)}
              aria-label={`Tile ${index + 1}`}
              className={`aspect-square rounded-xl border transition duration-100 ${
                running && index === target
                  ? "border-[var(--accent-line)] bg-[var(--accent-soft)] shadow-[0_0_30px_-6px_var(--accent-glow)]"
                  : "border-white/10 bg-black/40 hover:border-white/20 hover:bg-white/[0.05]"
              }`}
            >
              <span
                className={`mx-auto block h-9 w-9 rounded-full transition ${
                  running && index === target
                    ? "animate-pulse bg-[var(--accent)] shadow-[0_0_24px_2px_var(--accent-glow)]"
                    : "bg-white/[0.06]"
                }`}
              />
            </button>
          ))}
        </div>

        <div className="mt-4 flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-black/25 px-3 py-2 text-[0.7rem] text-pumpkin-50/50">
          <span>
            {over
              ? `Time. You scored ${score} with a best streak of ${bestStreak}.`
              : running
                ? "Hit the glowing tile. Misses cost 0.9s."
                : "30 seconds on the clock. Every 4-hit streak adds bonus points."}
          </span>
          <button
            type="button"
            onClick={start}
            className="btn-accent flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.68rem] font-bold"
          >
            {running ? <RotateCcw className="h-3 w-3" /> : <Play className="h-3 w-3" />}
            {running ? "Restart" : over ? "Again" : "Start"}
          </button>
        </div>
      </div>
    </div>
  );
}
