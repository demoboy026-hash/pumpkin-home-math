"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw, Trophy } from "lucide-react";

const COLS = 20;
const ROWS = 20;
const CELL = 20;
const HIGH_SCORE_KEY = "pumpkin.highscore.snake";

type Point = { x: number; y: number };

function initialSnake(): Point[] {
  return [
    { x: 9, y: 10 },
    { x: 8, y: 10 },
    { x: 7, y: 10 },
  ];
}

function randomFood(snake: Point[]): Point {
  for (let attempt = 0; attempt < 200; attempt += 1) {
    const candidate = { x: Math.floor(Math.random() * COLS), y: Math.floor(Math.random() * ROWS) };
    if (!snake.some((part) => part.x === candidate.x && part.y === candidate.y)) return candidate;
  }
  return { x: 0, y: 0 };
}

export function NeonSnake() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const snakeRef = useRef<Point[]>(initialSnake());
  const dirRef = useRef<Point>({ x: 1, y: 0 });
  const queuedRef = useRef<Point>({ x: 1, y: 0 });
  const foodRef = useRef<Point>({ x: 14, y: 10 });
  const [score, setScore] = useState(0);
  const [high, setHigh] = useState(0);
  const [running, setRunning] = useState(false);
  const [over, setOver] = useState(false);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.fillStyle = "#0c0806";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = "rgba(255,255,255,0.035)";
    ctx.lineWidth = 1;
    for (let index = 1; index < COLS; index += 1) {
      ctx.beginPath();
      ctx.moveTo(index * CELL, 0);
      ctx.lineTo(index * CELL, canvas.height);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, index * CELL);
      ctx.lineTo(canvas.width, index * CELL);
      ctx.stroke();
    }

    const food = foodRef.current;
    ctx.shadowColor = "#ff9f43";
    ctx.shadowBlur = 16;
    ctx.fillStyle = "#ff7a18";
    ctx.beginPath();
    ctx.arc(food.x * CELL + CELL / 2, food.y * CELL + CELL / 2, CELL * 0.32, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    snakeRef.current.forEach((part, index) => {
      const ratio = index / Math.max(1, snakeRef.current.length - 1);
      ctx.fillStyle = index === 0 ? "#ffd6a5" : `rgba(255, ${Math.round(140 - ratio * 60)}, 24, ${1 - ratio * 0.35})`;
      const pad = index === 0 ? 1.5 : 2.5;
      ctx.beginPath();
      ctx.roundRect(part.x * CELL + pad, part.y * CELL + pad, CELL - pad * 2, CELL - pad * 2, 5);
      ctx.fill();
    });

    ctx.fillStyle = "rgba(255,255,255,0.55)";
    ctx.font = "600 10px ui-sans-serif, system-ui";
    ctx.fillText("PUMPKIN", 10, canvas.height - 10);
  }, []);

  useEffect(() => {
    try {
      const stored = Number(window.localStorage.getItem(HIGH_SCORE_KEY) ?? "0");
      if (Number.isFinite(stored)) setHigh(stored);
    } catch {
      setHigh(0);
    }
    draw();
  }, [draw]);

  const finish = useCallback(() => {
    setRunning(false);
    setOver(true);
    setScore((current) => {
      try {
        const stored = Number(window.localStorage.getItem(HIGH_SCORE_KEY) ?? "0");
        if (current > stored) {
          window.localStorage.setItem(HIGH_SCORE_KEY, String(current));
          setHigh(current);
        }
      } catch {
        // ignore storage errors
      }
      return current;
    });
  }, []);

  const reset = useCallback(() => {
    snakeRef.current = initialSnake();
    dirRef.current = { x: 1, y: 0 };
    queuedRef.current = { x: 1, y: 0 };
    foodRef.current = randomFood(snakeRef.current);
    setScore(0);
    setOver(false);
    setRunning(true);
    draw();
  }, [draw]);

  const step = useCallback(() => {
    const direction = queuedRef.current;
    dirRef.current = direction;
    const snake = snakeRef.current;
    const head = snake[0];
    const next = { x: head.x + direction.x, y: head.y + direction.y };

    if (next.x < 0 || next.y < 0 || next.x >= COLS || next.y >= ROWS) {
      finish();
      return;
    }
    if (snake.some((part) => part.x === next.x && part.y === next.y)) {
      finish();
      return;
    }

    const eating = next.x === foodRef.current.x && next.y === foodRef.current.y;
    const nextSnake = [next, ...snake.slice(0, eating ? snake.length : snake.length - 1)];
    snakeRef.current = nextSnake;

    if (eating) {
      foodRef.current = randomFood(nextSnake);
      setScore((current) => current + 10);
    }
    draw();
  }, [draw, finish]);

  useEffect(() => {
    if (!running) return;
    const speed = Math.max(70, 135 - Math.floor(score / 50) * 10);
    const interval = setInterval(step, speed);
    return () => clearInterval(interval);
  }, [running, score, step]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      const key = event.key.toLowerCase();
      const current = dirRef.current;
      const map: Record<string, Point> = {
        arrowup: { x: 0, y: -1 },
        w: { x: 0, y: -1 },
        arrowdown: { x: 0, y: 1 },
        s: { x: 0, y: 1 },
        arrowleft: { x: -1, y: 0 },
        a: { x: -1, y: 0 },
        arrowright: { x: 1, y: 0 },
        d: { x: 1, y: 0 },
      };
      const next = map[key];
      if (next) {
        event.preventDefault();
        if (!(next.x === -current.x && next.y === -current.y)) queuedRef.current = next;
        if (!running && !over) reset();
        return;
      }
      if (key === " ") {
        event.preventDefault();
        if (over) reset();
        else setRunning((value) => !value);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [over, reset, running]);

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-black/30 px-4 py-2.5">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold uppercase tracking-[0.16em] text-pumpkin-50/50">score</span>
          <span className="text-xl font-bold text-pumpkin-50">{score}</span>
          <span className="flex items-center gap-1 text-xs text-pumpkin-50/45">
            <Trophy className="h-3.5 w-3.5 text-[var(--accent)]" /> {high}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => (over ? reset() : setRunning((value) => !value))}
            className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.7rem] font-semibold text-pumpkin-50"
          >
            {running ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            {over ? "Play again" : running ? "Pause" : "Resume"}
          </button>
          <button
            type="button"
            onClick={reset}
            className="btn-ghost grid h-8 w-8 place-items-center rounded-lg text-pumpkin-50"
            aria-label="Restart"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="relative bg-[#0c0806] p-3">
        <canvas
          ref={canvasRef}
          width={COLS * CELL}
          height={ROWS * CELL}
          className="mx-auto block w-full max-w-[420px] touch-none rounded-xl border border-white/10"
        />
        {!running ? (
          <div className="absolute inset-3 grid place-items-center rounded-xl bg-black/55 backdrop-blur-[2px]">
            <div className="text-center">
              <p className="text-lg font-bold text-pumpkin-50">{over ? "Run over" : "Neon Snake"}</p>
              <p className="mt-1 max-w-[240px] text-xs text-pumpkin-50/50">
                {over ? `You scored ${score}. Press space or hit play for another run.` : "Arrows or WASD to steer. Space pauses."}
              </p>
              <button
                type="button"
                onClick={reset}
                className="btn-accent mt-3 rounded-lg px-3.5 py-2 text-xs font-bold"
              >
                {over ? "Try again" : "Start"}
              </button>
            </div>
          </div>
        ) : null}
      </div>

      <div className="flex items-center justify-between border-t border-white/10 bg-black/30 px-4 py-2 text-[0.66rem] text-pumpkin-50/40">
        <span>Speed rises every 5 snacks</span>
        <span className="font-mono">arrows / wasd</span>
      </div>
    </div>
  );
}
