"use client";

import { BrickBurn } from "@/components/activities/brick-burn";
import { HalloweenPinball } from "@/components/activities/halloween-pinball";
import { PumpkinPairs } from "@/components/activities/pumpkin-pairs";
import { NeonSnake } from "@/components/activities/neon-snake";
import { TargetRush } from "@/components/activities/target-rush";

export function ActivityPlayer({ slug }: { slug: string }) {
  if (slug === "breakout") return <BrickBurn />;
  if (slug === "halloween-pinball") return <HalloweenPinball />;
  if (slug === "memory") return <PumpkinPairs />;
  if (slug === "target-rush") return <TargetRush />;
  return <NeonSnake />;
}
