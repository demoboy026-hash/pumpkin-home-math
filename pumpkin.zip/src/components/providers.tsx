"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  comboFromEvent,
  isEditableTarget,
  isSafeHttpUrl,
  readStoredSettings,
  SETTINGS_KEY,
  writeStoredSettings,
} from "@/lib/settings";
import { DEFAULT_SETTINGS, type Settings } from "@/lib/types";
import { installSessionFetch } from "@/lib/session-client";
import { useAccount } from "@/lib/account";

type SettingsContextValue = {
  settings: Settings;
  ready: boolean;
  saving: boolean;
  setLocal: (next: Settings) => void;
  save: (next: Settings) => Promise<boolean>;
  notify: (message: string) => void;
};

const SettingsContext = createContext<SettingsContextValue | null>(null);

const PROFILE_ID_KEY = "pumpkin.profileId";

const DISGUISE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="#1d4ed8"/><path d="M32 16 54 27 32 38 10 27z" fill="#fff"/><path d="M19 32v10c0 4 6 7 13 7s13-3 13-7V32l-13 6z" fill="#fff" opacity=".85"/></svg>`;

const STANDARD_ICON = "/icon.svg";

function applyDocumentChrome(settings: Settings) {
  document.documentElement.dataset.accent = settings.accent;
  document.title = settings.disguiseEnabled
    ? settings.disguiseTitle || DEFAULT_SETTINGS.disguiseTitle
    : "pumpkin — your private browser";

  const href = settings.disguiseEnabled
    ? `data:image/svg+xml,${encodeURIComponent(DISGUISE_ICON)}`
    : STANDARD_ICON;

  let link = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
  if (!link) {
    link = document.createElement("link");
    link.rel = "icon";
    document.head.appendChild(link);
  }
  link.type = "image/svg+xml";
  link.href = href;
}

export function SettingsProvider({
  children,
  initialSettings,
}: {
  children: ReactNode;
  initialSettings?: Partial<Settings> | null;
}) {
  const baseline: Settings = { ...DEFAULT_SETTINGS, ...(initialSettings ?? {}) };
  const [settings, setSettings] = useState<Settings>(baseline);
  const [ready, setReady] = useState(false);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { refresh: refreshAccountState } = useAccount();

  useEffect(() => {
    void refreshAccountState();
  }, [refreshAccountState]);

  const notify = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  }, []);

  useEffect(() => {
    // Makes the very first request authenticated even without cookies.
    installSessionFetch();
  }, []);

  useEffect(() => {
    const stored = window.localStorage.getItem(SETTINGS_KEY);
    const local = readStoredSettings();
    setSettings({ ...baseline, ...local });
    setReady(true);

    let cancelled = false;
    (async () => {
      try {
        const response = await fetch("/api/settings", { cache: "no-store" });
        if (!response.ok) return;
        const data = (await response.json()) as { settings: Settings; profileId?: string };
        if (cancelled || !data.settings) return;

        // A different profile means someone signed in, signed up or signed out.
        // The server copy is authoritative so accounts restore on every visit.
        const knownProfile = window.localStorage.getItem(PROFILE_ID_KEY);
        const switched = Boolean(data.profileId) && knownProfile !== data.profileId;

        if (switched || !stored) {
          const merged = { ...baseline, ...data.settings };
          setSettings(merged);
          writeStoredSettings(merged);
        }
        if (data.profileId) window.localStorage.setItem(PROFILE_ID_KEY, data.profileId);
      } catch {
        // Offline / API unavailable — local settings still cover everything.
      }
    })();

    return () => {
      cancelled = true;
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    applyDocumentChrome(settings);
  }, [settings, ready]);

  const baselineKey = JSON.stringify(baseline);

  // Server-rendered profile values act as the base for this mount.
  useEffect(() => {
    setSettings((current) => ({ ...baseline, ...current }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baselineKey]);

  const setLocal = useCallback((next: Settings) => {
    setSettings(next);
    writeStoredSettings(next);
  }, []);

  const save = useCallback(
    async (next: Settings) => {
      setSaving(true);
      setLocal(next);
      try {
        const response = await fetch("/api/settings", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(next),
        });
        if (!response.ok) throw new Error("save failed");
        notify("Settings saved");
        return true;
      } catch {
        notify("Saved on this device only");
        return false;
      } finally {
        setSaving(false);
      }
    },
    [notify, setLocal],
  );

  const value = useMemo(
    () => ({ settings, ready, saving, setLocal, save, notify }),
    [settings, ready, saving, setLocal, save, notify],
  );

  useEffect(() => {
    if (!ready || !settings.panicEnabled) return;
    if (!settings.panicKey) return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (comboFromEvent(event) !== settings.panicKey) return;
      const hasModifier = event.ctrlKey || event.altKey || event.metaKey;
      if (isEditableTarget(event.target) && !hasModifier) return;

      event.preventDefault();
      event.stopPropagation();
      const destination = isSafeHttpUrl(settings.panicUrl)
        ? settings.panicUrl
        : DEFAULT_SETTINGS.panicUrl;
      window.location.replace(destination);
    };

    window.addEventListener("keydown", onKeyDown, true);
    return () => window.removeEventListener("keydown", onKeyDown, true);
  }, [ready, settings.panicEnabled, settings.panicKey, settings.panicUrl]);

  return (
    <SettingsContext.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-6 z-[90] flex justify-center px-4"
      >
        {toast ? (
          <div className="animate-rise glass flex items-center gap-2 rounded-full px-4 py-2 text-sm text-pumpkin-50 shadow-2xl">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent)" }} />
            {toast}
          </div>
        ) : null}
      </div>
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error("useSettings must be used inside SettingsProvider");
  return ctx;
}
