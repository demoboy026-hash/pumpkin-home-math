"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowRight, LayoutGrid, Play, Search } from "lucide-react";
import { ACTIVITIES } from "@/lib/activities";

const CATEGORIES = ["All", "Classic", "Puzzle", "Reflex"] as const;

export function ActivityCatalog() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("All");

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return ACTIVITIES.filter((activity) => {
      const inCategory = category === "All" || activity.category === category;
      const inSearch =
        !term ||
        activity.name.toLowerCase().includes(term) ||
        activity.description.toLowerCase().includes(term) ||
        activity.category.toLowerCase().includes(term);
      return inCategory && inSearch;
    });
  }, [category, query]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-black/40 px-3 py-2 sm:w-72">
          <Search className="h-3.5 w-3.5 text-pumpkin-50/35" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search activities"
            aria-label="Search activities"
            className="w-full bg-transparent text-xs text-pumpkin-50 outline-none placeholder:text-pumpkin-50/30"
          />
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {CATEGORIES.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setCategory(item)}
              className={`rounded-full border px-3 py-1.5 text-[0.7rem] font-semibold transition ${
                category === item
                  ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                  : "border-white/10 bg-white/[0.03] text-pumpkin-50/55 hover:text-pumpkin-50"
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {filtered.map((activity) => (
          <Link
            key={activity.slug}
            href={`/activities/${activity.slug}`}
            className="glass panel-hover group relative overflow-hidden rounded-2xl p-4"
          >
            <div
              className="pointer-events-none absolute -right-10 -top-12 h-32 w-32 rounded-full opacity-25 blur-2xl transition group-hover:opacity-40"
              style={{ background: activity.accent }}
            />
            <div className="relative flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <span
                  className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border text-2xl"
                  style={{ borderColor: `${activity.accent}55`, background: `${activity.accent}1f` }}
                >
                  {activity.emoji}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-pumpkin-50">{activity.name}</h3>
                    <span
                      className="rounded-full px-1.5 py-0.5 text-[0.58rem] font-bold uppercase tracking-wider"
                      style={{ background: `${activity.accent}22`, color: activity.accent }}
                    >
                      {activity.category}
                    </span>
                  </div>
                  <p className="mt-1 text-[0.72rem] leading-relaxed text-pumpkin-50/45">
                    {activity.tagline}
                  </p>
                </div>
              </div>
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-white/10 bg-black/30 text-pumpkin-50/40 transition group-hover:border-[var(--accent-line)] group-hover:text-[var(--accent)]">
                <Play className="h-3.5 w-3.5" />
              </span>
            </div>
            <div className="relative mt-3 flex items-center justify-between border-t border-white/[0.07] pt-2.5 text-[0.64rem] text-pumpkin-50/35">
              <span className="flex items-center gap-1.5">
                <LayoutGrid className="h-3 w-3" /> runs locally · no filter
              </span>
              <span className="flex items-center gap-1 font-semibold text-pumpkin-50/55 transition group-hover:text-[var(--accent)]">
                Open <ArrowRight className="h-3 w-3" />
              </span>
            </div>
          </Link>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="glass rounded-2xl px-4 py-10 text-center text-sm text-pumpkin-50/45">
          No activity matches that yet.
        </div>
      ) : null}
    </div>
  );
}
