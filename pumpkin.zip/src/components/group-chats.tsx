"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Check,
  Crown,
  Loader2,
  Lock,
  LogOut,
  Pencil,
  Plus,
  Send,
  Trash2,
  UserMinus,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { AvatarView } from "@/components/avatar-view";
import { useSettings } from "@/components/providers";
import { useAccount } from "@/lib/account";

type Member = {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  effect: string | null;
  role: string;
};

type Group = {
  id: number;
  name: string;
  createdBy: string;
  creatorIsMe: boolean;
  role: string;
  members: Member[];
  lastMessage: { body: string; at: string; mine: boolean } | null;
};

type Invitable = { id: string; username: string; displayName: string };

type Message = {
  id: number;
  mine: boolean;
  body: string;
  author: string;
  avatar: string | null;
  effect: string | null;
  createdAt: string;
};

export function GroupChats() {
  const { user, loading: accountLoading } = useAccount();
  const { notify } = useSettings();
  const [groups, setGroups] = useState<Group[]>([]);
  const [invitable, setInvitable] = useState<Invitable[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [picked, setPicked] = useState<string[]>([]);
  const [renaming, setRenaming] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [addingId, setAddingId] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [threadError, setThreadError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/groups", { cache: "no-store" });
      if (!response.ok) return;
      const payload = (await response.json()) as { groups?: Group[]; invitable?: Invitable[] };
      setGroups(payload.groups ?? []);
      setInvitable(payload.invitable ?? []);
      setActiveId((current) => {
        if (current && (payload.groups ?? []).some((g) => g.id === current)) return current;
        return payload.groups?.[0]?.id ?? null;
      });
    } catch {
      // keep whatever we already had
    }
  }, []);

  const loadThread = useCallback(async (groupId: number) => {
    try {
      const response = await fetch(`/api/groups/${groupId}/messages`, { cache: "no-store" });
      const payload = (await response.json()) as { messages?: Message[]; error?: string };
      if (!response.ok) {
        setThreadError(payload.error ?? "Could not load this group.");
        return;
      }
      setThreadError(null);
      setMessages(payload.messages ?? []);
    } catch {
      setThreadError("Could not load this group.");
    }
  }, []);

  useEffect(() => {
    if (accountLoading) return;
    void load();
    const interval = setInterval(() => void load(), 10000);
    return () => clearInterval(interval);
  }, [accountLoading, load]);

  useEffect(() => {
    if (!activeId) {
      setMessages([]);
      return;
    }
    void loadThread(activeId);
    const interval = setInterval(() => void loadThread(activeId), 4000);
    return () => clearInterval(interval);
  }, [activeId, loadThread]);

  useEffect(() => {
    const node = scrollRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages]);

  const active = groups.find((group) => group.id === activeId) ?? null;
  const isOwner = active?.role === "owner";

  const create = async () => {
    if (!newName.trim()) {
      notify("Give the group a name first");
      return;
    }
    setBusy("create");
    try {
      const response = await fetch("/api/groups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName.trim(), memberIds: picked }),
      });
      const payload = (await response.json()) as { id?: number; error?: string };
      if (!response.ok || !payload.id) {
        notify(payload.error ?? "Could not create that group");
        return;
      }
      setCreating(false);
      setNewName("");
      setPicked([]);
      await load();
      setActiveId(payload.id);
      notify("Group created — only members can see it");
    } catch {
      notify("Could not create that group");
    } finally {
      setBusy(null);
    }
  };

  const rename = async () => {
    if (!active) return;
    setBusy("rename");
    try {
      const response = await fetch(`/api/groups/${active.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: renameValue }),
      });
      const payload = (await response.json()) as { name?: string; error?: string };
      if (!response.ok) {
        notify(payload.error ?? "Could not rename the group");
        return;
      }
      setRenaming(false);
      await load();
      notify(`Renamed to “${payload.name}”`);
    } catch {
      notify("Could not rename the group");
    } finally {
      setBusy(null);
    }
  };

  const memberAction = async (
    action: "add" | "remove" | "leave",
    userId: string,
    label: string,
  ) => {
    if (!active) return;
    setBusy(`${action}:${userId}`);
    try {
      const response = await fetch(`/api/groups/${active.id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, userId }),
      });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok) {
        notify(payload.error ?? "Could not update members");
        return;
      }
      setAddingId("");
      notify(label);
      await load();
      if (action === "leave") setActiveId(null);
    } catch {
      notify("Could not update members");
    } finally {
      setBusy(null);
    }
  };

  const removeGroup = async () => {
    if (!active) return;
    setBusy("delete");
    try {
      const response = await fetch(`/api/groups/${active.id}`, { method: "DELETE" });
      if (!response.ok) {
        const payload = (await response.json()) as { error?: string };
        notify(payload.error ?? "Could not delete the group");
        return;
      }
      notify("Group deleted");
      setActiveId(null);
      await load();
    } catch {
      notify("Could not delete the group");
    } finally {
      setBusy(null);
    }
  };

  const send = async () => {
    const text = draft.trim();
    if (!text || !active || sending) return;
    setSending(true);
    const tempId = -Date.now();
    setMessages((previous) => [
      ...previous,
      {
        id: tempId,
        mine: true,
        body: text,
        author: user?.displayName ?? "you",
        avatar: null,
        effect: "none",
        createdAt: new Date().toISOString(),
      },
    ]);
    setDraft("");
    try {
      const response = await fetch(`/api/groups/${active.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body: text }),
      });
      const payload = (await response.json()) as { message?: Message; error?: string };
      if (!response.ok || !payload.message) {
        setMessages((previous) => previous.filter((message) => message.id !== tempId));
        setDraft(text);
        notify(payload.error ?? "Message did not send");
        return;
      }
      setMessages((previous) =>
        previous.map((message) => (message.id === tempId ? (payload.message as Message) : message)),
      );
    } catch {
      setMessages((previous) => previous.filter((message) => message.id !== tempId));
      setDraft(text);
      notify("Message did not send");
    } finally {
      setSending(false);
    }
  };

  if (accountLoading) {
    return (
      <div className="glass flex items-center justify-center gap-2 rounded-2xl px-4 py-16 text-xs text-pumpkin-50/45">
        <Loader2 className="h-4 w-4 animate-spin" /> loading group chats
      </div>
    );
  }

  if (!user) {
    return (
      <div className="glass rounded-2xl px-5 py-12 text-center">
        <Lock className="mx-auto h-7 w-7 text-pumpkin-50/25" />
        <p className="mt-2 text-base font-bold text-pumpkin-50">Group chats need an account</p>
        <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-pumpkin-50/45">
          Private groups are tied to your account so only the people you add can read them.
        </p>
        <Link href="/account" className="btn-accent mt-3 inline-flex rounded-xl px-3.5 py-2 text-xs font-bold">
          Sign in or create account
        </Link>
      </div>
    );
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
      <div className="space-y-3">
        <section className="glass rounded-2xl p-3.5">
          <div className="flex items-center justify-between">
            <p className="section-label flex items-center gap-1.5">
              <Users className="h-3 w-3" /> your groups · {groups.length}
            </p>
            <button
              type="button"
              onClick={() => setCreating((value) => !value)}
              className="flex items-center gap-1 rounded-lg border border-[var(--accent-line)] bg-[var(--accent-soft)] px-2 py-1 text-[0.62rem] font-semibold text-pumpkin-50"
            >
              <Plus className="h-3 w-3" /> New
            </button>
          </div>

          {creating ? (
            <div className="mt-2 space-y-2 rounded-xl border border-white/10 bg-black/30 p-2.5">
              <input
                value={newName}
                onChange={(event) => setNewName(event.target.value.slice(0, 60))}
                placeholder="Group name"
                aria-label="New group name"
                className="field text-[0.74rem]"
              />
              <div>
                <p className="text-[0.6rem] uppercase tracking-widest text-pumpkin-50/40">
                  add people
                </p>
                <div className="mt-1 max-h-32 space-y-1 overflow-y-auto pr-0.5">
                  {invitable.length === 0 ? (
                    <p className="py-2 text-[0.64rem] text-pumpkin-50/35">
                      No other accounts yet.
                    </p>
                  ) : (
                    invitable.map((person) => {
                      const on = picked.includes(person.id);
                      return (
                        <button
                          key={person.id}
                          type="button"
                          onClick={() =>
                            setPicked((previous) =>
                              on ? previous.filter((id) => id !== person.id) : [...previous, person.id],
                            )
                          }
                          className={`flex w-full items-center gap-2 rounded-lg border px-2 py-1 text-left transition ${
                            on
                              ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                              : "border-white/[0.07] bg-white/[0.03]"
                          }`}
                        >
                          <span
                            className={`grid h-3.5 w-3.5 place-items-center rounded border ${
                              on ? "border-[var(--accent)] bg-[var(--accent)] text-[#1b0c02]" : "border-white/25"
                            }`}
                          >
                            {on ? <Check className="h-2.5 w-2.5" /> : null}
                          </span>
                          <span className="min-w-0 flex-1 truncate text-[0.68rem] text-pumpkin-50/80">
                            {person.displayName}
                            <span className="ml-1 text-pumpkin-50/35">@{person.username}</span>
                          </span>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => void create()}
                  disabled={busy === "create"}
                  className="btn-accent flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-[0.66rem] font-bold disabled:opacity-60"
                >
                  {busy === "create" ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />}
                  Create group
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCreating(false);
                    setPicked([]);
                    setNewName("");
                  }}
                  className="btn-ghost rounded-lg px-2 py-1.5 text-[0.66rem] font-semibold text-pumpkin-50/70"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : null}

          {groups.length === 0 ? (
            <p className="mt-2 text-[0.68rem] leading-relaxed text-pumpkin-50/40">
              No groups yet. Create one and add the people you want inside — nobody else can see it.
            </p>
          ) : (
            <ul className="mt-2 space-y-1">
              {groups.map((group) => (
                <li key={group.id}>
                  <button
                    type="button"
                    onClick={() => setActiveId(group.id)}
                    className={`flex w-full items-center gap-2 rounded-xl border px-2 py-1.5 text-left transition ${
                      activeId === group.id
                        ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                        : "border-transparent hover:bg-white/[0.04]"
                    }`}
                  >
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-white/10 bg-black/30 text-[var(--accent)]">
                      {group.role === "owner" ? <Crown className="h-3.5 w-3.5" /> : <Users className="h-3.5 w-3.5" />}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[0.74rem] font-semibold text-pumpkin-50">
                        {group.name}
                      </span>
                      <span className="block truncate text-[0.6rem] text-pumpkin-50/40">
                        {group.lastMessage
                          ? `${group.lastMessage.mine ? "you: " : ""}${group.lastMessage.body}`
                          : `${group.members.length} members`}
                      </span>
                    </span>
                    <span className="shrink-0 rounded-full border border-white/10 px-1.5 text-[0.55rem] text-pumpkin-50/40">
                      {group.members.length}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-2 flex items-center gap-1 text-[0.6rem] text-pumpkin-50/30">
            <Lock className="h-2.5 w-2.5" /> Private — visible only to members.
          </p>
        </section>
      </div>

      <section className="glass flex min-h-[460px] flex-col overflow-hidden rounded-2xl">
        {active ? (
          <>
            <div className="flex flex-wrap items-center gap-2 border-b border-white/10 bg-black/30 px-3 py-2.5">
              <span className="grid h-8 w-8 place-items-center rounded-lg border border-[var(--accent-line)] bg-[var(--accent-soft)] text-[var(--accent)]">
                {isOwner ? <Crown className="h-4 w-4" /> : <Users className="h-4 w-4" />}
              </span>
              <div className="min-w-0 flex-1">
                {renaming ? (
                  <div className="flex items-center gap-1.5">
                    <input
                      value={renameValue}
                      onChange={(event) => setRenameValue(event.target.value.slice(0, 60))}
                      aria-label="Group name"
                      className="field py-1 text-[0.76rem]"
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => void rename()}
                      disabled={busy === "rename"}
                      className="btn-accent rounded-lg px-2 py-1 text-[0.64rem] font-bold disabled:opacity-60"
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      onClick={() => setRenaming(false)}
                      className="rounded-lg px-1.5 py-1 text-pumpkin-50/50"
                      aria-label="Cancel rename"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ) : (
                  <p className="flex items-center gap-1.5 truncate text-sm font-bold text-pumpkin-50">
                    {active.name}
                    {isOwner ? (
                      <button
                        type="button"
                        onClick={() => {
                          setRenameValue(active.name);
                          setRenaming(true);
                        }}
                        aria-label="Rename group"
                        className="text-pumpkin-50/35 transition hover:text-[var(--accent)]"
                      >
                        <Pencil className="h-3 w-3" />
                      </button>
                    ) : null}
                  </p>
                )}
                <p className="truncate text-[0.6rem] text-pumpkin-50/40">
                  {active.members.length} member{active.members.length === 1 ? "" : "s"} ·{" "}
                  {active.role === "owner" ? "you own this group" : "private group"}
                </p>
              </div>
              <button
                type="button"
                onClick={() => void memberAction("leave", user.id, "You left the group")}
                className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/[0.04] px-2 py-1 text-[0.62rem] font-semibold text-pumpkin-50/60 hover:text-pumpkin-50"
              >
                <LogOut className="h-3 w-3" /> Leave
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-1.5 border-b border-white/[0.07] bg-black/20 px-3 py-1.5">
              {active.members.map((member) => (
                <span
                  key={member.id}
                  className="flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] py-0.5 pl-0.5 pr-1.5 text-[0.62rem] text-pumpkin-50/70"
                >
                  <AvatarView avatar={member.avatar} name={member.displayName} size={16} effect={member.effect} ring={false} />
                  {member.displayName}
                  {member.role === "owner" ? <Crown className="h-2.5 w-2.5 text-[var(--accent)]" /> : null}
                  {isOwner && member.role !== "owner" ? (
                    <button
                      type="button"
                      onClick={() => void memberAction("remove", member.id, `${member.displayName} removed`)}
                      aria-label={`Remove ${member.displayName}`}
                      className="text-pumpkin-50/25 hover:text-red-300"
                    >
                      <UserMinus className="h-2.5 w-2.5" />
                    </button>
                  ) : null}
                </span>
              ))}
              {isOwner ? (
                <span className="flex items-center gap-1">
                  <select
                    value={addingId}
                    onChange={(event) => setAddingId(event.target.value)}
                    aria-label="Add a member"
                    className="rounded-md border border-white/10 bg-black/40 px-1.5 py-0.5 text-[0.62rem] text-pumpkin-50/70"
                  >
                    <option value="">add person…</option>
                    {invitable
                      .filter((person) => !active.members.some((member) => member.id === person.id))
                      .map((person) => (
                        <option key={person.id} value={person.id} className="bg-[#140d09]">
                          {person.displayName}
                        </option>
                      ))}
                  </select>
                  {addingId ? (
                    <button
                      type="button"
                      onClick={() => void memberAction("add", addingId, "Member added")}
                      disabled={busy === `add:${addingId}`}
                      className="btn-accent flex items-center gap-1 rounded-md px-2 py-0.5 text-[0.62rem] font-bold disabled:opacity-60"
                    >
                      <UserPlus className="h-2.5 w-2.5" /> Add
                    </button>
                  ) : null}
                </span>
              ) : null}
            </div>

            <div ref={scrollRef} className="flex-1 space-y-2 overflow-y-auto bg-black/20 px-3 py-3">
              {messages.length === 0 ? (
                <p className="grid h-full place-items-center text-center text-[0.7rem] text-pumpkin-50/35">
                  No messages yet — say hello to the group.
                </p>
              ) : (
                messages.map((message) => (
                  <div key={message.id} className={`flex gap-2 ${message.mine ? "flex-row-reverse" : ""}`}>
                    <AvatarView
                      avatar={message.avatar}
                      name={message.author}
                      size={26}
                      effect={message.effect ?? "none"}
                      ring={Boolean(message.avatar)}
                    />
                    <div className={`max-w-[78%] ${message.mine ? "text-right" : ""}`}>
                      <p className={`text-[0.58rem] text-pumpkin-50/35 ${message.mine ? "text-right" : ""}`}>
                        {message.mine ? "you" : message.author}
                      </p>
                      <p
                        className={`mt-0.5 inline-block whitespace-pre-wrap break-words rounded-xl border px-2.5 py-1.5 text-left text-[0.78rem] leading-relaxed ${
                          message.mine
                            ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                            : "border-white/[0.07] bg-white/[0.05] text-pumpkin-50/85"
                        }`}
                      >
                        {message.body}
                      </p>
                    </div>
                  </div>
                ))
              )}
              {threadError ? (
                <p className="rounded-lg border border-red-400/25 bg-red-500/10 px-2.5 py-1.5 text-[0.66rem] text-red-200/80">
                  {threadError}
                </p>
              ) : null}
            </div>

            <form
              onSubmit={(event) => {
                event.preventDefault();
                void send();
              }}
              className="flex items-center gap-2 border-t border-white/10 bg-black/30 px-3 py-2.5"
            >
              <input
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                placeholder={`Message ${active.name}…`}
                maxLength={800}
                aria-label="Group message"
                className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/45 px-3 py-2.5 text-xs text-pumpkin-50 outline-none placeholder:text-pumpkin-50/30 focus:border-[var(--accent-line)]"
              />
              <button
                type="submit"
                disabled={sending || !draft.trim()}
                className="btn-accent flex items-center gap-1.5 rounded-xl px-3.5 py-2.5 text-xs font-bold disabled:opacity-50"
              >
                {sending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                Send
              </button>
            </form>

            {isOwner ? (
              <div className="flex items-center justify-between gap-2 border-t border-white/10 bg-black/30 px-3 py-1.5">
                <span className="text-[0.6rem] text-pumpkin-50/30">
                  Owner controls · delete removes the group for everyone
                </span>
                <button
                  type="button"
                  onClick={() => void removeGroup()}
                  disabled={busy === "delete"}
                  className="flex items-center gap-1 rounded-md border border-red-400/30 bg-red-500/10 px-2 py-0.5 text-[0.6rem] font-semibold text-red-200/80 hover:bg-red-500/20 disabled:opacity-60"
                >
                  <Trash2 className="h-2.5 w-2.5" /> Delete group
                </button>
              </div>
            ) : null}
          </>
        ) : (
          <div className="grid flex-1 place-items-center px-4 py-12 text-center">
            <div>
              <Users className="mx-auto h-7 w-7 text-pumpkin-50/20" />
              <p className="mt-2 text-sm font-semibold text-pumpkin-50/70">No group selected</p>
              <p className="mx-auto mt-1 max-w-sm text-[0.7rem] leading-relaxed text-pumpkin-50/40">
                Create a private group and add the people you want in it. Only members can see the
                name and the messages.
              </p>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
