"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  Check,
  ExternalLink,
  Film,
  Image as ImageIcon,
  Link2,
  Loader2,
  RotateCcw,
  Save,
  Sparkles,
  Trash2,
  Upload,
  Wand2,
} from "lucide-react";
import { useSettings } from "@/components/providers";
import { useAccount } from "@/lib/account";
import { BannerView } from "@/components/banner-view";
import {
  BANNER_PRESETS,
  DEFAULT_BANNER,
  IMAGE_TYPES,
  MEDIA_LIMITS,
  VIDEO_TYPES,
  presetById,
  type Banner,
} from "@/lib/banners";

type UploadRow = {
  id: string;
  mime: string;
  kind: "video" | "image";
  name: string;
  bytes: number;
  createdAt: string;
};

function humanSize(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function BannerStudio() {
  const { settings, save, notify, saving } = useSettings();
  const { user } = useAccount();
  const [draft, setDraft] = useState<Banner>(settings.banner ?? DEFAULT_BANNER);
  const [uploads, setUploads] = useState<UploadRow[]>([]);
  const [loadingUploads, setLoadingUploads] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const loadUploads = useCallback(async () => {
    try {
      const response = await fetch("/api/media", { cache: "no-store" });
      const data = (await response.json()) as { uploads?: UploadRow[] };
      if (data.uploads) setUploads(data.uploads);
    } catch {
      // library stays empty if the API is unreachable
    } finally {
      setLoadingUploads(false);
    }
  }, []);

  useEffect(() => {
    void loadUploads();
  }, [loadUploads]);

  const update = <K extends keyof Banner>(key: K, value: Banner[K]) =>
    setDraft((previous) => ({ ...previous, [key]: value }));

  const uploadFile = async (file: File) => {
    setUploading(true);
    try {
      const body = new FormData();
      body.append("file", file);
      const response = await fetch("/api/media", { method: "POST", body });
      const data = (await response.json()) as { media?: UploadRow & { url: string }; error?: string };
      if (!response.ok || !data.media) {
        notify(data.error ?? "Upload failed");
        return;
      }
      setUploads((previous) => [data.media as UploadRow, ...previous]);
      setDraft((previous) => ({
        ...previous,
        kind: "upload",
        mediaId: data.media!.id,
        animated: data.media!.kind === "video" || data.media!.mime === "image/gif",
      }));
      notify("Banner uploaded — press save to keep it");
    } catch {
      notify("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const removeUpload = async (row: UploadRow) => {
    setUploads((previous) => previous.filter((item) => item.id !== row.id));
    if (draft.mediaId === row.id) {
      setDraft((previous) => ({ ...previous, mediaId: "", kind: "preset" }));
    }
    try {
      await fetch(`/api/media?id=${row.id}`, { method: "DELETE" });
      notify("Upload removed");
    } catch {
      notify("Could not remove that upload");
    }
  };

  const applyBanner = async () => {
    if (draft.kind === "upload" && !draft.mediaId) {
      notify("Pick an uploaded video or GIF first");
      return;
    }
    if (draft.kind === "url") {
      if (!/^https:\/\//i.test(draft.url)) {
        notify("Media links need to start with https://");
        return;
      }
    }
    await save({ ...settings, banner: draft });
  };

  const activePreset = presetById(draft.presetId);

  return (
    <div className="space-y-4">
      <section className="glass rounded-[26px] px-5 py-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="section-label">banners · header studio</p>
            <h2 className="mt-1 text-2xl font-black tracking-tight text-pumpkin-50 sm:text-3xl">
              Dress up the top of the page
            </h2>
            <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-pumpkin-50/50">
              Pick a premade animated scene, or drop in your own video, GIF or image. Your banner sits
              under the pumpkin title and shows on every page.
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => void applyBanner()}
              disabled={saving}
              className="btn-accent flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold disabled:opacity-60"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Use this banner
            </button>
            <button
              type="button"
              onClick={() => {
                setDraft(DEFAULT_BANNER);
                notify("Studio reset to the default banner");
              }}
              className="btn-ghost flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-pumpkin-50/75"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </button>
          </div>
        </div>
      </section>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between gap-2">
              <p className="section-label">live preview</p>
              <span className="rounded-full border border-white/10 bg-black/30 px-2 py-0.5 text-[0.6rem] text-pumpkin-50/45">
                {draft.kind === "preset" ? activePreset.name : draft.kind === "upload" ? "your upload" : "external link"}
              </span>
            </div>
            <div className="mt-2">
              <BannerView banner={draft} />
            </div>
            <p className="mt-2 text-[0.64rem] text-pumpkin-50/35">
              Previews animate exactly like the real header. Text is optional and sits bottom-left.
            </p>
          </section>

          <section className="glass rounded-2xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="section-label flex items-center gap-1.5">
                  <Sparkles className="h-3 w-3" /> premade banners
                </p>
                <p className="mt-1 text-[0.68rem] text-pumpkin-50/40">
                  Animated scenes run on SVG loops — no extra data usage.
                </p>
              </div>
              <span className="rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[0.6rem] text-pumpkin-50/45">
                {BANNER_PRESETS.length} designs
              </span>
            </div>

            <div className="mt-3 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
              {BANNER_PRESETS.map((preset) => {
                const selected = draft.kind === "preset" && draft.presetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() =>
                      setDraft((previous) => ({
                        ...previous,
                        kind: "preset",
                        presetId: preset.id,
                        animated: preset.animated,
                      }))
                    }
                    className={`group overflow-hidden rounded-xl border text-left transition ${
                      selected
                        ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                        : "border-white/[0.07] bg-black/25 hover:border-white/20"
                    }`}
                  >
                    <div className="relative h-16 w-full overflow-hidden">
                      <BannerView
                        banner={{
                          ...DEFAULT_BANNER,
                          kind: "preset",
                          presetId: preset.id,
                          height: 120,
                          overlay: 0.2,
                          title: "",
                          subtitle: "",
                        }}
                        rounded={false}
                        className="!h-16 !border-0"
                      />
                      {selected ? (
                        <span className="absolute right-1.5 top-1.5 grid h-4 w-4 place-items-center rounded-full bg-[var(--accent)] text-[#1b0c02]">
                          <Check className="h-2.5 w-2.5" />
                        </span>
                      ) : null}
                      {preset.animated ? (
                        <span className="absolute left-1.5 top-1.5 rounded-full bg-black/60 px-1.5 py-0.5 text-[0.52rem] font-bold uppercase tracking-wider text-white/70">
                          animated
                        </span>
                      ) : null}
                    </div>
                    <div className="px-2.5 py-2">
                      <p className="text-[0.74rem] font-semibold text-pumpkin-50">{preset.name}</p>
                      <p className="mt-0.5 line-clamp-2 text-[0.62rem] leading-snug text-pumpkin-50/40">
                        {preset.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          <section className="glass rounded-2xl p-4">
            <p className="section-label flex items-center gap-1.5">
              <Upload className="h-3 w-3" /> your media
            </p>
            <div
              onDragOver={(event) => {
                event.preventDefault();
                setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={(event) => {
                event.preventDefault();
                setDragging(false);
                const file = event.dataTransfer.files?.[0];
                if (file) void uploadFile(file);
              }}
              className={`mt-2 flex flex-col items-center justify-center rounded-xl border border-dashed px-4 py-6 text-center transition ${
                dragging
                  ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                  : "border-white/15 bg-black/25"
              }`}
            >
              <span className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-black/40 text-[var(--accent)]">
                {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Film className="h-4 w-4" />}
              </span>
              <p className="mt-2 text-[0.78rem] font-semibold text-pumpkin-50">
                {uploading ? "Uploading your banner…" : "Drop a video or GIF here"}
              </p>
              <p className="mt-1 max-w-sm text-[0.64rem] leading-relaxed text-pumpkin-50/40">
                MP4/WebM/MOV up to {Math.round(MEDIA_LIMITS.video / (1024 * 1024))}MB, GIF/PNG/JPG/WebP
                up to {Math.round(MEDIA_LIMITS.image / (1024 * 1024))}MB. Files are stored on this
                pumpkin server and stream back through <code className="text-pumpkin-50/55">/api/media</code>.
              </p>
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                disabled={uploading}
                className="btn-accent mt-2.5 rounded-lg px-3 py-1.5 text-[0.7rem] font-bold disabled:opacity-60"
              >
                Choose a file
              </button>
              <input
                ref={inputRef}
                type="file"
                accept={[...VIDEO_TYPES, ...IMAGE_TYPES].join(",")}
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) void uploadFile(file);
                  event.target.value = "";
                }}
              />
            </div>

            <div className="mt-3">
              <p className="section-label">library</p>
              {loadingUploads ? (
                <p className="mt-2 flex items-center gap-1.5 text-[0.7rem] text-pumpkin-50/40">
                  <Loader2 className="h-3 w-3 animate-spin" /> loading uploads
                </p>
              ) : uploads.length === 0 ? (
                <p className="mt-2 text-[0.7rem] text-pumpkin-50/35">
                  Nothing uploaded yet. Videos and GIFs you add show up here.
                </p>
              ) : (
                <ul className="mt-2 space-y-1.5">
                  {uploads.map((row) => {
                    const selected = draft.kind === "upload" && draft.mediaId === row.id;
                    return (
                      <li
                        key={row.id}
                        className={`flex items-center gap-2 rounded-xl border px-2.5 py-2 ${
                          selected
                            ? "border-[var(--accent-line)] bg-[var(--accent-soft)]"
                            : "border-white/[0.07] bg-black/25"
                        }`}
                      >
                        <span className="grid h-8 w-10 shrink-0 place-items-center overflow-hidden rounded-md border border-white/10 bg-black">
                          {row.kind === "image" ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={`/api/media/${row.id}`} alt="" className="h-full w-full object-cover" />
                          ) : (
                            <video src={`/api/media/${row.id}`} muted playsInline className="h-full w-full object-cover" />
                          )}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setDraft((previous) => ({
                              ...previous,
                              kind: "upload",
                              mediaId: row.id,
                              animated: row.kind === "video" || row.mime === "image/gif",
                            }))
                          }
                          className="min-w-0 flex-1 text-left"
                        >
                          <span className="block truncate text-[0.72rem] font-semibold text-pumpkin-50">
                            {row.name}
                          </span>
                          <span className="block text-[0.6rem] text-pumpkin-50/40">
                            {row.kind === "video" ? "video" : "image"} · {humanSize(row.bytes)}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => void removeUpload(row)}
                          aria-label={`Delete ${row.name}`}
                          className="text-pumpkin-50/30 transition hover:text-red-300"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
              {!user ? (
                <p className="mt-2 rounded-lg border border-white/10 bg-black/25 px-2.5 py-2 text-[0.62rem] leading-relaxed text-pumpkin-50/40">
                  You are not signed in, so uploads are visible to everyone and may be cleared.
                  <Link href="/account" className="ml-1 font-semibold text-[var(--accent)] hover:underline">
                    Create an account
                  </Link>{" "}
                  to keep up to 12 files in your own library.
                </p>
              ) : null}
            </div>
          </section>
        </div>

        <aside className="space-y-3">
          <section className="glass rounded-2xl p-4">
            <p className="section-label flex items-center gap-1.5">
              <ImageIcon className="h-3 w-3" /> banner options
            </p>

            <label className="mt-3 block">
              <span className="section-label">height</span>
              <div className="mt-1.5 grid grid-cols-3 gap-1.5">
                {([120, 170, 230] as const).map((height) => (
                  <button
                    key={height}
                    type="button"
                    onClick={() => update("height", height)}
                    className={`rounded-lg border px-2 py-1.5 text-[0.68rem] font-semibold transition ${
                      draft.height === height
                        ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                        : "border-white/10 bg-white/[0.03] text-pumpkin-50/55 hover:text-pumpkin-50"
                    }`}
                  >
                    {height === 120 ? "Slim" : height === 170 ? "Standard" : "Tall"}
                  </button>
                ))}
              </div>
            </label>

            <label className="mt-3 block">
              <span className="section-label">media fit</span>
              <div className="mt-1.5 grid grid-cols-2 gap-1.5">
                {(["cover", "contain"] as const).map((fit) => (
                  <button
                    key={fit}
                    type="button"
                    onClick={() => update("fit", fit)}
                    className={`rounded-lg border px-2 py-1.5 text-[0.68rem] font-semibold capitalize transition ${
                      draft.fit === fit
                        ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-pumpkin-50"
                        : "border-white/10 bg-white/[0.03] text-pumpkin-50/55 hover:text-pumpkin-50"
                    }`}
                  >
                    {fit}
                  </button>
                ))}
              </div>
            </label>

            <label className="mt-3 block">
              <span className="section-label">darkness overlay · {Math.round(draft.overlay * 100)}%</span>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={draft.overlay}
                onChange={(event) => update("overlay", Number(event.target.value))}
                className="mt-2 w-full accent-[var(--accent)]"
              />
            </label>

            <label className="mt-3 flex items-center justify-between gap-2 rounded-lg border border-white/[0.07] bg-black/25 px-2.5 py-2">
              <span className="text-[0.72rem] font-semibold text-pumpkin-50">Play animation</span>
              <button
                type="button"
                role="switch"
                aria-checked={draft.animated}
                onClick={() => update("animated", !draft.animated)}
                className={`relative h-5 w-9 shrink-0 rounded-full border transition ${
                  draft.animated ? "border-[var(--accent-line)] bg-[var(--accent)]" : "border-white/15 bg-white/10"
                }`}
              >
                <span
                  className={`absolute top-0.5 h-3.5 w-3.5 rounded-full transition-all ${
                    draft.animated ? "left-[18px] bg-[#180d06]" : "left-0.5 bg-white/60"
                  }`}
                />
              </button>
            </label>
            <p className="mt-1 text-[0.6rem] leading-relaxed text-pumpkin-50/35">
              Turning animation off pauses videos and freezes GIFs on a still frame.
            </p>

            <label className="mt-3 block">
              <span className="section-label">banner title (optional)</span>
              <input
                value={draft.title}
                onChange={(event) => update("title", event.target.value.slice(0, 60))}
                placeholder="Happy Halloween"
                className="field mt-1.5"
              />
            </label>
            <label className="mt-2 block">
              <span className="section-label">subtitle (optional)</span>
              <input
                value={draft.subtitle}
                onChange={(event) => update("subtitle", event.target.value.slice(0, 90))}
                placeholder="three rooms, four activities, one pumpkin"
                className="field mt-1.5"
              />
            </label>
          </section>

          <section className="glass rounded-2xl p-4">
            <p className="section-label flex items-center gap-1.5">
              <Link2 className="h-3 w-3" /> use a link instead
            </p>
            <p className="mt-1 text-[0.66rem] leading-relaxed text-pumpkin-50/40">
              Point at a hosted MP4, GIF or image (https only). Handy for media too big to upload.
            </p>
            <input
              value={draft.url}
              onChange={(event) => {
                update("url", event.target.value);
                update("kind", "url");
              }}
              placeholder="https://example.com/banner.mp4"
              className="field mt-2 font-mono text-[0.72rem]"
            />
            <div className="mt-2 flex flex-wrap gap-1.5">
              {[
                { label: "Halloween (Wikimedia)", url: "https://upload.wikimedia.org/wikipedia/commons/6/6b/Halloween-Banner.png" },
                { label: "Jack-o-lantern", url: "https://upload.wikimedia.org/wikipedia/commons/9/91/Pumpkin_%28Jack-o%27-lantern%29.jpg" },
              ].map((sample) => (
                <button
                  key={sample.url}
                  type="button"
                  onClick={() => {
                    setDraft((previous) => ({ ...previous, kind: "url", url: sample.url, presetId: previous.presetId }));
                    notify("Sample link loaded — press save to keep it");
                  }}
                  className="flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[0.62rem] text-pumpkin-50/55 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50"
                >
                  <ExternalLink className="h-2.5 w-2.5" /> {sample.label}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => {
                setDraft((previous) => ({ ...previous, kind: "preset" }));
                notify("Back to premade banners");
              }}
              className="btn-ghost mt-2 flex w-full items-center justify-center gap-1.5 rounded-lg px-2.5 py-2 text-[0.68rem] font-semibold text-pumpkin-50/70"
            >
              <Wand2 className="h-3 w-3" /> Back to premade banners
            </button>
          </section>

          <section className="glass rounded-2xl p-4">
            <p className="section-label">currently live</p>
            <p className="mt-1 text-[0.72rem] text-pumpkin-50/55">
              {settings.banner?.kind === "preset" || !settings.banner
                ? presetById(settings.banner?.presetId ?? DEFAULT_BANNER.presetId).name
                : settings.banner.kind === "upload"
                  ? "Your uploaded media"
                  : "External media link"}
            </p>
            <Link
              href="/"
              className="mt-2 flex items-center justify-between rounded-lg border border-white/10 bg-black/25 px-2.5 py-2 text-[0.68rem] font-semibold text-pumpkin-50/70 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50"
            >
              See it on the home page <ArrowRight className="h-3 w-3" />
            </Link>
          </section>
        </aside>
      </div>
    </div>
  );
}
