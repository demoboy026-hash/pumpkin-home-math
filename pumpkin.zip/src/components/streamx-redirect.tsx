"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { ArrowRight, ExternalLink, ShieldCheck, Tv, X } from "lucide-react";
import { STREAMX_URL } from "@/lib/constants";

const BROWSER_PATH = `/browse?url=${encodeURIComponent(STREAMX_URL)}`;

export function StreamxRedirect() {
  const router = useRouter();
  const [count, setCount] = useState(3);
  const [cancelled, setCancelled] = useState(false);

  useEffect(() => {
    if (cancelled) return;
    if (count <= 0) {
      router.push(BROWSER_PATH);
      return;
    }
    const timer = setTimeout(() => setCount((value) => value - 1), 1000);
    return () => clearTimeout(timer);
  }, [cancelled, count, router]);

  return (
    <section className="glass relative overflow-hidden rounded-[26px] p-5 sm:p-8">
      <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-[var(--accent-glow)] opacity-30 blur-[80px]" />
      <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="max-w-xl">
          <span className="accent-chip inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.18em]">
            <Tv className="h-3 w-3" /> streamx redirect
          </span>
          <h2 className="mt-3 text-3xl font-black tracking-tight text-pumpkin-50 sm:text-4xl">
            streamxtv.net
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-pumpkin-50/55">
            The mirror link requested for StreamX. We route it through the pumpkin browser so the
            unblocked tab keeps your favorites, panic key and shields intact.
          </p>
          <div className="mt-3 flex items-center gap-2 rounded-xl border border-white/10 bg-black/40 px-3 py-2">
            <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" />
            <code className="min-w-0 flex-1 truncate text-[0.7rem] text-pumpkin-50/55">{STREAMX_URL}</code>
            <a
              href={STREAMX_URL}
              target="_blank"
              rel="noreferrer noopener"
              className="text-pumpkin-50/40 transition hover:text-pumpkin-50"
              aria-label="Open StreamX directly"
            >
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-2">
            <Link
              href={BROWSER_PATH}
              className="btn-accent inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold"
            >
              Open in pumpkin browser <ArrowRight className="h-4 w-4" />
            </Link>
            <button
              type="button"
              onClick={() => {
                setCancelled(true);
              }}
              className="btn-ghost inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-pumpkin-50/75"
            >
              <X className="h-3.5 w-3.5" />
              {cancelled ? "Redirect paused" : "Stay on this page"}
            </button>
          </div>
          {!cancelled ? (
            <p className="mt-3 text-[0.7rem] text-pumpkin-50/40">
              Redirecting to the embedded browser in{" "}
              <strong className="font-semibold text-[var(--accent)]">{Math.max(count, 0)}s</strong>.
            </p>
          ) : (
            <p className="mt-3 text-[0.7rem] text-pumpkin-50/40">
              Auto-redirect paused. Use the button above whenever you are ready.
            </p>
          )}
        </div>

        <div className="w-full max-w-sm space-y-2.5">
          {[
            { step: "01", title: "Loads inside pumpkin", body: "No new window, no lost session." },
            {
              step: "02",
              title: "Shield available",
              body: "If the player frame is refused, tap Shield in the address bar.",
            },
            {
              step: "03",
              title: "Panic stays armed",
              body: "Your keybind still fires on this page and inside the browser shell.",
            },
          ].map((item) => (
            <div
              key={item.step}
              className="flex items-start gap-3 rounded-xl border border-white/[0.07] bg-black/25 p-3"
            >
              <span className="mt-0.5 rounded-md border border-[var(--accent-line)] bg-[var(--accent-soft)] px-1.5 py-0.5 font-mono text-[0.62rem] text-[var(--accent)]">
                {item.step}
              </span>
              <span>
                <span className="block text-[0.78rem] font-semibold text-pumpkin-50">{item.title}</span>
                <span className="block text-[0.68rem] leading-relaxed text-pumpkin-50/45">{item.body}</span>
              </span>
            </div>
          ))}
          <p className="flex items-center gap-1.5 px-1 text-[0.62rem] text-pumpkin-50/30">
            <ShieldCheck className="h-3 w-3" />
            The hash fragment from the original link is preserved.
          </p>
        </div>
      </div>
    </section>
  );
}
