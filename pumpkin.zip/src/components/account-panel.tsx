"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import {
  Bookmark,
  CalendarDays,
  Check,
  Eye,
  EyeOff,
  KeyRound,
  Loader2,
  LogIn,
  LogOut,
  MessagesSquare,
  Save,
  ShieldCheck,
  Sparkles,
  Trash2,
  UserPlus,
  Waypoints,
} from "lucide-react";
import {
  adoptSession,
  forgetSavedSession,
  invalidateAccountRequests,
  restoreSession,
  useAccount,
} from "@/lib/account";
import { useRouter } from "next/navigation";
import { storeSessionToken } from "@/lib/session-client";
import { useSettings } from "@/components/providers";
import { AvatarView } from "@/components/avatar-view";
import { AvatarPicker } from "@/components/avatar-picker";
import { NICKNAME_KEY } from "@/lib/settings";

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return "recently";
  }
}

function Field({
  label,
  type = "text",
  value,
  onChange,
  placeholder,
  autoComplete,
  hint,
}: {
  label: string;
  type?: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  autoComplete?: string;
  hint?: string;
}) {
  const [reveal, setReveal] = useState(false);
  const isPassword = type === "password";
  return (
    <label className="block">
      <span className="section-label">{label}</span>
      <span className="relative mt-1.5 flex items-center">
        <input
          type={isPassword && reveal ? "text" : type}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className="field pr-9"
        />
        {isPassword ? (
          <button
            type="button"
            onClick={() => setReveal((current) => !current)}
            aria-label={reveal ? "Hide password" : "Show password"}
            className="absolute right-2 text-pumpkin-50/35 transition hover:text-pumpkin-50"
          >
            {reveal ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
          </button>
        ) : null}
      </span>
      {hint ? <span className="mt-1 block text-[0.62rem] text-pumpkin-50/35">{hint}</span> : null}
    </label>
  );
}

function AuthForms() {
  const { notify } = useSettings();
  const router = useRouter();
  const { refresh, setUser } = useAccount();
  const [tab, setTab] = useState<"login" | "signup">("signup");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [errorCode, setErrorCode] = useState<string | null>(null);
  const [savedAs, setSavedAs] = useState<{ username: string; displayName: string } | null>(null);

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      const endpoint = tab === "signup" ? "/api/auth/signup" : "/api/auth/login";
      const payload =
        tab === "signup" ? { username, password, displayName } : { username, password };
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as {
        error?: string;
        code?: string;
        adopted?: boolean;
        existing?: boolean;
        token?: string;
        user?: {
          id: string;
          username: string;
          displayName: string;
          createdAt: string;
        };
      };
      if (!response.ok) {
        setError(data.error ?? "Something went wrong.");
        setErrorCode(data.code ?? null);
        return;
      }
      if (!data.user) {
        setError("The server did not confirm the account. Try signing in again.");
        return;
      }

      // Take the session from the sign-in response itself: no reload, and no
      // waiting on a second request that a stale one could overwrite.
      adoptSession(data.user, data.token);
      setUser(data.user);
      setError(null);
      setSavedAs({
        username: data.user.username,
        displayName: data.user.displayName || username,
      });
      notify(
        data.existing
          ? "That account already existed — you are signed in"
          : tab === "signup"
            ? "Account created and saved"
            : "Welcome back",
      );

      // Background reconciliation (settings, banner, avatar) without changing auth.
      void refresh(true);
      router.refresh();
    } catch {
      setError("Network hiccup. Try again.");
    } finally {
      setBusy(false);
    }
  };

  if (savedAs) {
    return (
      <div className="glass rounded-2xl p-4 text-center">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-full border border-emerald-400/30 bg-emerald-400/10 text-emerald-300">
          <Check className="h-6 w-6" />
        </span>
        <p className="mt-2 text-base font-bold text-pumpkin-50">Account saved</p>
        <p className="mt-1 text-[0.75rem] text-pumpkin-50/55">
          Signed in as <strong className="text-pumpkin-50">@{savedAs.username}</strong>
          {savedAs.displayName ? ` (${savedAs.displayName})` : ""}.
        </p>
        <p className="mx-auto mt-1 max-w-xs text-[0.66rem] leading-relaxed text-pumpkin-50/40">
          Your favorites, panic key, banner and avatar are stored on this account and will load the
          next time you open pumpkin on this browser.
        </p>
        <button
          type="button"
          onClick={() => void refresh(true).then(() => router.refresh())}
          className="btn-accent mt-3 rounded-xl px-3.5 py-2 text-xs font-bold"
        >
          Continue
        </button>
      </div>
    );
  }

  return (
    <div className="glass rounded-2xl p-4">
      <div className="flex gap-1.5 rounded-xl border border-white/10 bg-black/35 p-1">
        <button
          type="button"
          onClick={() => setTab("signup")}
          className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold transition ${
            tab === "signup" ? "bg-[var(--accent-soft)] text-pumpkin-50" : "text-pumpkin-50/50"
          }`}
        >
          <UserPlus className="h-3.5 w-3.5" /> Create account
        </button>
        <button
          type="button"
          onClick={() => setTab("login")}
          className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold transition ${
            tab === "login" ? "bg-[var(--accent-soft)] text-pumpkin-50" : "text-pumpkin-50/50"
          }`}
        >
          <LogIn className="h-3.5 w-3.5" /> Sign in
        </button>
      </div>

      <form
        className="mt-3.5 space-y-2.5"
        onSubmit={(event) => {
          event.preventDefault();
          void submit();
        }}
      >
        <Field
          label="username"
          value={username}
          onChange={setUsername}
          placeholder="pumpkinfan"
          autoComplete="username"
          hint="3–24 characters: letters, numbers or underscores."
        />
        {tab === "signup" ? (
          <Field
            label="display name (chat)"
            value={displayName}
            onChange={setDisplayName}
            placeholder="Optional — shows in chat rooms"
          />
        ) : null}
        <Field
          label="password"
          type="password"
          value={password}
          onChange={setPassword}
          placeholder={tab === "signup" ? "At least 8 characters" : "Your password"}
          autoComplete={tab === "signup" ? "new-password" : "current-password"}
        />

        {error ? (
          <div className="rounded-lg border border-red-400/25 bg-red-500/10 px-2.5 py-2 text-[0.68rem] text-red-200/85">
            <p>{error}</p>
            {errorCode === "username_taken" ? (
              <button
                type="button"
                onClick={() => {
                  setTab("login");
                  setError(null);
                  setErrorCode(null);
                }}
                className="mt-1.5 font-semibold text-[var(--accent)] underline"
              >
                Sign in to that account instead
              </button>
            ) : null}
            {errorCode === "no_account" ? (
              <button
                type="button"
                onClick={() => {
                  setTab("signup");
                  setError(null);
                  setErrorCode(null);
                }}
                className="mt-1.5 font-semibold text-[var(--accent)] underline"
              >
                Create “{username || "this account"}” instead
              </button>
            ) : null}
          </div>
        ) : null}

        <button
          type="submit"
          disabled={busy}
          className="btn-accent flex w-full items-center justify-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-bold disabled:opacity-60"
        >
          {busy ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : tab === "signup" ? (
            <UserPlus className="h-4 w-4" />
          ) : (
            <LogIn className="h-4 w-4" />
          )}
          {tab === "signup" ? "Create my account" : "Sign in"}
        </button>
      </form>

      <div className="mt-3 rounded-xl border border-white/[0.07] bg-black/25 p-3 text-[0.66rem] leading-relaxed text-pumpkin-50/45">
        <p className="mb-1 flex items-center gap-1.5 font-semibold text-pumpkin-50/70">
          <ShieldCheck className="h-3 w-3 text-[var(--accent)]" /> what an account does
        </p>
        Your panic key, disguise, theme, browser favorites and chat name are stored on the server
        against your account. Sign in on any device and the same pumpkin is waiting. Creating an
        account keeps the favorites already saved on this device.
      </div>
    </div>
  );
}

export function AccountPanel() {
  const {
    user,
    stats,
    loading,
    refresh,
    setUser,
    unavailable,
    hasToken: hasStoredToken,
    lastError,
  } = useAccount();
  const [restoring, setRestoring] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);
  const { notify } = useSettings();
  const [displayName, setDisplayName] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (user) setDisplayName(user.displayName);
  }, [user]);

  const signOut = useCallback(async () => {
    setBusy("logout");
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      invalidateAccountRequests();
      storeSessionToken(null);
      forgetSavedSession();
      try {
        window.localStorage.removeItem(NICKNAME_KEY);
      } catch {
        // ignore storage errors
      }
      notify("Signed out");
      window.location.reload();
    } finally {
      setBusy(null);
    }
  }, [notify]);

  if (loading) {
    return (
      <div className="glass flex items-center justify-center gap-2 rounded-2xl px-4 py-16 text-xs text-pumpkin-50/45">
        <Loader2 className="h-4 w-4 animate-spin" /> checking your session
      </div>
    );
  }

  if (!user) {
    return (
      <div className="space-y-3">
        {unavailable ? (
          <div className="rounded-xl border border-amber-300/25 bg-amber-300/10 px-3 py-2.5 text-[0.7rem] leading-relaxed text-amber-100/85">
            <p className="font-semibold">Session store is warming up</p>
            <p className="mt-0.5 text-amber-100/65">
              Your saved login is still on this device. Give it a couple of seconds and retry.
            </p>
            <button
              type="button"
              onClick={() => void refresh(true)}
              className="mt-1.5 rounded-lg border border-amber-300/30 bg-amber-300/15 px-2.5 py-1 text-[0.66rem] font-semibold"
            >
              Retry now
            </button>
          </div>
        ) : null}
        <div className="rounded-xl border border-white/10 bg-black/25 px-3 py-2.5 text-[0.7rem] text-pumpkin-50/55">
          {hasStoredToken ? (
            <>
              <p className="flex flex-wrap items-center justify-between gap-2">
                <span>A saved session exists on this device.</span>
                <button
                  type="button"
                  onClick={async () => {
                    setRestoring(true);
                    setRestoreMessage(null);
                    const result = await restoreSession();
                    setRestoring(false);
                    setRestoreMessage(result.message);
                    if (result.ok) {
                      notify(result.message);
                    }
                  }}
                  disabled={restoring}
                  className="flex items-center gap-1.5 rounded-lg border border-[var(--accent-line)] bg-[var(--accent-soft)] px-2.5 py-1 text-[0.64rem] font-semibold text-pumpkin-50 disabled:opacity-60"
                >
                  {restoring ? <Loader2 className="h-3 w-3 animate-spin" /> : <KeyRound className="h-3 w-3" />}
                  {restoring ? "Restoring…" : "Restore"}
                </button>
              </p>
              {restoreMessage ? (
                <p
                  className={`mt-1.5 rounded-md px-2 py-1 text-[0.64rem] ${
                    restoreMessage.startsWith("Session restored")
                      ? "bg-emerald-400/10 text-emerald-200/85"
                      : "bg-red-400/10 text-red-200/85"
                  }`}
                >
                  {restoreMessage}
                </p>
              ) : null}
              {restoreMessage && !restoreMessage.startsWith("Session restored") ? (
                <button
                  type="button"
                  onClick={() => {
                    forgetSavedSession();
                    setRestoreMessage("Saved session cleared — create or sign in to an account below.");
                  }}
                  className="mt-1.5 text-[0.62rem] font-semibold text-pumpkin-50/50 underline hover:text-pumpkin-50"
                >
                  Forget that saved session
                </button>
              ) : null}
            </>
          ) : (
            <p className="text-[0.66rem] text-pumpkin-50/45">
              No saved session on this device — create an account or sign in below.
            </p>
          )}
          {lastError && !restoreMessage ? (
            <p className="mt-1.5 text-[0.62rem] text-amber-100/70">{lastError}</p>
          ) : null}
        </div>
        <AuthForms />
      </div>
    );
  }

  const saveProfile = async () => {
    setBusy("profile");
    try {
      const response = await fetch("/api/auth/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword,
          newPassword,
          displayName,
        }),
      });
      const data = (await response.json()) as { error?: string; user?: AccountUserLike };
      if (!response.ok) {
        notify(data.error ?? "Could not update account");
        return;
      }
      if (data.user) setUser({ ...data.user });
      setCurrentPassword("");
      setNewPassword("");
      notify("Account updated");
      void refresh();
    } catch {
      notify("Could not update account");
    } finally {
      setBusy(null);
    }
  };

  const deleteAccount = async () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    setBusy("delete");
    try {
      const response = await fetch("/api/auth/account", { method: "DELETE" });
      if (!response.ok) {
        notify("Could not delete the account");
        return;
      }
      notify("Account deleted");
      window.location.reload();
    } finally {
      setBusy(null);
    }
  };

  const statCards = [
    { label: "favorites", value: stats?.bookmarks ?? 0, icon: Bookmark, href: "/" },
    { label: "messages", value: stats?.messages ?? 0, icon: MessagesSquare, href: "/chat" },
    { label: "mirrors live", value: stats?.mirrors ?? 0, icon: Waypoints, href: "/mirrors" },
  ];

  return (
    <div className="space-y-3">
      <div className="glass relative overflow-hidden rounded-2xl p-4">
        <div className="pointer-events-none absolute -right-12 -top-16 h-40 w-40 rounded-full bg-[var(--accent-glow)] opacity-25 blur-[60px]" />
        <div className="relative flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <AvatarView avatar={user.avatar} name={user.displayName} size={52} effect={user.effect} />
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-lg font-bold text-pumpkin-50">{user.displayName}</h3>
                <span className="flex items-center gap-1 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-2 py-0.5 text-[0.6rem] font-semibold text-emerald-200">
                  <Check className="h-2.5 w-2.5" /> signed in
                </span>
              </div>
              <p className="text-[0.72rem] text-pumpkin-50/45">@{user.username}</p>
              <p className="mt-0.5 flex items-center gap-1 text-[0.64rem] text-pumpkin-50/30">
                <CalendarDays className="h-3 w-3" /> member since {formatDate(stats?.memberSince ?? user.createdAt)}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={signOut}
            disabled={busy === "logout"}
            className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.7rem] font-semibold text-pumpkin-50/75"
          >
            {busy === "logout" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <LogOut className="h-3.5 w-3.5" />}
            Sign out
          </button>
        </div>

        <div className="relative mt-3 grid grid-cols-3 gap-2">
          {statCards.map((card) => {
            const Icon = card.icon;
            return (
              <Link
                key={card.label}
                href={card.href}
                className="glass-soft rounded-xl px-2.5 py-2 transition hover:border-[var(--accent-line)]"
              >
                <Icon className="h-3.5 w-3.5 text-[var(--accent)]" />
                <p className="mt-1 text-base font-bold text-pumpkin-50">{card.value}</p>
                <p className="text-[0.58rem] uppercase tracking-[0.14em] text-pumpkin-50/40">
                  {card.label}
                </p>
              </Link>
            );
          })}
        </div>

        <p className="relative mt-3 flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/25 px-2.5 py-2 text-[0.64rem] text-pumpkin-50/45">
          <Sparkles className="h-3 w-3 text-[var(--accent)]" />
          This browser is signed in, so your pumpkin returns automatically next visit.
        </p>
      </div>

      <div className="glass rounded-2xl p-4">
        <p className="section-label flex items-center gap-1.5">
          <KeyRound className="h-3 w-3" /> profile & security
        </p>
        <div className="mt-2.5 space-y-2.5">
          <Field
            label="display name (chat)"
            value={displayName}
            onChange={setDisplayName}
            placeholder="Your chat name"
          />
          <div className="grid gap-2.5 sm:grid-cols-2">
            <Field
              label="current password"
              type="password"
              value={currentPassword}
              onChange={setCurrentPassword}
              placeholder="Required to change password"
              autoComplete="current-password"
            />
            <Field
              label="new password"
              type="password"
              value={newPassword}
              onChange={setNewPassword}
              placeholder="Leave blank to keep it"
              autoComplete="new-password"
            />
          </div>
          <button
            type="button"
            onClick={() => void saveProfile()}
            disabled={busy === "profile"}
            className="btn-accent flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold disabled:opacity-60"
          >
            {busy === "profile" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
            Save account
          </button>
        </div>
      </div>

      <AvatarPicker />

      <div className="rounded-2xl border border-red-400/20 bg-red-500/[0.06] p-4">
        <p className="section-label text-red-200/70">danger zone</p>
        <p className="mt-1 text-[0.68rem] leading-relaxed text-red-100/55">
          Deleting the account removes the login, every saved favorite and the settings attached to
          it. Chat messages already posted stay in the rooms.
        </p>
        <button
          type="button"
          onClick={() => void deleteAccount()}
          onBlur={() => setConfirmDelete(false)}
          disabled={busy === "delete"}
          className="mt-2.5 flex items-center gap-1.5 rounded-lg border border-red-400/30 bg-red-500/15 px-2.5 py-1.5 text-[0.7rem] font-semibold text-red-200 transition hover:bg-red-500/25"
        >
          {busy === "delete" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
          {confirmDelete ? "Click again to confirm" : "Delete my account"}
        </button>
      </div>
    </div>
  );
}

type AccountUserLike = { id: string; username: string; displayName: string; createdAt: string };

type LoginResult = { error?: string; code?: string; token?: string };
