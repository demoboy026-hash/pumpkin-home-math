import { FriendsPanel } from "@/components/friends-panel";

export const metadata = {
  title: "friends — pumpkin",
};

export default function FriendsPage() {
  return (
    <div className="space-y-4">
      <section className="glass relative overflow-hidden rounded-[26px] px-5 py-5">
        <div className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full bg-[var(--accent-glow)] opacity-25 blur-[80px]" />
        <div className="relative flex flex-wrap items-end justify-between gap-3">
          <div>
            <span className="accent-chip inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.18em]">
              friends · private chat
            </span>
            <h2 className="mt-3 text-2xl font-black tracking-tight text-pumpkin-50 sm:text-3xl">
              Your pumpkin circle
            </h2>
            <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-pumpkin-50/50">
              Send a request, accept one, then message privately. Direct threads are visible only to
              the two people in them — the group rooms stay public.
            </p>
          </div>
          <span className="flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-3 py-1.5 text-[0.66rem] text-emerald-200/80">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            requests and messages update automatically
          </span>
        </div>
      </section>

      <FriendsPanel />
    </div>
  );
}
