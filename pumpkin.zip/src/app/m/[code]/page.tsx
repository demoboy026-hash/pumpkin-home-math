import Link from "next/link";
import { notFound } from "next/navigation";
import { eq, sql } from "drizzle-orm";
import { ArrowRight, Waypoints } from "lucide-react";
import { db } from "@/db";
import { mirrors } from "@/db/schema";
import { BrowserWorkbench } from "@/components/browser-workbench";

export const dynamic = "force-dynamic";

export default async function MirrorPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;

  let mirror: typeof mirrors.$inferSelect | undefined;
  try {
    const rows = await db.select().from(mirrors).where(eq(mirrors.code, code)).limit(1);
    mirror = rows[0];
    if (mirror) {
      await db
        .update(mirrors)
        .set({ visits: sql`${mirrors.visits} + 1` })
        .where(eq(mirrors.id, mirror.id));
    }
  } catch {
    mirror = undefined;
  }

  if (!mirror) notFound();

  return (
    <div className="space-y-4">
      <section className="glass flex flex-wrap items-center justify-between gap-3 rounded-2xl px-4 py-3">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl border border-[var(--accent-line)] bg-[var(--accent-soft)] text-[var(--accent)]">
            <Waypoints className="h-4 w-4" />
          </span>
          <div>
            <p className="text-sm font-bold text-pumpkin-50">{mirror.label}</p>
            <p className="font-mono text-[0.66rem] text-pumpkin-50/40">
              /m/{mirror.code} · {mirror.visits + 1} visit{mirror.visits + 1 === 1 ? "" : "s"}
            </p>
          </div>
        </div>
        <Link
          href={mirror.target}
          className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.7rem] font-semibold text-pumpkin-50/75"
        >
          Jump to {mirror.target} <ArrowRight className="h-3 w-3" />
        </Link>
      </section>

      <BrowserWorkbench mirror={{ code: mirror.code, label: mirror.label }} />
    </div>
  );
}
