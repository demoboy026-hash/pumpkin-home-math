import Link from "next/link";
import { Compass, Waypoints } from "lucide-react";
import { PumpkinMark } from "@/components/pumpkin-mark";

export default function NotFound() {
  return (
    <div className="glass animate-rise rounded-[26px] px-6 py-14 text-center">
      <PumpkinMark className="mx-auto h-14 w-14 animate-float" />
      <p className="section-label mt-4">404 · missing page</p>
      <h2 className="mt-2 text-3xl font-black tracking-tight text-pumpkin-50">
        This patch is empty
      </h2>
      <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-pumpkin-50/50">
        The link you followed does not point at anything pumpkin knows about. It may have been a
        mirror that was retired — you can always forge a new one.
      </p>
      <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
        <Link href="/" className="btn-accent inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold">
          <Compass className="h-4 w-4" /> Open the browser
        </Link>
        <Link
          href="/mirrors"
          className="btn-ghost inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-pumpkin-50/80"
        >
          <Waypoints className="h-4 w-4" /> Make a mirror
        </Link>
      </div>
    </div>
  );
}
