import { Hash, MessagesSquare, ShieldCheck } from "lucide-react";
import { ChatRoom } from "@/components/chat-room";
import { GroupChats } from "@/components/group-chats";
import Link from "next/link";
import { Users } from "lucide-react";
import { OnlineCounter } from "@/components/online-counter";
import { CHAT_ROOMS } from "@/lib/types";

export const metadata = {
  title: "chatroom — pumpkin",
};

export default function ChatPage() {
  return (
    <div className="space-y-4">
      <section className="glass relative overflow-hidden rounded-[26px] px-5 py-5">
        <div className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full bg-[var(--accent-glow)] opacity-25 blur-[80px]" />
        <div className="relative flex flex-wrap items-end justify-between gap-3">
          <div>
            <span className="accent-chip inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.18em]">
              <MessagesSquare className="h-3 w-3" /> 3 rooms · one group
            </span>
            <h2 className="mt-3 text-2xl font-black tracking-tight text-pumpkin-50 sm:text-3xl">
              The pumpkin chatroom
            </h2>
            <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-pumpkin-50/50">
              Everything lands in the shared rooms below — main for the lobby, gaming for scores and
              dev for build notes. Pick a name and talk.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <OnlineCounter />
            <span className="rounded-full border border-white/10 bg-black/30 px-2.5 py-1 text-[0.62rem] text-pumpkin-50/45">
              messages refresh every 4.5s
            </span>
          </div>
        </div>
      </section>

      <section className="glass flex flex-wrap items-center justify-between gap-2 rounded-2xl px-4 py-3">
        <div>
          <p className="section-label">private groups</p>
          <p className="mt-0.5 text-[0.72rem] text-pumpkin-50/45">
            Make your own group, rename it, and choose exactly who can see it.
          </p>
        </div>
        <Link
          href="/groups"
          className="btn-accent flex items-center gap-1.5 rounded-xl px-3 py-2 text-[0.7rem] font-bold"
        >
          <Users className="h-3.5 w-3.5" /> Open group chats
        </Link>
      </section>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_250px]">
        <ChatRoom />

        <aside className="space-y-3">
          {CHAT_ROOMS.map((room) => (
            <div key={room.id} className="glass rounded-2xl p-3.5">
              <p className="flex items-center gap-1.5 text-[0.78rem] font-semibold text-pumpkin-50">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: room.dot }} />
                {room.name}
              </p>
              <p className="mt-1 text-[0.68rem] leading-relaxed text-pumpkin-50/40">{room.blurb}</p>
            </div>
          ))}
          <div className="rounded-2xl border border-white/[0.07] bg-black/25 p-3.5 text-[0.66rem] leading-relaxed text-pumpkin-50/40">
            <p className="mb-1 flex items-center gap-1.5 font-semibold text-pumpkin-50/65">
              <ShieldCheck className="h-3 w-3 text-[var(--accent)]" /> house rules
            </p>
            Keep it friendly, no doxxing, no spam. Messages are stored in this pumpkin instance only.
            <p className="mt-2 flex items-center gap-1 text-pumpkin-50/30">
              <Hash className="h-2.5 w-2.5" /> maximum 600 characters per message
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
