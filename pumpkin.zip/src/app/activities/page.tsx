import Link from "next/link";
import { Globe, Sparkles } from "lucide-react";
import { ActivityCatalog } from "@/components/activity-catalog";
import { ACTIVITIES } from "@/lib/activities";

export const metadata = {
  title: "study break — pumpkin",
};

const EXTERNAL = [
  { label: "itch.io", url: "https://itch.io" },
  { label: "Wikipedia", url: "https://en.wikipedia.org" },
  { label: "OpenStreetMap", url: "https://www.openstreetmap.org" },
];

export default function ActivitiesPage() {
  return (
    <div className="space-y-4">
      <section className="glass relative overflow-hidden rounded-[26px] p-5 sm:p-6">
        <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-[var(--accent-glow)] opacity-25 blur-[80px]" />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <span className="accent-chip inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.18em]">
              <Sparkles className="h-3 w-3" /> {ACTIVITIES.length} interactive activities
            </span>
            <h2 className="mt-3 text-2xl font-black tracking-tight text-pumpkin-50 sm:text-3xl">
              Study break activities
            </h2>
            <p className="mt-1.5 max-w-lg text-sm leading-relaxed text-pumpkin-50/50">
              Short interactive activities hosted on this server, so they open instantly during a
              break. Progress and best results stay on your device.
            </p>
          </div>
          <Link
            href="/"
            className="btn-ghost flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-pumpkin-50/80"
          >
            <Globe className="h-4 w-4 text-[var(--accent)]" />
            Open the browser instead
          </Link>
        </div>
      </section>

      <ActivityCatalog />

      <section className="glass rounded-2xl p-4">
        <p className="section-label">useful references</p>
        <p className="mt-1 text-[0.72rem] text-pumpkin-50/40">
          Reference sites open inside your browser with favourites and shield support.
        </p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {EXTERNAL.map((site) => (
            <Link
              key={site.url}
              href={`/browse?url=${encodeURIComponent(site.url)}`}
              className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[0.7rem] text-pumpkin-50/65 transition hover:border-[var(--accent-line)] hover:text-pumpkin-50"
            >
              {site.label}
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
