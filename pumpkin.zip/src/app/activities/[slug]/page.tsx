import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, Bookmark, Clock, LayoutGrid } from "lucide-react";
import { ActivityPlayer } from "@/components/activities/activity-player";
import { ACTIVITIES, activityBySlug } from "@/lib/activities";

export function generateStaticParams() {
  return ACTIVITIES.map((activity) => ({ slug: activity.slug }));
}

export default async function ActivityPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const activity = activityBySlug(slug);
  if (!activity) notFound();

  const others = ACTIVITIES.filter((item) => item.slug !== activity.slug);

  return (
    <div className="space-y-4">
      <section className="glass relative overflow-hidden rounded-[26px] p-5 sm:p-6">
        <div
          className="pointer-events-none absolute -right-16 -top-24 h-56 w-56 rounded-full opacity-25 blur-[80px]"
          style={{ background: activity.accent }}
        />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3.5">
            <span
              className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border text-3xl"
              style={{ borderColor: `${activity.accent}55`, background: `${activity.accent}1f` }}
            >
              {activity.emoji}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black tracking-tight text-pumpkin-50">{activity.name}</h2>
                <span
                  className="rounded-full px-2 py-0.5 text-[0.58rem] font-bold uppercase tracking-wider"
                  style={{ background: `${activity.accent}22`, color: activity.accent }}
                >
                  {activity.category}
                </span>
              </div>
              <p className="mt-1 max-w-xl text-sm leading-relaxed text-pumpkin-50/50">
                {activity.description}
              </p>
            </div>
          </div>
          <Link
            href="/activities"
            className="btn-ghost flex shrink-0 items-center gap-1.5 self-start rounded-lg px-2.5 py-1.5 text-[0.7rem] font-semibold text-pumpkin-50/70"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> All activities
          </Link>
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_260px]">
        <ActivityPlayer slug={activity.slug} />

        <aside className="space-y-3">
          <div className="glass rounded-2xl p-4">
            <p className="section-label flex items-center gap-1.5">
              <LayoutGrid className="h-3 w-3" /> controls
            </p>
            <p className="mt-2 text-[0.74rem] leading-relaxed text-pumpkin-50/60">{activity.controls}</p>
            <div className="mt-3 flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/30 px-2.5 py-2 text-[0.66rem] text-pumpkin-50/40">
              <Clock className="h-3 w-3" />
              High scores saved locally
            </div>
            <div className="mt-2 flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/30 px-2.5 py-2 text-[0.66rem] text-pumpkin-50/40">
              <Bookmark className="h-3 w-3" />
              Bookmark this page in your browser
            </div>
          </div>

          <div className="glass rounded-2xl p-4">
            <p className="section-label">more activities</p>
            <ul className="mt-2 space-y-1">
              {others.map((item) => (
                <li key={item.slug}>
                  <Link
                    href={`/activities/${item.slug}`}
                    className="group flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-[0.74rem] text-pumpkin-50/65 transition hover:bg-white/5 hover:text-pumpkin-50"
                  >
                    <span className="flex items-center gap-2 truncate">
                      <span aria-hidden="true">{item.emoji}</span>
                      <span className="truncate">{item.name}</span>
                    </span>
                    <ArrowRight className="h-3 w-3 shrink-0 text-pumpkin-50/25 transition group-hover:text-[var(--accent)]" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
