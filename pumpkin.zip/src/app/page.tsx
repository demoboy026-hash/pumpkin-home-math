import Link from "next/link";
import { ArrowRight, ShieldAlert, Waypoints } from "lucide-react";
import { BrowserWorkbench } from "@/components/browser-workbench";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-2 px-1">
        <div>
          <p className="section-label">home · browser</p>
          <h2 className="mt-1 text-lg font-bold tracking-tight text-pumpkin-50 sm:text-xl">
            Your unblocked browser
          </h2>
        </div>
        <p className="text-[0.7rem] text-pumpkin-50/40">
          Tabs, favorites and a shield tunnel — all in one window.
        </p>
      </div>

      <BrowserWorkbench />

      <div className="grid gap-3 sm:grid-cols-2">
        <Link
          href="/mirrors"
          className="glass panel-hover group flex items-center justify-between rounded-2xl px-4 py-3.5"
        >
          <span className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-black/30 text-[var(--accent)]">
              <Waypoints className="h-4 w-4" />
            </span>
            <span>
              <span className="block text-sm font-semibold text-pumpkin-50">Make a mirror link</span>
              <span className="block text-[0.68rem] text-pumpkin-50/40">
                An identical site on a different URL
              </span>
            </span>
          </span>
          <ArrowRight className="h-4 w-4 text-pumpkin-50/30 transition group-hover:translate-x-0.5 group-hover:text-[var(--accent)]" />
        </Link>
        <Link
          href="/settings"
          className="glass panel-hover group flex items-center justify-between rounded-2xl px-4 py-3.5"
        >
          <span className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-black/30 text-[var(--accent)]">
              <ShieldAlert className="h-4 w-4" />
            </span>
            <span>
              <span className="block text-sm font-semibold text-pumpkin-50">Set your panic key</span>
              <span className="block text-[0.68rem] text-pumpkin-50/40">
                One keystroke and you are back on a school portal
              </span>
            </span>
          </span>
          <ArrowRight className="h-4 w-4 text-pumpkin-50/30 transition group-hover:translate-x-0.5 group-hover:text-[var(--accent)]" />
        </Link>
      </div>
    </div>
  );
}
