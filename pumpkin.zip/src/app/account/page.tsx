import { AccountPanel } from "@/components/account-panel";

export const metadata = {
  title: "account — pumpkin",
};

export default function AccountPage() {
  return (
    <div className="space-y-4">
      <section className="glass rounded-[26px] px-5 py-5">
        <p className="section-label">account · saved pumpkin</p>
        <h2 className="mt-1 text-2xl font-black tracking-tight text-pumpkin-50 sm:text-3xl">
          Keep your pumpkin
        </h2>
        <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-pumpkin-50/50">
          Without an account, pumpkin remembers this browser only. Create one and your favorites,
          panic key, disguise, theme and chat name are saved on the server — the same setup loads
          every time you come back.
        </p>
      </section>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,340px)_minmax(0,1fr)]">
        <AccountPanel />
        <aside className="space-y-3">
          {[
            {
              title: "Animated profile picture",
              body: "Pick a premade animation or upload a GIF/video — it shows in the header and in chat.",
              emoji: "🎭",
            },
            {
              title: "Saved on every visit",
              body: "Sessions last a year, so returning to pumpkin restores your account without typing anything.",
              emoji: "🔁",
            },
            {
              title: "Favorites follow you",
              body: "Bookmarks made in the unblocked browser are stored against the account, not the tab.",
              emoji: "🔖",
            },
            {
              title: "One identity in chat",
              body: "Your display name is used automatically in the main, gaming and dev rooms.",
              emoji: "💬",
            },
            {
              title: "Same panic key anywhere",
              body: "Clients are configured from your account settings, so the disguise and keybind never get lost.",
              emoji: "🛡️",
            },
          ].map((item) => (
            <div key={item.title} className="glass rounded-2xl p-3.5">
              <p className="flex items-center gap-2 text-[0.82rem] font-semibold text-pumpkin-50">
                <span aria-hidden="true">{item.emoji}</span>
                {item.title}
              </p>
              <p className="mt-1 text-[0.7rem] leading-relaxed text-pumpkin-50/45">{item.body}</p>
            </div>
          ))}
        </aside>
      </div>
    </div>
  );
}
