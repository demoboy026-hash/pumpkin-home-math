import { GroupChats } from "@/components/group-chats";

export const metadata = {
  title: "group chats — pumpkin",
};

export default function GroupsPage() {
  return (
    <div className="space-y-4">
      <section className="glass relative overflow-hidden rounded-[26px] px-5 py-5">
        <div className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full bg-[var(--accent-glow)] opacity-25 blur-[80px]" />
        <div className="relative flex flex-wrap items-end justify-between gap-3">
          <div>
            <span className="accent-chip inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.18em]">
              private group chats
            </span>
            <h2 className="mt-3 text-2xl font-black tracking-tight text-pumpkin-50 sm:text-3xl">
              Your own circles
            </h2>
            <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-pumpkin-50/50">
              Create a group, name it whatever you like, rename it later and add only the people you
              want inside. Groups are invisible to everyone else — names, members and messages.
            </p>
          </div>
          <span className="flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-3 py-1.5 text-[0.66rem] text-emerald-200/80">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            member-only visibility
          </span>
        </div>
      </section>

      <GroupChats />
    </div>
  );
}
