import { MirrorStudio } from "@/components/mirror-studio";

export const metadata = {
  title: "mirrors — pumpkin",
};

export default function MirrorsPage() {
  return (
    <div className="space-y-4">
      <section className="glass rounded-[26px] px-5 py-5">
        <p className="section-label">mirrors · alias engine</p>
        <h2 className="mt-1 text-2xl font-black tracking-tight text-pumpkin-50 sm:text-3xl">
          One site, many addresses
        </h2>
        <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-pumpkin-50/50">
          Spin up an identical copy of pumpkin on a brand new link. Handy when the usual address gets
          filtered, or when you just want a quieter URL for a study session.
        </p>
      </section>
      <MirrorStudio />
    </div>
  );
}
