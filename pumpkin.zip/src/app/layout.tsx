import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppShell } from "@/components/app-shell";
import { SettingsProvider } from "@/components/providers";
import { readProfileForRender } from "@/lib/profile";
import { parseSettingsRow } from "@/lib/settings";
import type { Settings } from "@/lib/types";

export const metadata: Metadata = {
  title: "pumpkin — your private browser",
  description:
    "pumpkin is a private, unblocked browser with study-break activities, mirrors, a panic key and community chat rooms.",
};

export const viewport: Viewport = {
  themeColor: "#0a0705",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  let initialSettings: Partial<Settings> | null = null;
  let accent = "ember";

  try {
    const profile = await readProfileForRender();
    if (profile) {
      initialSettings = parseSettingsRow(profile);
      accent = profile.accent;
    }
  } catch {
    // A cold database should still render the pumpkin defaults.
  }

  return (
    <html lang="en" data-accent={accent} suppressHydrationWarning>
      <body className="font-sans antialiased">
        <SettingsProvider initialSettings={initialSettings}>
          <AppShell>{children}</AppShell>
        </SettingsProvider>
      </body>
    </html>
  );
}
