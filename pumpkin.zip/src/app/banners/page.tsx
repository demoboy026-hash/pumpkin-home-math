import { BannerStudio } from "@/components/banner-studio";

export const metadata = {
  title: "banners — pumpkin",
};

export default function BannersPage() {
  return (
    <div className="space-y-4">
      <BannerStudio />
    </div>
  );
}
