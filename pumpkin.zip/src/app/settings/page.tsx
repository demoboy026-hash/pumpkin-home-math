import { SettingsPanel } from "@/components/settings-panel";

export const metadata = {
  title: "settings — pumpkin",
};

export default function SettingsPage() {
  return (
    <div className="space-y-4">
      <SettingsPanel />
    </div>
  );
}
