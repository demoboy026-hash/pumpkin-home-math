import { StreamxRedirect } from "@/components/streamx-redirect";

export const metadata = {
  title: "StreamX redirect — pumpkin",
};

export default function StreamxPage() {
  return (
    <div className="space-y-4">
      <StreamxRedirect />
      <div className="glass rounded-2xl p-4 text-[0.72rem] leading-relaxed text-pumpkin-50/45">
        <p className="section-label mb-1.5">why a redirect</p>
        <p>
          StreamX lives on its own domain. pumpkin sends the session into the embedded browser at{" "}
          <code className="rounded bg-black/40 px-1 py-0.5 text-pumpkin-50/65">/browse</code> so the
          address bar, shield toggle, favorites and panic key are still one tap away. If the provider
          forbids framing, use <strong className="text-pumpkin-50/70">Open directly</strong> in the
          browser toolbar — that always works.
        </p>
      </div>
    </div>
  );
}
