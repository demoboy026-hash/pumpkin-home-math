import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { BrowserWorkbench } from "@/components/browser-workbench";
import { isSafeHttpUrl, prettyHost } from "@/lib/settings";

export const dynamic = "force-dynamic";

type BrowseSearchParams = { url?: string | string[] };

export default async function BrowsePage({
  searchParams,
}: {
  searchParams: Promise<BrowseSearchParams>;
}) {
  const params = await searchParams;
  const raw = Array.isArray(params.url) ? params.url[0] : params.url;
  const initialUrl = raw && isSafeHttpUrl(raw) ? raw : null;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 px-1">
        <div>
          <p className="section-label">browser · session</p>
          <h2 className="mt-1 truncate text-lg font-bold tracking-tight text-pumpkin-50 sm:text-xl">
            {initialUrl ? prettyHost(initialUrl) : "New browser session"}
          </h2>
        </div>
        <Link
          href="/"
          className="btn-ghost flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[0.7rem] font-semibold text-pumpkin-50/70"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Start page
        </Link>
      </div>

      <BrowserWorkbench initialUrl={initialUrl} />

      {raw && !initialUrl ? (
        <p className="rounded-xl border border-amber-300/20 bg-amber-300/10 px-3 py-2 text-[0.7rem] text-amber-100/80">
          That address was not a valid link, so the browser opened on its start page instead.
        </p>
      ) : null}
    </div>
  );
}
