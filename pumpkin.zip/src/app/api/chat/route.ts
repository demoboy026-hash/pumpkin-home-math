import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMessages, users } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import { parseAvatar, parseEffect } from "@/lib/avatars";
import type { ChatRoomId } from "@/lib/types";

export const dynamic = "force-dynamic";

const ROOMS: ChatRoomId[] = ["main", "gaming", "dev"];

const SEED: Record<ChatRoomId, { author: string; body: string }[]> = {
  main: [
    {
      author: "pumpkin",
      body: "Welcome to the lobby 🎃 Drop a link, say what you're working on, keep it friendly.",
    },
    {
      author: "mantis",
      body: "Bookmarks are saved per browser profile now, so my school links stay separate from fun links.",
    },
  ],
  gaming: [
    {
      author: "pumpkin",
      body: "This room is open. Post your best runs — Target Rush is embarrassingly addictive.",
    },
    {
      author: "juno",
      body: "Neon Snake at 34. Beat it and I'll believe you.",
    },
  ],
  dev: [
    {
      author: "pumpkin",
      body: "Dev room: mirror requests, browser bugs, ideas for what to add next.",
    },
    {
      author: "kai",
      body: "If a site refuses to embed, flip the shield switch in the address bar and retry.",
    },
  ],
};

function isRoom(value: string | null): value is ChatRoomId {
  return value !== null && ROOMS.includes(value as ChatRoomId);
}

async function seedRoom(room: ChatRoomId) {
  const existing = await db.select({ id: chatMessages.id }).from(chatMessages).where(eq(chatMessages.room, room)).limit(1);
  if (existing.length > 0) return;
  const base = Date.now() - 1000 * 60 * 60 * 6;
  await db.insert(chatMessages).values(
    SEED[room].map((message, index) => ({
      room,
      author: message.author,
      body: message.body,
      createdAt: new Date(base + index * 1000 * 60 * 4),
    })),
  );
}

export async function GET(request: Request) {
  try {
    const roomParam = new URL(request.url).searchParams.get("room");
    const room: ChatRoomId = isRoom(roomParam) ? roomParam : "main";
    await seedRoom(room);

    const rows = await db
      .select({ message: chatMessages, avatar: users.avatar, effect: users.avatarEffect })
      .from(chatMessages)
      .leftJoin(users, eq(chatMessages.userId, users.id))
      .where(eq(chatMessages.room, room))
      .orderBy(desc(chatMessages.id))
      .limit(80);

    return Response.json({
      room,
      messages: rows
        .reverse()
        .map(({ message, avatar, effect }) => ({
          id: message.id,
          room: message.room,
          author: message.author,
          body: message.body,
          createdAt: message.createdAt.toISOString(),
          avatar: avatar ? parseAvatar(avatar) : null,
          authorEffect: effect ? parseEffect(effect) : null,
        })),
    });
  } catch {
    return Response.json({ error: "Chat is warming up", messages: [] }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const body = (await request.json()) as { room?: unknown; author?: unknown; body?: unknown };
    const room = typeof body.room === "string" && isRoom(body.room) ? body.room : null;
    const author = typeof body.author === "string" ? body.author.trim().slice(0, 24) : "";
    const text = typeof body.body === "string" ? body.body.trim().slice(0, 600) : "";

    if (!room) return Response.json({ error: "Unknown room" }, { status: 400 });
    if (!text) return Response.json({ error: "Message can't be empty" }, { status: 400 });

    const session = await getSessionUser();
    const finalAuthor = session ? session.user.displayName.slice(0, 24) : author || "anonymous";

    const [created] = await db
      .insert(chatMessages)
      .values({
        room,
        author: finalAuthor,
        body: text,
        userId: session?.user.id ?? null,
      })
      .returning();

    return Response.json({
      message: {
        id: created.id,
        room: created.room,
        author: created.author,
        body: created.body,
        createdAt: created.createdAt.toISOString(),
      },
    });
  } catch {
    return Response.json({ error: "Could not send message" }, { status: 500 });
  }
}
