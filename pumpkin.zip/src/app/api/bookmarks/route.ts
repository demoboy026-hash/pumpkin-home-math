import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookmarks } from "@/db/schema";
import { attachProfileCookie, ensureProfile } from "@/lib/profile";
import { cookiePolicy, isTrustedOrigin } from "@/lib/auth";
import { isSafeHttpUrl, prettyHost } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { profile, created } = await ensureProfile();
    const rows = await db
      .select()
      .from(bookmarks)
      .where(eq(bookmarks.profileId, profile.id))
      .orderBy(asc(bookmarks.createdAt))
      .limit(80);

    const response = Response.json({
      bookmarks: rows.map((row) => ({
        id: row.id,
        label: row.label,
        url: row.url,
        createdAt: row.createdAt.toISOString(),
      })),
    });
    return created ? attachProfileCookie(response, profile.id, cookiePolicy(request)) : response;
  } catch {
    return Response.json({ error: "Could not load bookmarks", bookmarks: [] }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const { profile, created } = await ensureProfile();
    const body = (await request.json()) as { url?: unknown; label?: unknown };
    const url = typeof body.url === "string" ? body.url.trim().slice(0, 1000) : "";
    if (!isSafeHttpUrl(url)) {
      return Response.json({ error: "Only http(s) links can be bookmarked" }, { status: 400 });
    }

    const existing = await db
      .select({ id: bookmarks.id })
      .from(bookmarks)
      .where(and(eq(bookmarks.profileId, profile.id), eq(bookmarks.url, url)))
      .limit(1);

    if (existing.length > 0) {
      return Response.json({ error: "Already in your favorites" }, { status: 409 });
    }

    const rawLabel = typeof body.label === "string" ? body.label.trim() : "";
    const [createdRow] = await db
      .insert(bookmarks)
      .values({
        profileId: profile.id,
        label: (rawLabel || prettyHost(url)).slice(0, 60),
        url,
      })
      .returning();

    const response = Response.json({
      bookmark: {
        id: createdRow.id,
        label: createdRow.label,
        url: createdRow.url,
        createdAt: createdRow.createdAt.toISOString(),
      },
    });
    return created ? attachProfileCookie(response, profile.id, cookiePolicy(request)) : response;
  } catch {
    return Response.json({ error: "Could not save bookmark" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const { profile } = await ensureProfile();
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!Number.isInteger(id) || id <= 0) {
      return Response.json({ error: "Invalid bookmark" }, { status: 400 });
    }

    await db.delete(bookmarks).where(and(eq(bookmarks.id, id), eq(bookmarks.profileId, profile.id)));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Could not remove bookmark" }, { status: 500 });
  }
}
