export const dynamic = "force-dynamic";

const BLOCKED_HOST =
  /^(localhost|127\.|0\.0\.0\.0|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[?::1\]?|0x7f)/i;

const MAX_HTML_BYTES = 3_000_000;

function errorPage(message: string, url: string) {
  const safeUrl = url.replace(/"/g, "&quot;");
  return new Response(
    `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Shield could not load this page</title>
<style>
  :root{color-scheme:dark}
  body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b0705;color:#f7ede4;
  font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;padding:32px}
  .card{max-width:520px;border:1px solid rgba(255,122,24,.28);background:rgba(255,255,255,.04);
  border-radius:20px;padding:28px;box-shadow:0 30px 60px -40px #000}
  h1{margin:0 0 8px;font-size:22px}
  p{color:rgba(247,237,228,.65);line-height:1.6;font-size:14px;margin:0 0 16px}
  a{display:inline-block;background:linear-gradient(180deg,#ff963f,#ff7a18);color:#1b0c02;
  text-decoration:none;font-weight:600;padding:10px 16px;border-radius:12px;font-size:14px}
  code{font-size:11px;color:rgba(247,237,228,.4);word-break:break-all}
</style></head><body><div class="card">
<h1>This page asked the shield not to load</h1>
<p>${message}</p>
<p><code>${safeUrl}</code></p>
<a href="${safeUrl}" target="_blank" rel="noreferrer noopener">Open it directly instead</a>
</div></body></html>`,
    { status: 200, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } },
  );
}

export async function GET(request: Request) {
  const raw = new URL(request.url).searchParams.get("url");
  if (!raw) return errorPage("No address was provided for the shield to fetch.", "#");

  let target: URL;
  try {
    target = new URL(raw);
  } catch {
    return errorPage("That address is not a valid URL.", raw);
  }

  if (target.protocol !== "http:" && target.protocol !== "https:") {
    return errorPage("Only http and https addresses can run through the shield.", raw);
  }
  if (BLOCKED_HOST.test(target.hostname) || target.hostname.endsWith(".local")) {
    return errorPage("Local network addresses are blocked inside the shield.", raw);
  }

  try {
    const upstream = await fetch(target, {
      redirect: "follow",
      signal: AbortSignal.timeout(13_000),
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
      cache: "no-store",
    });

    const contentType = upstream.headers.get("content-type") ?? "text/html";
    if (!contentType.includes("text/html") && !contentType.includes("application/xhtml")) {
      return new Response(upstream.body, {
        status: upstream.status,
        headers: {
          "Content-Type": contentType,
          "Cache-Control": "no-store",
        },
      });
    }

    const buffer = await upstream.arrayBuffer();
    if (buffer.byteLength > MAX_HTML_BYTES) {
      return errorPage("That page is too large for the shield. Open it directly instead.", target.toString());
    }

    let html = new TextDecoder("utf-8").decode(buffer);
    const base = `<base href="${upstream.url.replace(/"/g, "&quot;")}">`;

    html = html
      .replace(/<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi, "")
      .replace(/<meta[^>]+http-equiv=["']?x-frame-options["']?[^>]*>/gi, "");

    if (/<head[^>]*>/i.test(html)) {
      html = html.replace(/<head[^>]*>/i, (match) => `${match}${base}`);
    } else {
      html = `${base}${html}`;
    }

    return new Response(html, {
      status: upstream.status,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
        "Referrer-Policy": "no-referrer",
      },
    });
  } catch {
    return errorPage(
      "The shield timed out or the site refused the request. Some sites force their own frame rules — opening directly usually works.",
      target.toString(),
    );
  }
}
