import { and, count, desc, eq, ne, or } from "drizzle-orm";
import { db } from "@/db";
import { directMessages, friendships, users } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import { parseAvatar, parseEffect } from "@/lib/avatars";

export const dynamic = "force-dynamic";

type PublicUser = {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  effect: string | null;
};

function toPublic(row: {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  avatarEffect: string;
}): PublicUser {
  return {
    id: row.id,
    username: row.username,
    displayName: row.displayName,
    avatar: JSON.stringify(parseAvatar(row.avatar)),
    effect: parseEffect(row.avatarEffect),
  };
}

export async function GET() {
  const session = await getSessionUser();
  if (!session) {
    return Response.json({ error: "Sign in to use friends." }, { status: 401 });
  }
  const me = session.user.id;

  try {
    const rows = await db
      .select({
        id: friendships.id,
        requesterId: friendships.requesterId,
        addresseeId: friendships.addresseeId,
        status: friendships.status,
        createdAt: friendships.createdAt,
      })
      .from(friendships)
      .where(or(eq(friendships.requesterId, me), eq(friendships.addresseeId, me)))
      .orderBy(desc(friendships.id));

    const otherIds = rows.map((row) => (row.requesterId === me ? row.addresseeId : row.requesterId));
    const people = otherIds.length
      ? await db
          .select({
            id: users.id,
            username: users.username,
            displayName: users.displayName,
            avatar: users.avatar,
            avatarEffect: users.avatarEffect,
          })
          .from(users)
          .where(or(...otherIds.map((id) => eq(users.id, id))))
      : [];
    const byId = new Map(people.map((person) => [person.id, toPublic(person)]));

    const messages = await db
      .select({
        senderId: directMessages.senderId,
        recipientId: directMessages.recipientId,
        body: directMessages.body,
        readAt: directMessages.readAt,
        createdAt: directMessages.createdAt,
      })
      .from(directMessages)
      .where(or(eq(directMessages.senderId, me), eq(directMessages.recipientId, me)))
      .orderBy(desc(directMessages.id))
      .limit(400);

    const lastMessage = new Map<string, { body: string; at: string; mine: boolean }>();
    const unread = new Map<string, number>();
    messages.forEach((message) => {
      const other = message.senderId === me ? message.recipientId : message.senderId;
      if (!lastMessage.has(other)) {
        lastMessage.set(other, {
          body: message.body,
          at: message.createdAt.toISOString(),
          mine: message.senderId === me,
        });
      }
      if (message.recipientId === me && !message.readAt) {
        unread.set(message.senderId, (unread.get(message.senderId) ?? 0) + 1);
      }
    });

    const friends = rows
      .filter((row) => row.status === "accepted")
      .map((row) => {
        const other = row.requesterId === me ? row.addresseeId : row.requesterId;
        const person = byId.get(other);
        if (!person) return null;
        return {
          ...person,
          since: row.createdAt.toISOString(),
          lastMessage: lastMessage.get(other) ?? null,
          unread: unread.get(other) ?? 0,
        };
      })
      .filter((entry): entry is NonNullable<typeof entry> => entry !== null)
      .sort((a, b) => {
        const aTime = a.lastMessage?.at ?? a.since;
        const bTime = b.lastMessage?.at ?? b.since;
        return bTime.localeCompare(aTime);
      });

    const incoming = rows
      .filter((row) => row.status === "pending" && row.addresseeId === me)
      .map((row) => {
        const person = byId.get(row.requesterId);
        if (!person) return null;
        return { ...person, requestId: row.id, requestedAt: row.createdAt.toISOString() };
      })
      .filter((entry): entry is NonNullable<typeof entry> => entry !== null);

    const outgoing = rows
      .filter((row) => row.status === "pending" && row.requesterId === me)
      .map((row) => {
        const person = byId.get(row.addresseeId);
        if (!person) return null;
        return { ...person, requestId: row.id, requestedAt: row.createdAt.toISOString() };
      })
      .filter((entry): entry is NonNullable<typeof entry> => entry !== null);

    const existingIds = new Set([me, ...otherIds]);
    const candidates = await db
      .select({
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        avatar: users.avatar,
        avatarEffect: users.avatarEffect,
      })
      .from(users)
      .where(ne(users.id, me))
      .limit(40);

    const suggestions = candidates
      .filter((candidate) => !existingIds.has(candidate.id))
      .slice(0, 12)
      .map(toPublic);

    const [pendingCount] = await db
      .select({ value: count() })
      .from(friendships)
      .where(and(eq(friendships.addresseeId, me), eq(friendships.status, "pending")));

    return Response.json(
      {
        friends,
        incoming,
        outgoing,
        suggestions,
        pendingRequests: Number(pendingCount?.value ?? 0),
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json({ error: "Could not load friends." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  const session = await getSessionUser();
  if (!session) {
    return Response.json({ error: "Sign in to use friends." }, { status: 401 });
  }
  const me = session.user.id;

  try {
    const body = (await request.json()) as {
      action?: string;
      userId?: string;
      username?: string;
    };
    const action = body.action ?? "";

    let targetId = typeof body.userId === "string" ? body.userId : "";
    if (!targetId && typeof body.username === "string") {
      const [found] = await db
        .select({ id: users.id })
        .from(users)
        .where(eq(users.username, body.username.trim().toLowerCase()))
        .limit(1);
      targetId = found?.id ?? "";
    }

    if (!targetId) return Response.json({ error: "Pick a user first." }, { status: 400 });
    if (targetId === me) return Response.json({ error: "You cannot friend yourself." }, { status: 400 });

    const existingRows = await db
      .select()
      .from(friendships)
      .where(
        or(
          and(eq(friendships.requesterId, me), eq(friendships.addresseeId, targetId)),
          and(eq(friendships.requesterId, targetId), eq(friendships.addresseeId, me)),
        ),
      )
      .limit(1);
    const existing = existingRows[0];

    if (action === "request") {
      if (existing?.status === "accepted") {
        return Response.json({ error: "You are already friends." }, { status: 409 });
      }
      if (existing?.status === "pending") {
        if (existing.addresseeId === me) {
          await db
            .update(friendships)
            .set({ status: "accepted", updatedAt: new Date() })
            .where(eq(friendships.id, existing.id));
          return Response.json({ status: "friends", message: "Friend request accepted." });
        }
        return Response.json({ error: "Request already sent." }, { status: 409 });
      }
      await db.insert(friendships).values({ requesterId: me, addresseeId: targetId, status: "pending" });
      return Response.json({ status: "pending_out", message: "Friend request sent." });
    }

    if (action === "accept") {
      if (!existing || existing.status !== "pending") {
        return Response.json({ error: "No pending request from that user." }, { status: 404 });
      }
      if (existing.addresseeId !== me && existing.requesterId !== me) {
        return Response.json({ error: "Not your request." }, { status: 403 });
      }
      await db
        .update(friendships)
        .set({ status: "accepted", updatedAt: new Date() })
        .where(eq(friendships.id, existing.id));
      return Response.json({ status: "friends", message: "You are now friends." });
    }

    if (action === "decline" || action === "cancel" || action === "remove") {
      if (!existing) return Response.json({ status: "none", message: "Nothing to remove." });
      if (existing.addresseeId !== me && existing.requesterId !== me) {
        return Response.json({ error: "Not your friendship." }, { status: 403 });
      }
      await db.delete(friendships).where(eq(friendships.id, existing.id));
      return Response.json({
        status: "none",
        message: action === "remove" ? "Friend removed." : "Request cleared.",
      });
    }

    return Response.json({ error: "Unknown action." }, { status: 400 });
  } catch {
    return Response.json({ error: "Could not update that friendship." }, { status: 500 });
  }
}
