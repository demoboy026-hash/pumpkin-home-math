import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { attachProfileCookie, ensureProfile } from "@/lib/profile";
import { cookiePolicy, isTrustedOrigin } from "@/lib/auth";
import { ACCENTS, isSafeHttpUrl, parseBanner, parseSettingsRow } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { profile, created } = await ensureProfile();
    const response = Response.json({ settings: parseSettingsRow(profile), profileId: profile.id });
    return created ? attachProfileCookie(response, profile.id, cookiePolicy(request)) : response;
  } catch {
    return Response.json({ error: "Could not load settings" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const { profile, created } = await ensureProfile();
    const body = (await request.json()) as Record<string, unknown>;

    const panicKey = typeof body.panicKey === "string" ? body.panicKey.slice(0, 40) : profile.panicKey;
    const panicUrl = typeof body.panicUrl === "string" ? body.panicUrl.slice(0, 500) : profile.panicUrl;
    if (panicUrl && !isSafeHttpUrl(panicUrl)) {
      return Response.json({ error: "Panic redirect must be a valid http(s) link" }, { status: 400 });
    }

    const accent =
      typeof body.accent === "string" && ACCENTS.some((item) => item.id === body.accent)
        ? body.accent
        : profile.accent;

    const [updated] = await db
      .update(profiles)
      .set({
        panicKey: panicKey || profile.panicKey,
        panicUrl,
        panicEnabled: typeof body.panicEnabled === "boolean" ? body.panicEnabled : profile.panicEnabled,
        disguiseEnabled:
          typeof body.disguiseEnabled === "boolean" ? body.disguiseEnabled : profile.disguiseEnabled,
        disguiseTitle:
          typeof body.disguiseTitle === "string"
            ? body.disguiseTitle.slice(0, 120)
            : profile.disguiseTitle,
        accent,
        homepage: typeof body.homepage === "string" ? body.homepage.slice(0, 500) : profile.homepage,
        proxyDefault:
          typeof body.proxyDefault === "boolean" ? body.proxyDefault : profile.proxyDefault,
        banner:
          body.banner && typeof body.banner === "object"
            ? JSON.stringify(parseBanner(JSON.stringify(body.banner)))
            : profile.banner,
        updatedAt: new Date(),
      })
      .where(eq(profiles.id, profile.id))
      .returning();

    const response = Response.json({ settings: parseSettingsRow(updated) });
    return created ? attachProfileCookie(response, profile.id, cookiePolicy(request)) : response;
  } catch {
    return Response.json({ error: "Could not save settings" }, { status: 500 });
  }
}
