import { desc, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import { MEDIA_LIMITS, mediaKindFor } from "@/lib/banners";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const MAX_FILES = 12;

export async function GET() {
  try {
    const session = await getSessionUser();
    const uploads = await db
      .select({
        id: media.id,
        mime: media.mime,
        kind: media.kind,
        name: media.name,
        bytes: media.bytes,
        ownerId: media.ownerId,
        createdAt: media.createdAt,
      })
      .from(media)
      .where(session ? eq(media.ownerId, session.user.id) : isNull(media.ownerId))
      .orderBy(desc(media.id))
      .limit(40);

    return Response.json({
      uploads: uploads.map((row) => ({
        id: row.id,
        mime: row.mime,
        kind: row.kind,
        name: row.name,
        bytes: row.bytes,
        createdAt: row.createdAt.toISOString(),
      })),
    });
  } catch {
    return Response.json({ uploads: [] }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();

  try {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return Response.json({ error: "No file was uploaded." }, { status: 400 });
    }

    const kind = mediaKindFor(file.type);
    if (!kind) {
      return Response.json(
        { error: "Use a video (MP4, WebM, MOV) or an image/GIF (GIF, PNG, JPG, WebP)." },
        { status: 415 },
      );
    }

    const limit = kind === "video" ? MEDIA_LIMITS.video : MEDIA_LIMITS.image;
    if (file.size > limit) {
      return Response.json(
        { error: `That file is too large. Keep ${kind === "video" ? "videos" : "images"} under ${Math.round(limit / (1024 * 1024))}MB.` },
        { status: 413 },
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const [created] = await db
      .insert(media)
      .values({
        ownerId: session?.user.id ?? null,
        mime: file.type,
        kind,
        name: (file.name || "banner").slice(0, 120),
        bytes: buffer.byteLength,
        data: buffer.toString("base64"),
      })
      .returning({ id: media.id, kind: media.kind, name: media.name, bytes: media.bytes, mime: media.mime });

    // Keep the library from growing without bound for signed-in users.
    if (session) {
      const owned = await db
        .select({ id: media.id })
        .from(media)
        .where(eq(media.ownerId, session.user.id))
        .orderBy(desc(media.id));
      const stale = owned.slice(MAX_FILES);
      for (const row of stale) {
        await db.delete(media).where(eq(media.id, row.id));
      }
    }

    return Response.json({
      media: {
        id: created.id,
        kind: created.kind,
        name: created.name,
        bytes: created.bytes,
        mime: created.mime,
        url: `/api/media/${created.id}`,
      },
    });
  } catch {
    return Response.json({ error: "The upload failed. Try a smaller file." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const session = await getSessionUser();
    const id = new URL(request.url).searchParams.get("id");
    if (!id) return Response.json({ error: "Missing id" }, { status: 400 });

    const [row] = await db.select({ ownerId: media.ownerId }).from(media).where(eq(media.id, id)).limit(1);
    if (!row) return Response.json({ error: "Not found" }, { status: 404 });
    if (row.ownerId && row.ownerId !== session?.user.id) {
      return Response.json({ error: "You can only remove your own uploads." }, { status: 403 });
    }

    await db.delete(media).where(eq(media.id, id));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Could not remove that file." }, { status: 500 });
  }
}
