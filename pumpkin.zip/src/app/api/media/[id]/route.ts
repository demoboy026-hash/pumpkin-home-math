import { eq } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID_RE.test(id)) return new Response("Not found", { status: 404 });

  try {
    const [row] = await db
      .select({ mime: media.mime, data: media.data, kind: media.kind })
      .from(media)
      .where(eq(media.id, id))
      .limit(1);

    if (!row) return new Response("Not found", { status: 404 });

    const buffer = Buffer.from(row.data, "base64");
    return new Response(new Uint8Array(buffer), {
      headers: {
        "Content-Type": row.mime || (row.kind === "video" ? "video/mp4" : "image/gif"),
        "Content-Length": String(buffer.byteLength),
        "Cache-Control": "public, max-age=31536000, immutable",
        "Accept-Ranges": "none",
        "Content-Disposition": "inline",
      },
    });
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
