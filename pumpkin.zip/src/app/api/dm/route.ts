import { and, asc, eq, isNull, or } from "drizzle-orm";
import { db } from "@/db";
import { directMessages, users } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import { parseAvatar, parseEffect } from "@/lib/avatars";
import { areFriends } from "@/lib/friends";

export const dynamic = "force-dynamic";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function GET(request: Request) {
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in to read messages." }, { status: 401 });
  const me = session.user.id;

  const withId = new URL(request.url).searchParams.get("with") ?? "";
  if (!UUID_RE.test(withId)) {
    return Response.json({ error: "Unknown conversation." }, { status: 400 });
  }

  try {
    if (!(await areFriends(me, withId))) {
      return Response.json({ error: "You can only message friends." }, { status: 403 });
    }

    const [partner] = await db
      .select({
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        avatar: users.avatar,
        avatarEffect: users.avatarEffect,
      })
      .from(users)
      .where(eq(users.id, withId))
      .limit(1);

    const rows = await db
      .select()
      .from(directMessages)
      .where(
        or(
          and(eq(directMessages.senderId, me), eq(directMessages.recipientId, withId)),
          and(eq(directMessages.senderId, withId), eq(directMessages.recipientId, me)),
        ),
      )
      .orderBy(asc(directMessages.id))
      .limit(200);

    await db
      .update(directMessages)
      .set({ readAt: new Date() })
      .where(
        and(
          eq(directMessages.senderId, withId),
          eq(directMessages.recipientId, me),
          isNull(directMessages.readAt),
        ),
      );

    return Response.json(
      {
        partner: partner
          ? {
              id: partner.id,
              username: partner.username,
              displayName: partner.displayName,
              avatar: JSON.stringify(parseAvatar(partner.avatar)),
              effect: parseEffect(partner.avatarEffect),
            }
          : null,
        messages: rows.map((row) => ({
          id: row.id,
          mine: row.senderId === me,
          body: row.body,
          read: Boolean(row.readAt),
          createdAt: row.createdAt.toISOString(),
        })),
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json({ error: "Could not load this conversation." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in to send messages." }, { status: 401 });
  const me = session.user.id;

  try {
    const body = (await request.json()) as { to?: unknown; body?: unknown };
    const to = typeof body.to === "string" ? body.to : "";
    const text = typeof body.body === "string" ? body.body.trim().slice(0, 800) : "";

    if (!UUID_RE.test(to)) return Response.json({ error: "Unknown recipient." }, { status: 400 });
    if (!text) return Response.json({ error: "Write something first." }, { status: 400 });
    if (!(await areFriends(me, to))) {
      return Response.json({ error: "You can only message friends." }, { status: 403 });
    }

    const [created] = await db
      .insert(directMessages)
      .values({ senderId: me, recipientId: to, body: text })
      .returning();

    return Response.json({
      message: {
        id: created.id,
        mine: true,
        body: created.body,
        read: false,
        createdAt: created.createdAt.toISOString(),
      },
    });
  } catch {
    return Response.json({ error: "Message did not send." }, { status: 500 });
  }
}
