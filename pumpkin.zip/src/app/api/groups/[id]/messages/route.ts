import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { groupMessages, groups, users } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import { parseAvatar, parseEffect } from "@/lib/avatars";
import { loadGroupForMember } from "@/lib/groups";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function GET(_request: Request, { params }: Params) {
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in first." }, { status: 401 });

  const { id } = await params;
  const groupId = Number(id);
  const access = await loadGroupForMember(groupId, session.user.id);
  if (!access) return Response.json({ error: "Group not found." }, { status: 404 });

  try {
    const rows = await db
      .select({
        id: groupMessages.id,
        body: groupMessages.body,
        createdAt: groupMessages.createdAt,
        senderId: groupMessages.senderId,
        username: users.username,
        displayName: users.displayName,
        avatar: users.avatar,
        avatarEffect: users.avatarEffect,
      })
      .from(groupMessages)
      .innerJoin(users, eq(groupMessages.senderId, users.id))
      .where(eq(groupMessages.groupId, groupId))
      .orderBy(asc(groupMessages.id))
      .limit(300);

    return Response.json(
      {
        group: { id: access.group.id, name: access.group.name },
        messages: rows.map((row) => ({
          id: row.id,
          mine: row.senderId === session.user.id,
          body: row.body,
          author: row.displayName,
          username: row.username,
          avatar: JSON.stringify(parseAvatar(row.avatar)),
          effect: parseEffect(row.avatarEffect),
          createdAt: row.createdAt.toISOString(),
        })),
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json({ error: "Could not load this group." }, { status: 500 });
  }
}

export async function POST(request: Request, { params }: Params) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in first." }, { status: 401 });

  const { id } = await params;
  const groupId = Number(id);
  const access = await loadGroupForMember(groupId, session.user.id);
  if (!access) return Response.json({ error: "Group not found." }, { status: 404 });

  try {
    const body = (await request.json()) as { body?: unknown };
    const text = (typeof body.body === "string" ? body.body.trim() : "").slice(0, 800);
    if (!text) return Response.json({ error: "Write something first." }, { status: 400 });

    const [created] = await db
      .insert(groupMessages)
      .values({ groupId, senderId: session.user.id, body: text })
      .returning();
    await db.update(groups).set({ updatedAt: new Date() }).where(eq(groups.id, groupId));

    return Response.json({
      message: {
        id: created.id,
        mine: true,
        body: created.body,
        author: session.user.displayName,
        username: session.user.username,
        avatar: null,
        effect: "none",
        createdAt: created.createdAt.toISOString(),
      },
    });
  } catch {
    return Response.json({ error: "Message did not send." }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: Params) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in first." }, { status: 401 });

  const { id } = await params;
  const groupId = Number(id);
  const access = await loadGroupForMember(groupId, session.user.id);
  if (!access) return Response.json({ error: "Group not found." }, { status: 404 });

  try {
    await db
      .delete(groupMessages)
      .where(and(eq(groupMessages.groupId, groupId), eq(groupMessages.senderId, session.user.id)));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Could not clear messages." }, { status: 500 });
  }
}
