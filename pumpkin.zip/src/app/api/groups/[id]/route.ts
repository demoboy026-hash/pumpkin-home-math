import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { groupMembers, groups, users } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import { canManage, loadGroupForMember } from "@/lib/groups";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Params) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in first." }, { status: 401 });

  const { id } = await params;
  const groupId = Number(id);
  const access = await loadGroupForMember(groupId, session.user.id);
  if (!access) return Response.json({ error: "Group not found." }, { status: 404 });
  if (!canManage(access.role)) {
    return Response.json({ error: "Only the group owner can rename it." }, { status: 403 });
  }

  try {
    const body = (await request.json()) as { name?: unknown };
    const name = (typeof body.name === "string" ? body.name.trim() : "").slice(0, 60);
    if (!name) return Response.json({ error: "Give the group a name." }, { status: 400 });

    const [updated] = await db
      .update(groups)
      .set({ name, updatedAt: new Date() })
      .where(eq(groups.id, groupId))
      .returning();

    return Response.json({ id: updated.id, name: updated.name });
  } catch {
    return Response.json({ error: "Could not rename that group." }, { status: 500 });
  }
}

export async function POST(request: Request, { params }: Params) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in first." }, { status: 401 });

  const { id } = await params;
  const groupId = Number(id);
  const access = await loadGroupForMember(groupId, session.user.id);
  if (!access) return Response.json({ error: "Group not found." }, { status: 404 });

  try {
    const body = (await request.json()) as { action?: string; userId?: string };
    const action = body.action ?? "add";

    if (action === "add") {
      if (!canManage(access.role)) {
        return Response.json({ error: "Only the owner can add people." }, { status: 403 });
      }
      const userId = typeof body.userId === "string" ? body.userId : "";
      if (!userId) return Response.json({ error: "Pick someone to add." }, { status: 400 });

      const existing = await db
        .select({ id: groupMembers.id })
        .from(groupMembers)
        .where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, userId)))
        .limit(1);
      if (existing.length > 0) {
        return Response.json({ error: "They are already in this group." }, { status: 409 });
      }

      const [person] = await db
        .select({ id: users.id, displayName: users.displayName })
        .from(users)
        .where(eq(users.id, userId))
        .limit(1);
      if (!person) return Response.json({ error: "That person does not exist." }, { status: 404 });

      await db.insert(groupMembers).values({ groupId, userId, role: "member" });
      await db.update(groups).set({ updatedAt: new Date() }).where(eq(groups.id, groupId));
      return Response.json({ ok: true, added: person.displayName });
    }

    if (action === "leave") {
      if (access.role === "owner") {
        return Response.json(
          { error: "The owner cannot leave. Delete the group instead." },
          { status: 400 },
        );
      }
      await db
        .delete(groupMembers)
        .where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, session.user.id)));
      return Response.json({ ok: true, left: true });
    }

    if (action === "remove") {
      if (!canManage(access.role)) {
        return Response.json({ error: "Only the owner can remove people." }, { status: 403 });
      }
      const userId = typeof body.userId === "string" ? body.userId : "";
      if (userId === session.user.id) {
        return Response.json({ error: "Use leave instead." }, { status: 400 });
      }
      await db
        .delete(groupMembers)
        .where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, userId)));
      return Response.json({ ok: true, removed: true });
    }

    return Response.json({ error: "Unknown action." }, { status: 400 });
  } catch {
    return Response.json({ error: "Could not update the group." }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: Params) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in first." }, { status: 401 });

  const { id } = await params;
  const groupId = Number(id);
  const access = await loadGroupForMember(groupId, session.user.id);
  if (!access) return Response.json({ error: "Group not found." }, { status: 404 });
  if (!canManage(access.role)) {
    return Response.json({ error: "Only the owner can delete the group." }, { status: 403 });
  }

  try {
    await db.delete(groups).where(eq(groups.id, groupId));
    return Response.json({ ok: true, deleted: true });
  } catch {
    return Response.json({ error: "Could not delete the group." }, { status: 500 });
  }
}

export async function GET(_request: Request, { params }: Params) {
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in first." }, { status: 401 });

  const { id } = await params;
  const groupId = Number(id);
  const access = await loadGroupForMember(groupId, session.user.id);
  if (!access) return Response.json({ error: "Group not found." }, { status: 404 });

  const memberIds = await db
    .select({ userId: groupMembers.userId, role: groupMembers.role })
    .from(groupMembers)
    .where(eq(groupMembers.groupId, groupId));

  const people = memberIds.length
    ? await db
        .select({
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          avatarEffect: users.avatarEffect,
        })
        .from(users)
        .where(inArray(users.id, memberIds.map((row) => row.userId)))
    : [];

  return Response.json({
    group: { id: access.group.id, name: access.group.name, createdBy: access.group.createdBy },
    role: access.role,
    members: memberIds.map((row) => {
      const person = people.find((entry) => entry.id === row.userId);
      return {
        id: row.userId,
        username: person?.username ?? "unknown",
        displayName: person?.displayName ?? "unknown",
        role: row.role,
      };
    }),
  });
}
