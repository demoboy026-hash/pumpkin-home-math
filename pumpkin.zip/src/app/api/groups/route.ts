import { asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { groupMembers, groupMessages, groups, users } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import { parseAvatar, parseEffect } from "@/lib/avatars";

export const dynamic = "force-dynamic";

const MAX_MEMBERS = 25;

type MemberPayload = {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  effect: string | null;
  role: string;
};

async function membersOf(groupIds: number[]) {
  if (groupIds.length === 0) return new Map<number, MemberPayload[]>();
  const rows = await db
    .select({
      groupId: groupMembers.groupId,
      role: groupMembers.role,
      id: users.id,
      username: users.username,
      displayName: users.displayName,
      avatar: users.avatar,
      avatarEffect: users.avatarEffect,
    })
    .from(groupMembers)
    .innerJoin(users, eq(groupMembers.userId, users.id))
    .where(inArray(groupMembers.groupId, groupIds))
    .orderBy(asc(groupMembers.joinedAt));

  const map = new Map<number, MemberPayload[]>();
  rows.forEach((row) => {
    const list = map.get(row.groupId) ?? [];
    list.push({
      id: row.id,
      username: row.username,
      displayName: row.displayName,
      avatar: JSON.stringify(parseAvatar(row.avatar)),
      effect: parseEffect(row.avatarEffect),
      role: row.role,
    });
    map.set(row.groupId, list);
  });
  return map;
}

export async function GET() {
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in to use group chats." }, { status: 401 });
  const me = session.user.id;

  try {
    // Only groups where the caller is a member are ever returned.
    const mine = await db
      .select({ groupId: groupMembers.groupId, role: groupMembers.role })
      .from(groupMembers)
      .where(eq(groupMembers.userId, me));
    const ids = mine.map((row) => row.groupId);

    if (ids.length === 0) {
      const friends = await db
        .select({ id: users.id, username: users.username, displayName: users.displayName })
        .from(users)
        .where(sql`${users.id} <> ${me}`)
        .limit(40);
      return Response.json({ groups: [], invitable: friends });
    }

    const rows = await db
      .select()
      .from(groups)
      .where(inArray(groups.id, ids))
      .orderBy(desc(groups.updatedAt));

    const memberMap = await membersOf(ids);
    const lastMessages = await db
      .select({
        groupId: groupMessages.groupId,
        body: groupMessages.body,
        senderId: groupMessages.senderId,
        createdAt: groupMessages.createdAt,
        id: groupMessages.id,
      })
      .from(groupMessages)
      .where(inArray(groupMessages.groupId, ids))
      .orderBy(desc(groupMessages.id))
      .limit(300);

    const latest = new Map<number, { body: string; at: string; mine: boolean; sender: string }>();
    lastMessages.forEach((message) => {
      if (!latest.has(message.groupId)) {
        latest.set(message.groupId, {
          body: message.body,
          at: message.createdAt.toISOString(),
          mine: message.senderId === me,
          sender: message.senderId,
        });
      }
    });

    const invitable = await db
      .select({ id: users.id, username: users.username, displayName: users.displayName })
      .from(users)
      .where(sql`${users.id} <> ${me}`)
      .limit(40);

    return Response.json(
      {
        groups: rows.map((group) => ({
          id: group.id,
          name: group.name,
          accent: group.accent,
          createdBy: group.createdBy,
          creatorIsMe: group.createdBy === me,
          role: mine.find((row) => row.groupId === group.id)?.role ?? "member",
          createdAt: group.createdAt.toISOString(),
          members: memberMap.get(group.id) ?? [],
          lastMessage: latest.get(group.id) ?? null,
        })),
        invitable,
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json({ error: "Could not load your group chats." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in to create a group." }, { status: 401 });
  const me = session.user.id;

  try {
    const body = (await request.json()) as { name?: unknown; memberIds?: unknown; accent?: unknown };
    const name = (typeof body.name === "string" ? body.name.trim() : "").slice(0, 60) || "Pumpkin group";
    const requested = Array.isArray(body.memberIds)
      ? body.memberIds.filter((id): id is string => typeof id === "string")
      : [];
    const accent = typeof body.accent === "string" ? body.accent.slice(0, 16) : "ember";

    const valid = new Set<string>();
    if (requested.length > 0) {
      const found = await db
        .select({ id: users.id })
        .from(users)
        .where(inArray(users.id, requested.slice(0, MAX_MEMBERS)));
      found.forEach((row) => valid.add(row.id));
    }
    valid.delete(me);

    const [group] = await db
      .insert(groups)
      .values({ name, accent, createdBy: me })
      .returning();

    await db.insert(groupMembers).values([
      { groupId: group.id, userId: me, role: "owner" },
      ...[...valid].map((userId) => ({ groupId: group.id, userId, role: "member" })),
    ]);

    // A system line so the thread is never completely empty.
    await db.insert(groupMessages).values({
      groupId: group.id,
      senderId: me,
      body: `created the group “${name}”`,
    });

    return Response.json({ id: group.id, name: group.name });
  } catch {
    return Response.json({ error: "Could not create that group." }, { status: 500 });
  }
}
