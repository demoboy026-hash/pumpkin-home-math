import { and, count, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookmarks, chatMessages, mirrors, users } from "@/db/schema";
import { cookies, headers } from "next/headers";
import { getSessionUser, SESSION_COOKIE, SESSION_HEADER, touchSession } from "@/lib/auth";
import { parseAvatar, parseEffect } from "@/lib/avatars";
import { ensureProfile } from "@/lib/profile";

export const dynamic = "force-dynamic";

async function dbHealthy() {
  try {
    await db.execute(sql`select 1`);
    return true;
  } catch {
    return false;
  }
}

export async function GET() {
  // A cold or briefly unavailable database must not look like "signed out".
  let session = await getSessionUser();
  if (!session) {
    await new Promise((resolve) => setTimeout(resolve, 120));
    session = await getSessionUser();
  }

  if (!session) {
    const dbUp = await dbHealthy();
    if (!dbUp) {
      return Response.json(
        { user: null, unavailable: true, error: "Session store is warming up." },
        { status: 503, headers: { "Cache-Control": "no-store" } },
      );
    }
    return Response.json(
      { user: null, sessionValid: false },
      { headers: { "Cache-Control": "no-store" } },
    );
  }

  void touchSession(session.sessionId);

  let stats = { bookmarks: 0, messages: 0, mirrors: 0, memberSince: session.user.createdAt };

  try {
    const { profile } = await ensureProfile();
    const [bookmarkCount] = await db
      .select({ value: count() })
      .from(bookmarks)
      .where(eq(bookmarks.profileId, profile.id));
    const [messageCount] = await db
      .select({ value: count() })
      .from(chatMessages)
      .where(and(eq(chatMessages.userId, session.user.id)));
    const [mirrorCount] = await db.select({ value: count() }).from(mirrors);

    stats = {
      bookmarks: Number(bookmarkCount?.value ?? 0),
      messages: Number(messageCount?.value ?? 0),
      mirrors: Number(mirrorCount?.value ?? 0),
      memberSince: session.user.createdAt,
    };
  } catch {
    // Stats are cosmetic; the session itself is already validated.
  }

  let avatar = parseAvatar("");
  let effect = parseEffect("");
  try {
    const [row] = await db
      .select({ avatar: users.avatar, effect: users.avatarEffect })
      .from(users)
      .where(eq(users.id, session.user.id))
      .limit(1);
    avatar = parseAvatar(row?.avatar);
    effect = parseEffect(row?.effect);
  } catch {
    // keep the defaults if the lookup fails
  }

  // Hand the bearer its own token so the client can mirror it and stay signed
  // in even where cookies are blocked (cross-site iframes, strict browsers).
  let token: string | undefined;
  try {
    token = (await cookies()).get(SESSION_COOKIE)?.value;
  } catch {
    token = undefined;
  }
  if (!token) {
    // Authenticated through the mirrored header (cookies blocked): echo it back
    // so the client keeps a durable copy instead of losing the session.
    try {
      token = (await headers()).get(SESSION_HEADER) ?? undefined;
    } catch {
      token = undefined;
    }
  }

  return Response.json(
    {
      user: { ...session.user, avatar, effect },
      stats,
      persisted: true,
      sessionValid: true,
      token,
    },
    { headers: { "Cache-Control": "no-store" } },
  );
}
