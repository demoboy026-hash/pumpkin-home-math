import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  clearSessionCookie,
  cookiePolicy,
  destroyCurrentSession,
  getSessionUser,
  isTrustedOrigin,
} from "@/lib/auth";
import { clearProfileCookie } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function DELETE(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) {
    return Response.json({ error: "You are not signed in." }, { status: 401 });
  }

  try {
    await destroyCurrentSession();
    // Deleting the user cascades to sessions, the profile and its bookmarks.
    await db.delete(users).where(eq(users.id, session.user.id));
  } catch {
    return Response.json({ error: "Could not delete the account." }, { status: 500 });
  }

  const policy = cookiePolicy(request);
  const response = Response.json({ ok: true });
  response.headers.append("Set-Cookie", clearSessionCookie(policy));
  return clearProfileCookie(response, policy);
}
