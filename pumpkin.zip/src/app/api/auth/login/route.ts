import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles, users } from "@/db/schema";
import {
  cookiePolicy,
  createSession,
  isTrustedOrigin,
  normalizeUsername,
  sessionCookie,
  verifyPassword,
} from "@/lib/auth";
import { attachProfileCookie } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const body = (await request.json()) as { username?: unknown; password?: unknown };
    const username = normalizeUsername(typeof body.username === "string" ? body.username : "");
    const password = typeof body.password === "string" ? body.password : "";

    if (!username || !password) {
      return Response.json({ error: "Enter your username and password." }, { status: 400 });
    }

    const [user] = await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (!user) {
      return Response.json(
        {
          error: `No account called “${username}” on this pumpkin. Create it first — it only takes a second.`,
          code: "no_account",
        },
        { status: 401 },
      );
    }
    if (!verifyPassword(password, user.passwordHash)) {
      return Response.json(
        { error: "That password does not match this account.", code: "bad_password" },
        { status: 401 },
      );
    }

    let [profile] = await db.select().from(profiles).where(eq(profiles.userId, user.id)).limit(1);
    if (!profile) {
      [profile] = await db.insert(profiles).values({ userId: user.id }).returning();
    }

    const session = await createSession(user.id);
    const policy = cookiePolicy(request);
    const response = Response.json({
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        createdAt: user.createdAt.toISOString(),
      },
      token: session.token,
      expiresAt: session.expiresAt.toISOString(),
    });
    response.headers.append("Set-Cookie", sessionCookie(session.token, policy));
    return attachProfileCookie(response, profile.id, policy);
  } catch {
    return Response.json({ error: "Could not sign in. Try again." }, { status: 500 });
  }
}
