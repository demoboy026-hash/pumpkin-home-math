import { cookiePolicy, getSessionUserFromToken, sessionCookie, touchSession } from "@/lib/auth";
import { ensureProfile } from "@/lib/profile";

export const dynamic = "force-dynamic";

/**
 * Validates a mirrored session token and, when it is still live, re-establishes
 * the cookie so the saved login works again. This is what the "Restore" button
 * calls — it must always answer clearly: restored, expired or unknown.
 */
export async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get("token")?.trim() ?? "";

  if (!token || !/^[a-f0-9]{64}$/i.test(token)) {
    return Response.json(
      { restored: false, reason: "missing", error: "No saved session was found on this device." },
      { status: 400, headers: { "Cache-Control": "no-store" } },
    );
  }

  const session = await getSessionUserFromToken(token);
  if (!session) {
    return Response.json(
      {
        restored: false,
        reason: "expired",
        error: "That saved session has expired or was signed out. Sign in again to keep your account.",
      },
      { status: 401, headers: { "Cache-Control": "no-store" } },
    );
  }

  // Sliding expiry plus a fresh cookie so the session behaves like a new sign-in.
  await touchSession(session.sessionId);
  const { profile } = await ensureProfile();

  const response = Response.json(
    { restored: true, user: session.user, profileId: profile.id },
    { headers: { "Cache-Control": "no-store" } },
  );
  const policy = cookiePolicy(request);
  response.headers.append("Set-Cookie", sessionCookie(token, policy));
  return response;
}
