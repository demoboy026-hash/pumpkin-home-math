import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser, hashPassword, isTrustedOrigin, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) {
    return Response.json({ error: "Sign in first." }, { status: 401 });
  }

  try {
    const body = (await request.json()) as {
      currentPassword?: unknown;
      newPassword?: unknown;
      displayName?: unknown;
    };
    const currentPassword = typeof body.currentPassword === "string" ? body.currentPassword : "";
    const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
    const displayName =
      typeof body.displayName === "string" ? body.displayName.trim().slice(0, 40) : undefined;

    const [user] = await db.select().from(users).where(eq(users.id, session.user.id)).limit(1);
    if (!user) return Response.json({ error: "Account not found." }, { status: 404 });

    const updates: { displayName?: string; passwordHash?: string } = {};

    if (newPassword) {
      if (!verifyPassword(currentPassword, user.passwordHash)) {
        return Response.json({ error: "Current password is incorrect." }, { status: 403 });
      }
      if (newPassword.length < 8) {
        return Response.json({ error: "New password needs at least 8 characters." }, { status: 400 });
      }
      updates.passwordHash = hashPassword(newPassword);
    }

    if (displayName && displayName !== user.displayName) {
      updates.displayName = displayName;
    }

    if (Object.keys(updates).length === 0) {
      return Response.json({ error: "Nothing to update." }, { status: 400 });
    }

    const [updated] = await db.update(users).set(updates).where(eq(users.id, user.id)).returning();

    return Response.json({
      user: {
        id: updated.id,
        username: updated.username,
        displayName: updated.displayName,
        createdAt: updated.createdAt.toISOString(),
      },
    });
  } catch {
    return Response.json({ error: "Could not update the account." }, { status: 500 });
  }
}
