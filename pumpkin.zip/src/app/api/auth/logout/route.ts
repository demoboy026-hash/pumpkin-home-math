import { clearSessionCookie, cookiePolicy, destroyCurrentSession, isTrustedOrigin } from "@/lib/auth";
import { clearProfileCookie } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    await destroyCurrentSession();
  } catch {
    // Signing out should never fail loudly.
  }
  const policy = cookiePolicy(request);
  const response = Response.json({ ok: true });
  response.headers.append("Set-Cookie", clearSessionCookie(policy));
  return clearProfileCookie(response, policy);
}
