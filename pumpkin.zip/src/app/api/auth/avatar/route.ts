import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import {
  AVATAR_PRESETS,
  parseAvatar,
  parseEffect,
  serializeAvatar,
  type AvatarConfig,
} from "@/lib/avatars";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getSessionUser();
  if (!session) return Response.json({ avatar: null });

  const [row] = await db
    .select({ avatar: users.avatar, effect: users.avatarEffect })
    .from(users)
    .where(eq(users.id, session.user.id))
    .limit(1);
  return Response.json({ avatar: parseAvatar(row?.avatar), effect: parseEffect(row?.effect) });
}

export async function PUT(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Sign in first." }, { status: 401 });

  try {
    const body = (await request.json()) as {
      avatar?: (Partial<AvatarConfig> & { presetId?: string }) | null;
      effect?: unknown;
      kind?: string;
      presetId?: string;
      mediaId?: string;
      animated?: boolean;
    };

    const [current] = await db
      .select({ avatar: users.avatar, effect: users.avatarEffect })
      .from(users)
      .where(eq(users.id, session.user.id))
      .limit(1);

    const incoming = body.avatar ?? (body.kind ? body : null);
    let config: AvatarConfig = parseAvatar(current?.avatar);

    if (incoming) {
      if (incoming.kind === "media" && typeof incoming.mediaId === "string" && incoming.mediaId) {
        config = {
          kind: "media",
          mediaId: incoming.mediaId.slice(0, 64),
          animated: incoming.animated !== false,
        };
      } else if (incoming.kind === "initials") {
        config = { kind: "initials" };
      } else if (incoming.kind === "preset") {
        const presetId =
          typeof incoming.presetId === "string" &&
          AVATAR_PRESETS.some((preset) => preset.id === incoming.presetId)
            ? incoming.presetId
            : AVATAR_PRESETS[0].id;
        config = { kind: "preset", presetId };
      }
    }

    const effect =
      typeof body.effect === "string" ? parseEffect(body.effect) : parseEffect(current?.effect);

    await db
      .update(users)
      .set({ avatar: serializeAvatar(config), avatarEffect: effect })
      .where(eq(users.id, session.user.id));

    return Response.json({ avatar: config, effect });
  } catch {
    return Response.json({ error: "Could not save that avatar." }, { status: 500 });
  }
}
