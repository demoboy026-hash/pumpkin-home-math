import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles, users } from "@/db/schema";
import {
  createSession,
  hashPassword,
  cookiePolicy,
  isTrustedOrigin,
  normalizeUsername,
  sessionCookie,
  validUsername,
  verifyPassword,
} from "@/lib/auth";
import { adoptAnonymousProfile, attachProfileCookie } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const body = (await request.json()) as {
      username?: unknown;
      password?: unknown;
      displayName?: unknown;
    };

    const username = normalizeUsername(typeof body.username === "string" ? body.username : "");
    const password = typeof body.password === "string" ? body.password : "";
    const displayNameRaw = typeof body.displayName === "string" ? body.displayName.trim() : "";

    if (!validUsername(username)) {
      return Response.json(
        { error: "Username needs 3–24 characters: letters, numbers or underscores." },
        { status: 400 },
      );
    }
    if (password.length < 8) {
      return Response.json({ error: "Use at least 8 characters for your password." }, { status: 400 });
    }

    const existing = await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (existing.length > 0) {
      // Retrying "create account" for an account you already made should sign you
      // in rather than look like the save failed.
      const existingUser = existing[0];
      if (verifyPassword(password, existingUser.passwordHash)) {
        let [profile] = await db
          .select()
          .from(profiles)
          .where(eq(profiles.userId, existingUser.id))
          .limit(1);
        if (!profile) {
          [profile] = await db.insert(profiles).values({ userId: existingUser.id }).returning();
        }
        const session = await createSession(existingUser.id);
        const policy = cookiePolicy(request);
        const signedIn = Response.json({
          user: {
            id: existingUser.id,
            username: existingUser.username,
            displayName: existingUser.displayName,
            createdAt: existingUser.createdAt.toISOString(),
          },
          existing: true,
          token: session.token,
          expiresAt: session.expiresAt.toISOString(),
        });
        signedIn.headers.append("Set-Cookie", sessionCookie(session.token, policy));
        return attachProfileCookie(signedIn, profile.id, policy);
      }
      return Response.json(
        { error: "That username is already taken.", code: "username_taken" },
        { status: 409 },
      );
    }

    const [user] = await db
      .insert(users)
      .values({
        username,
        displayName: (displayNameRaw || username).slice(0, 40),
        passwordHash: hashPassword(password),
      })
      .returning();

    // Carry over whatever this device already saved (bookmarks, panic key, theme).
    const adopted = await adoptAnonymousProfile(user.id);
    const profile =
      adopted ??
      (
        await db
          .insert(profiles)
          .values({ userId: user.id, disguiseTitle: "Canvas — Course Dashboard" })
          .returning()
      )[0];

    const session = await createSession(user.id);
    const policy = cookiePolicy(request);
    const response = Response.json({
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        createdAt: user.createdAt.toISOString(),
      },
      adopted: Boolean(adopted),
      token: session.token,
      expiresAt: session.expiresAt.toISOString(),
    });
    response.headers.append("Set-Cookie", sessionCookie(session.token, policy));
    return attachProfileCookie(response, profile.id, policy);
  } catch {
    return Response.json({ error: "Could not create that account. Try again." }, { status: 500 });
  }
}
