import { randomBytes } from "node:crypto";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { mirrors } from "@/db/schema";
import { isTrustedOrigin } from "@/lib/auth";

export const dynamic = "force-dynamic";

const ALPHABET = "23456789abcdefghjkmnpqrstuvwxyz";

function makeCode(length = 7) {
  const bytes = randomBytes(length);
  let code = "";
  for (let index = 0; index < length; index += 1) {
    code += ALPHABET[bytes[index] % ALPHABET.length];
  }
  return code;
}

function serialize(row: typeof mirrors.$inferSelect) {
  return {
    id: row.id,
    code: row.code,
    label: row.label,
    target: row.target,
    visits: row.visits,
    createdAt: row.createdAt.toISOString(),
  };
}

export async function GET() {
  try {
    const rows = await db.select().from(mirrors).orderBy(desc(mirrors.id)).limit(40);
    return Response.json({ mirrors: rows.map(serialize) });
  } catch {
    return Response.json({ error: "Could not load mirrors", mirrors: [] }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const body = (await request.json()) as { label?: unknown; target?: unknown };
    const rawLabel = typeof body.label === "string" ? body.label.trim() : "";
    const rawTarget = typeof body.target === "string" ? body.target.trim() : "/";
    const target = rawTarget.startsWith("/") && !rawTarget.startsWith("//") ? rawTarget.slice(0, 160) : "/";

    for (let attempt = 0; attempt < 6; attempt += 1) {
      const code = makeCode();
      try {
        const [created] = await db
          .insert(mirrors)
          .values({
            code,
            label: (rawLabel || "pumpkin mirror").slice(0, 60),
            target,
          })
          .returning();
        return Response.json({ mirror: serialize(created) });
      } catch (error) {
        const message = error instanceof Error ? error.message : "";
        if (!message.includes("duplicate key")) throw error;
      }
    }
    return Response.json({ error: "Could not allocate a mirror code" }, { status: 500 });
  } catch {
    return Response.json({ error: "Could not create mirror" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!Number.isInteger(id) || id <= 0) {
      return Response.json({ error: "Invalid mirror" }, { status: 400 });
    }
    await db.delete(mirrors).where(eq(mirrors.id, id));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Could not remove mirror" }, { status: 500 });
  }
}
