import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { presence, users } from "@/db/schema";
import { getSessionUser, isTrustedOrigin } from "@/lib/auth";
import { parseAvatar, parseEffect } from "@/lib/avatars";

export const dynamic = "force-dynamic";

/** Someone counts as online if they checked in during this window. */
const ONLINE_WINDOW_SECONDS = 75;
const VISITOR_RE = /^[A-Za-z0-9_-]{8,64}$/;

async function counts() {
  const cutoff = new Date(Date.now() - ONLINE_WINDOW_SECONDS * 1000);

  const [row] = await db
    .select({
      online: sql<number>`count(distinct ${presence.visitorId})`,
      members: sql<number>`count(distinct ${presence.userId})`,
    })
    .from(presence)
    .where(gte(presence.lastSeenAt, cutoff));

  return {
    online: Number(row?.online ?? 0),
    members: Number(row?.members ?? 0),
    guests: Math.max(0, Number(row?.online ?? 0) - Number(row?.members ?? 0)),
    windowSeconds: ONLINE_WINDOW_SECONDS,
  };
}

export async function GET() {
  try {
    const cutoff = new Date(Date.now() - ONLINE_WINDOW_SECONDS * 1000);
    const [stats] = await db
      .select({ online: sql<number>`count(distinct ${presence.visitorId})` })
      .from(presence)
      .where(gte(presence.lastSeenAt, cutoff));

    const people = await db
      .select({
        visitorId: presence.visitorId,
        displayName: presence.displayName,
        path: presence.path,
        lastSeenAt: presence.lastSeenAt,
        userId: presence.userId,
        username: users.username,
        avatar: users.avatar,
        avatarEffect: users.avatarEffect,
      })
      .from(presence)
      .leftJoin(users, eq(presence.userId, users.id))
      .where(and(gte(presence.lastSeenAt, cutoff)))
      .orderBy(sql`${presence.lastSeenAt} desc`)
      .limit(60);

    return Response.json(
      {
        ...(await counts()),
        people: people.map((person) => ({
          key: person.visitorId,
          name: person.username ? `@${person.username}` : person.displayName || "guest",
          displayName: person.username ? person.username : person.displayName || "guest",
          path: person.path,
          lastSeenAt: person.lastSeenAt.toISOString(),
          avatar: person.avatar ? JSON.stringify(parseAvatar(person.avatar)) : null,
          effect: person.avatarEffect ? parseEffect(person.avatarEffect) : "none",
          member: Boolean(person.userId),
        })),
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json({ online: 0, members: 0, guests: 0, people: [] }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return Response.json({ error: "Blocked cross-site request." }, { status: 403 });
  }

  try {
    const body = (await request.json()) as { visitorId?: unknown; path?: unknown };
    const visitorId = typeof body.visitorId === "string" ? body.visitorId.trim() : "";
    if (!VISITOR_RE.test(visitorId)) {
      return Response.json({ error: "Invalid visitor id." }, { status: 400 });
    }

    const rawPath = typeof body.path === "string" ? body.path : "/";
    const path = rawPath.startsWith("/") ? rawPath.slice(0, 120) : "/";
    const session = await getSessionUser();

    await db
      .insert(presence)
      .values({
        visitorId,
        userId: session?.user.id ?? null,
        displayName: session?.user.displayName.slice(0, 40) ?? "guest",
        path,
        lastSeenAt: new Date(),
      })
      .onConflictDoUpdate({
        target: presence.visitorId,
        set: {
          userId: session?.user.id ?? null,
          displayName: session?.user.displayName.slice(0, 40) ?? "guest",
          path,
          lastSeenAt: new Date(),
        },
      });

    // Housekeeping: drop stale rows so the table never grows without bound.
    await db
      .delete(presence)
      .where(sql`${presence.lastSeenAt} < now() - interval '2 days'`);

    return Response.json(await counts(), { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ online: 0, members: 0, guests: 0 }, { status: 500 });
  }
}
