import { and, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { friendships } from "@/db/schema";

export type FriendStatus = "none" | "pending_out" | "pending_in" | "friends" | "self";

export type Relation = {
  id: number;
  requesterId: string;
  addresseeId: string;
  status: string;
};

/** Finds the single friendship row between two users, in either direction. */
export async function relationBetween(userId: string, otherId: string): Promise<Relation | null> {
  const rows = await db
    .select()
    .from(friendships)
    .where(
      or(
        and(eq(friendships.requesterId, userId), eq(friendships.addresseeId, otherId)),
        and(eq(friendships.requesterId, otherId), eq(friendships.addresseeId, userId)),
      ),
    )
    .limit(1);

  const row = rows[0];
  if (!row) return null;
  return {
    id: row.id,
    requesterId: row.requesterId,
    addresseeId: row.addresseeId,
    status: row.status,
  };
}

export function statusFor(userId: string, otherId: string, relation: Relation | null): FriendStatus {
  if (userId === otherId) return "self";
  if (!relation) return "none";
  if (relation.status === "accepted") return "friends";
  return relation.requesterId === userId ? "pending_out" : "pending_in";
}

export async function areFriends(userId: string, otherId: string) {
  const relation = await relationBetween(userId, otherId);
  return relation?.status === "accepted";
}

/** Everyone else on this pumpkin, so people can actually find each other. */
export async function listOtherUserIds(userId: string) {
  const rows = await db
    .select({ id: friendships.requesterId, other: friendships.addresseeId })
    .from(friendships)
    .where(or(eq(friendships.requesterId, userId), eq(friendships.addresseeId, userId)));

  const ids = new Set<string>();
  rows.forEach((row) => {
    ids.add(row.id === userId ? row.other : row.id);
  });
  ids.delete(userId);
  return [...ids];
}

export function otherParticipant(userId: string, relation: Relation) {
  return relation.requesterId === userId ? relation.addresseeId : relation.requesterId;
}
