export const STREAMX_URL = "https://www.streamxtv.net/about#google_vignette";
export const STREAMX_HOME = "https://www.streamxtv.net";
export const PANIC_FALLBACK = "https://classroom.google.com/";

export const ACCENT_DEFAULT = "#ff7a18";
