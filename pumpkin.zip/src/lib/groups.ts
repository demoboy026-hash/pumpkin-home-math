import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { groupMembers, groups } from "@/db/schema";

export type GroupRole = "owner" | "member";

export async function membership(groupId: number, userId: string) {
  const [row] = await db
    .select({ role: groupMembers.role, groupId: groupMembers.groupId })
    .from(groupMembers)
    .where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, userId)))
    .limit(1);
  return row ?? null;
}

export async function loadGroupForMember(groupId: number, userId: string) {
  if (!Number.isInteger(groupId) || groupId <= 0) return null;
  const member = await membership(groupId, userId);
  if (!member) return null;
  const [group] = await db.select().from(groups).where(eq(groups.id, groupId)).limit(1);
  if (!group) return null;
  return { group, role: member.role as GroupRole };
}

export function canManage(role: GroupRole) {
  return role === "owner";
}
