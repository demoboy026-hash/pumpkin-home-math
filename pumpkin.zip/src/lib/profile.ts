import { cookies } from "next/headers";
import { eq, isNull, and } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";

export const PROFILE_COOKIE = "pumpkin_profile";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export type ProfileRow = typeof profiles.$inferSelect;

export async function readProfileCookie() {
  const store = await cookies();
  return store.get(PROFILE_COOKIE)?.value ?? null;
}

/**
 * Resolves the profile that every feature writes to. A signed-in account always
 * wins, so settings and bookmarks follow the user across devices and visits.
 * Anonymous visitors keep the original cookie-based profile.
 */
export async function ensureProfile(): Promise<{ profile: ProfileRow; created: boolean }> {
  const session = await getSessionUser();

  if (session) {
    const [owned] = await db
      .select()
      .from(profiles)
      .where(eq(profiles.userId, session.user.id))
      .limit(1);
    if (owned) return { profile: owned, created: false };

    const [createdForUser] = await db
      .insert(profiles)
      .values({ userId: session.user.id })
      .returning();
    return { profile: createdForUser, created: true };
  }

  const existingId = await readProfileCookie();

  if (existingId && UUID_RE.test(existingId)) {
    const [existing] = await db.select().from(profiles).where(eq(profiles.id, existingId)).limit(1);
    if (existing) return { profile: existing, created: false };
  }

  const [created] = await db.insert(profiles).values({}).returning();
  return { profile: created, created: true };
}

/** Links the current device's anonymous profile to a new account, keeping its data. */
export async function adoptAnonymousProfile(userId: string): Promise<ProfileRow | null> {
  const existingId = await readProfileCookie();
  if (!existingId || !UUID_RE.test(existingId)) return null;

  try {
    const [adopted] = await db
      .update(profiles)
      .set({ userId })
      .where(and(eq(profiles.id, existingId), isNull(profiles.userId)))
      .returning();
    return adopted ?? null;
  } catch {
    return null;
  }
}

/**
 * Read-only profile lookup for server rendering. Never inserts, so page views
 * cannot spawn orphan profiles — the API routes stay responsible for creation.
 */
export async function readProfileForRender(): Promise<ProfileRow | null> {
  try {
    const session = await getSessionUser();
    if (session) {
      const [owned] = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, session.user.id))
        .limit(1);
      if (owned) return owned;
      const [cookieProfile] = await readCookieProfile();
      return cookieProfile;
    }
    const [fromCookie] = await readCookieProfile();
    return fromCookie;
  } catch {
    return null;
  }
}

async function readCookieProfile(): Promise<ProfileRow[]> {
  const existingId = await readProfileCookie();
  if (!existingId || !UUID_RE.test(existingId)) return [];
  return db.select().from(profiles).where(eq(profiles.id, existingId)).limit(1);
}

type CookiePolicy = { secure: boolean; sameSite: "None" | "Lax" };

export function attachProfileCookie<T extends Response>(
  response: T,
  profileId: string,
  policy: CookiePolicy,
): T {
  response.headers.append(
    "Set-Cookie",
    `${PROFILE_COOKIE}=${profileId}; Path=/; Max-Age=31536000; SameSite=${policy.sameSite}${
      policy.secure ? "; Secure" : ""
    }`,
  );
  return response;
}

export function clearProfileCookie<T extends Response>(response: T, policy: CookiePolicy): T {
  response.headers.append(
    "Set-Cookie",
    `${PROFILE_COOKIE}=; Path=/; Max-Age=0; SameSite=${policy.sameSite}${
      policy.secure ? "; Secure" : ""
    }`,
  );
  return response;
}
