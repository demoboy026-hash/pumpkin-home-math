export type BannerKind = "preset" | "upload" | "url";

export type Banner = {
  kind: BannerKind;
  presetId: string;
  mediaId: string;
  url: string;
  fit: "cover" | "contain";
  height: 120 | 170 | 230;
  overlay: number;
  title: string;
  subtitle: string;
  animated: boolean;
};

export const DEFAULT_BANNER: Banner = {
  kind: "preset",
  presetId: "haunted-hills",
  mediaId: "",
  url: "",
  fit: "cover",
  height: 170,
  overlay: 0.45,
  title: "",
  subtitle: "",
  animated: true,
};

export type PresetPalette = { sky: string; glow: string; hill: string; accent: string };

export type Preset =
  | {
      id: string;
      name: string;
      description: string;
      animated: boolean;
      palette: PresetPalette;
      animation: string;
    }
  | {
      id: string;
      name: string;
      description: string;
      animated: boolean;
      palette: PresetPalette;
      scene: "haunted-hills" | "moon-bats" | "candy-swirl" | "ember-rain" | "ghost-fog" | "pumpkin-patch";
    };

const CSS_PRESETS: Preset[] = [
  {
    id: "pumpkin-drip",
    name: "Pumpkin Drip",
    description: "Oozing gradient with a slow breathing glow.",
    animated: true,
    palette: { sky: "#2a0d05", glow: "#ff8a3d", hill: "#ff6a00", accent: "#ffd6a5" },
    animation: "pumpkinDrip 12s ease-in-out infinite",
  },
  {
    id: "midnight-moon",
    name: "Midnight Moon",
    description: "Deep violet sky with a drifting lunar halo.",
    animated: true,
    palette: { sky: "#0d0a1f", glow: "#a78bfa", hill: "#312e81", accent: "#e0e7ff" },
    animation: "moonDrift 18s ease-in-out infinite",
  },
  {
    id: "ember-sweep",
    name: "Ember Sweep",
    description: "A molten highlight sweeping across charcoal.",
    animated: true,
    palette: { sky: "#12100e", glow: "#ff7a18", hill: "#3a1d0c", accent: "#ffb46b" },
    animation: "emberSweep 9s linear infinite",
  },
  {
    id: "quiet",
    name: "Quiet Study",
    description: "Static, low-contrast banner for a calm look.",
    animated: false,
    palette: { sky: "#171310", glow: "#8a7a6a", hill: "#241c16", accent: "#e7e5e4" },
    animation: "none",
  },
];

export const PRESET_SCENES: Preset[] = [
  {
    id: "haunted-hills",
    name: "Haunted Hills",
    description: "Rolling silhouettes, drifting fog and a moon that pulses.",
    animated: true,
    palette: { sky: "#1b0f2b", glow: "#c084fc", hill: "#0c0713", accent: "#ffd6a5" },
    scene: "haunted-hills",
  },
  {
    id: "moon-bats",
    name: "Moon Bats",
    description: "Bats crossing a full moon, animated across the banner.",
    animated: true,
    palette: { sky: "#100b1c", glow: "#e9d5ff", hill: "#08060d", accent: "#c084fc" },
    scene: "moon-bats",
  },
  {
    id: "candy-swirl",
    name: "Candy Swirl",
    description: "Rotating candy stripes in pumpkin and plum.",
    animated: true,
    palette: { sky: "#2a0f1d", glow: "#fb7185", hill: "#ff7a18", accent: "#fde68a" },
    scene: "candy-swirl",
  },
  {
    id: "ember-rain",
    name: "Ember Rain",
    description: "Falling embers over a warped harvest sky.",
    animated: true,
    palette: { sky: "#160a05", glow: "#ff8a3d", hill: "#3d1505", accent: "#ffb46b" },
    scene: "ember-rain",
  },
  {
    id: "ghost-fog",
    name: "Ghost Fog",
    description: "Layered fog banks sliding in opposite directions.",
    animated: true,
    palette: { sky: "#0f1216", glow: "#93c5fd", hill: "#1e293b", accent: "#e2e8f0" },
    scene: "ghost-fog",
  },
  {
    id: "pumpkin-patch",
    name: "Pumpkin Patch",
    description: "A field of glowing pumpkins under a starless sky.",
    animated: true,
    palette: { sky: "#1c0d08", glow: "#ff7a18", hill: "#2b130a", accent: "#ffd6a5" },
    scene: "pumpkin-patch",
  },
  ...CSS_PRESETS,
];

export const BANNER_PRESETS: Preset[] = [...PRESET_SCENES];

export function presetById(id: string): Preset {
  return BANNER_PRESETS.find((preset) => preset.id === id) ?? BANNER_PRESETS[0];
}

export const MEDIA_LIMITS = {
  video: 15 * 1024 * 1024,
  image: 6 * 1024 * 1024,
};

export const VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime", "video/ogg", "video/x-m4v"];
export const IMAGE_TYPES = ["image/gif", "image/png", "image/jpeg", "image/webp", "image/avif"];

export function mediaKindFor(mime: string): "video" | "image" | null {
  if (VIDEO_TYPES.includes(mime) || mime.startsWith("video/")) return "video";
  if (IMAGE_TYPES.includes(mime) || mime.startsWith("image/")) return "image";
  return null;
}

export function bannerHeightClass(height: Banner["height"]) {
  if (height === 120) return "h-[120px]";
  if (height === 230) return "h-[230px]";
  return "h-[170px]";
}

export function bannerToQuery(banner: Banner) {
  return encodeURIComponent(JSON.stringify(banner));
}

export function bannerFromQuery(raw: string | null): Banner {
  if (!raw) return DEFAULT_BANNER;
  try {
    const parsed = JSON.parse(decodeURIComponent(raw)) as Partial<Banner>;
    return { ...DEFAULT_BANNER, ...parsed };
  } catch {
    return DEFAULT_BANNER;
  }
}
