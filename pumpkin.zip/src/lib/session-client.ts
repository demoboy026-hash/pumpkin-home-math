"use client";

export const SESSION_TOKEN_KEY = "pumpkin.token";
export const SESSION_USER_KEY = "pumpkin.account";
export const SESSION_HEADER = "x-pumpkin-session";

export type CachedUser = {
  id: string;
  username: string;
  displayName: string;
  createdAt: string;
  avatar?: string | null;
  effect?: string | null;
};

/** Keeps the signed-in identity on the device so navigation never loses it. */
export function storeCachedUser(user: CachedUser | null) {
  try {
    if (user) window.localStorage.setItem(SESSION_USER_KEY, JSON.stringify(user));
    else window.localStorage.removeItem(SESSION_USER_KEY);
  } catch {
    // storage can be unavailable in private windows
  }
}

export function readCachedUser(): CachedUser | null {
  try {
    const raw = window.localStorage.getItem(SESSION_USER_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as CachedUser;
    return parsed && typeof parsed.id === "string" ? parsed : null;
  } catch {
    return null;
  }
}

type PatchFlag = typeof globalThis & { __pumpkinFetchPatched?: boolean };

export function readSessionToken() {
  try {
    return window.localStorage.getItem(SESSION_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function storeSessionToken(token: string | null | undefined) {
  try {
    if (token) window.localStorage.setItem(SESSION_TOKEN_KEY, token);
    else window.localStorage.removeItem(SESSION_TOKEN_KEY);
  } catch {
    // storage can be unavailable in private windows
  }
}

/**
 * Mirrors the session token onto same-origin API calls. Installed when this
 * module is imported (before any component effect runs) so even the very first
 * `/api/auth/me` request is authenticated when cookies are unavailable.
 */
export function installSessionFetch() {
  if (typeof window === "undefined") return;
  const flag = globalThis as PatchFlag;
  if (flag.__pumpkinFetchPatched) return;
  flag.__pumpkinFetchPatched = true;

  const original = window.fetch.bind(window);
  window.fetch = (input, init) => {
    try {
      const url =
        typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
      const token = readSessionToken();
      if (token && url.startsWith("/")) {
        const request = input instanceof Request ? input : null;
        const merged = new Headers(init?.headers ?? request?.headers);
        if (!merged.has(SESSION_HEADER)) merged.set(SESSION_HEADER, token);
        if (request && !init) {
          return original(new Request(request, { headers: merged }));
        }
        return original(input, { ...init, headers: merged });
      }
    } catch {
      // fall through to the untouched request
    }
    return original(input, init);
  };
}

if (typeof window !== "undefined") installSessionFetch();
