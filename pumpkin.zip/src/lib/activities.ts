export type ActivityMeta = {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  category: "Classic" | "Puzzle" | "Reflex";
  accent: string;
  emoji: string;
  controls: string;
};

export const ACTIVITIES: ActivityMeta[] = [
  {
    slug: "snake",
    name: "Neon Snake",
    tagline: "Eat, grow, don't bite yourself.",
    description:
      "The classic snake format rebuilt on canvas. Wrap-free walls, speeding pace and a local best score that keeps you honest.",
    category: "Classic",
    accent: "#ff8a3d",
    emoji: "🐍",
    controls: "Arrow keys / WASD · on-screen pad on mobile",
  },
  {
    slug: "breakout",
    name: "Brick Burn",
    tagline: "One paddle against a wall of embers.",
    description:
      "Slide the paddle, keep the ball alive and clear every brick. Each level gets a little faster and a lot less forgiving.",
    category: "Classic",
    accent: "#ffb703",
    emoji: "🧱",
    controls: "Mouse, touch or ← → to move the paddle",
  },
  {
    slug: "memory",
    name: "Pumpkin Pairs",
    tagline: "A calmer kind of brain burn.",
    description:
      "Flip cards, find matching pairs and finish the board in as few moves as possible. Best runs are stored locally.",
    category: "Puzzle",
    accent: "#fb7185",
    emoji: "🃏",
    controls: "Click or tap cards to flip",
  },
  {
    slug: "halloween-pinball",
    name: "Halloween Pinball",
    tagline: "Haunted bumpers, tombstone targets, three silver balls.",
    description:
      "A full table built from scratch: charged plunger, two live flippers, pumpkin, ghost, bat and skull bumpers, plus tombstone drop targets. Chain hits for a ×5 combo.",
    category: "Classic",
    accent: "#c084fc",
    emoji: "🎃",
    controls: "← / A and → / L for flippers · hold space to charge the plunger · P pauses",
  },
  {
    slug: "target-rush",
    name: "Target Rush",
    tagline: "Thirty seconds. One glowing tile.",
    description:
      "Tap the highlighted tile as fast as you can before the clock runs out. Misses cost you time.",
    category: "Reflex",
    accent: "#a3e635",
    emoji: "🎯",
    controls: "Click or tap the lit tile",
  },
];

export function activityBySlug(slug: string) {
  return ACTIVITIES.find((activity) => activity.slug === slug);
}
