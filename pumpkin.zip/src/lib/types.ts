import type { Banner } from "@/lib/banners";

export type Accent = "ember" | "sunset" | "amber" | "mono";

export type Settings = {
  panicKey: string;
  panicUrl: string;
  panicEnabled: boolean;
  disguiseEnabled: boolean;
  disguiseTitle: string;
  accent: Accent;
  homepage: string;
  proxyDefault: boolean;
  openExternalNewTab: boolean;
  banner: Banner;
};

export type Bookmark = {
  id: number;
  label: string;
  url: string;
  createdAt?: string;
};

export type ChatRoomId = "main" | "gaming" | "dev";

export type ChatMessage = {
  id: number;
  room: ChatRoomId;
  author: string;
  body: string;
  createdAt: string;
  avatar?: string | null;
  authorEffect?: string | null;
};

export type MirrorRecord = {
  id: number;
  code: string;
  label: string;
  target: string;
  visits: number;
  createdAt: string;
};

export const DEFAULT_SETTINGS: Settings = {
  panicKey: "Escape",
  panicUrl: "https://classroom.google.com/",
  panicEnabled: true,
  disguiseEnabled: false,
  disguiseTitle: "Canvas — Course Dashboard",
  accent: "ember",
  homepage: "",
  proxyDefault: false,
  openExternalNewTab: true,
  banner: {
    kind: "preset",
    presetId: "haunted-hills",
    mediaId: "",
    url: "",
    fit: "cover",
    height: 170,
    overlay: 0.45,
    title: "",
    subtitle: "",
    animated: true,
  },
};

export const CHAT_ROOMS: {
  id: ChatRoomId;
  name: string;
  blurb: string;
  dot: string;
}[] = [
  {
    id: "main",
    name: "Main",
    blurb: "The lobby. Say hi, share links, hang out.",
    dot: "#ff9f43",
  },
  {
    id: "gaming",
    name: "Gaming",
    blurb: "Scores, squads and what everyone is playing.",
    dot: "#ffd166",
  },
  {
    id: "dev",
    name: "Dev",
    blurb: "Build notes, mirror requests and browser bugs.",
    dot: "#fb7185",
  },
];
