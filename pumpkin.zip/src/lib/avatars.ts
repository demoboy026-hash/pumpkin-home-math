export type AvatarPreset = {
  id: string;
  name: string;
  colors: { bg: string; ink: string; glow: string };
};

/** Animated SVG avatars. Each id is drawn by <AvatarView /> with its own motion. */
export const AVATAR_PRESETS: AvatarPreset[] = [
  { id: "pumpkin-glow", name: "Pumpkin Glow", colors: { bg: "#2a1206", ink: "#ff7a18", glow: "#ffd6a5" } },
  { id: "ghost-drift", name: "Ghost Drift", colors: { bg: "#161228", ink: "#e2e8f0", glow: "#a78bfa" } },
  { id: "bat-flap", name: "Bat Flap", colors: { bg: "#1b0f2b", ink: "#c084fc", glow: "#f0abfc" } },
  { id: "candy-swirl", name: "Candy Swirl", colors: { bg: "#2a0f1d", ink: "#fb7185", glow: "#fde68a" } },
  { id: "ember-eye", name: "Ember Eye", colors: { bg: "#150a05", ink: "#ff8a3d", glow: "#ffb46b" } },
  { id: "moon-wisp", name: "Moon Wisp", colors: { bg: "#101322", ink: "#e0e7ff", glow: "#93c5fd" } },
  { id: "skull-spin", name: "Skull Spin", colors: { bg: "#1c1418", ink: "#e7e5e4", glow: "#fb7185" } },
  { id: "raven", name: "Raven", colors: { bg: "#0f1013", ink: "#94a3b8", glow: "#38bdf8" } },
  { id: "static", name: "Initials", colors: { bg: "#221610", ink: "#ffd6a5", glow: "#ff7a18" } },
];

export const DEFAULT_AVATAR = "pumpkin-glow";

export type AvatarEffect = {
  id: string;
  name: string;
  description: string;
  accent: string;
};

/** Decorative overlays drawn around the avatar. Purely CSS/SVG — no uploads needed. */
export const AVATAR_EFFECTS: AvatarEffect[] = [
  { id: "none", name: "None", description: "Clean circle, no extras.", accent: "#94a3b8" },
  { id: "glow", name: "Ember Glow", description: "Pulsing halo that breathes.", accent: "#ff7a18" },
  { id: "flame", name: "Flames", description: "Embers rising off the rim.", accent: "#ff5a1f" },
  { id: "sparkle", name: "Sparkles", description: "Twinkling stars around the edge.", accent: "#ffd166" },
  { id: "ring", name: "Orbit Ring", description: "A dashed ring spinning slowly.", accent: "#c084fc" },
  { id: "orbit", name: "Moons", description: "Three little moons circling.", accent: "#93c5fd" },
  { id: "bat", name: "Bat Swarm", description: "Bats fluttering around you.", accent: "#a855f7" },
  { id: "bolt", name: "Static", description: "Flickering electric arcs.", accent: "#67e8f9" },
  { id: "frost", name: "Frost", description: "Snow drifting past the glass.", accent: "#e2e8f0" },
  { id: "candy", name: "Candy Rim", description: "Pumpkin-and-plum striped rim.", accent: "#fb7185" },
];

export const DEFAULT_EFFECT = "glow";

export function parseEffect(raw: string | null | undefined): string {
  if (!raw) return DEFAULT_EFFECT;
  return AVATAR_EFFECTS.some((effect) => effect.id === raw) ? raw : DEFAULT_EFFECT;
}

export function effectById(id: string): AvatarEffect {
  return AVATAR_EFFECTS.find((effect) => effect.id === id) ?? AVATAR_EFFECTS[0];
}

export type AvatarConfig =
  | { kind: "preset"; presetId: string }
  | { kind: "media"; mediaId: string; animated: boolean }
  | { kind: "initials" };

export function parseAvatar(raw: string | null | undefined): AvatarConfig {
  if (!raw) return { kind: "preset", presetId: DEFAULT_AVATAR };
  try {
    const parsed = JSON.parse(raw) as Partial<{ kind: string; presetId: string; mediaId: string; animated: boolean }>;
    if (parsed.kind === "media" && typeof parsed.mediaId === "string" && parsed.mediaId) {
      return { kind: "media", mediaId: parsed.mediaId.slice(0, 64), animated: parsed.animated !== false };
    }
    if (parsed.kind === "initials") return { kind: "initials" };
    if (parsed.kind === "preset" && typeof parsed.presetId === "string") {
      return { kind: "preset", presetId: parsed.presetId };
    }
    return { kind: "preset", presetId: DEFAULT_AVATAR };
  } catch {
    return { kind: "preset", presetId: DEFAULT_AVATAR };
  }
}

export function serializeAvatar(config: AvatarConfig) {
  return JSON.stringify(config);
}

export function avatarPreset(id: string) {
  return AVATAR_PRESETS.find((preset) => preset.id === id) ?? AVATAR_PRESETS[0];
}

export function initialsFor(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
}
