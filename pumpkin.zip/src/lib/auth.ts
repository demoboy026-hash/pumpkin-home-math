import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies, headers } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";

export const SESSION_COOKIE = "pumpkin_session";
export const SESSION_MAX_AGE = 60 * 60 * 24 * 365; // one year — stays signed in
export const SESSION_HEADER = "x-pumpkin-session";

/**
 * Only mark cookies Secure when the request actually arrived over https.
 * Using NODE_ENV alone broke sign-in whenever the app was opened over plain
 * http (local preview, IP address, some embeds): the browser silently threw
 * the session cookie away, so signing in looked like it never saved.
 */
export function requestIsHttps(request?: Request) {
  const forwarded = request?.headers.get("x-forwarded-proto")?.split(",")[0]?.trim();
  if (forwarded) return forwarded === "https";
  const origin = request?.headers.get("origin");
  if (origin) return origin.startsWith("https://");
  const referer = request?.headers.get("referer");
  if (referer) return referer.startsWith("https://");
  return false;
}

/**
 * Cookie policy for staying signed in.
 *
 * `SameSite=Lax` cookies are rejected by browsers when pumpkin runs inside a
 * cross-site iframe (embedded previews, portal wrappers), which made signing in
 * look like it never saved. Over https we therefore use `SameSite=None; Secure`
 * so the session survives in every context, and we compensate with origin
 * checks on state-changing requests. Over plain http we cannot use `None`
 * (browsers require Secure), so `Lax` is the best available.
 */
export function cookiePolicy(request?: Request) {
  const secure = requestIsHttps(request);
  return {
    secure,
    sameSite: (secure ? "None" : "Lax") as "None" | "Lax",
    crossSite: request?.headers.get("sec-fetch-site") === "cross-site",
  };
}

/** Blocks cross-origin state changes now that cookies travel on cross-site requests. */
export function isTrustedOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return true; // same-origin form posts / non-browser clients
  try {
    const host = request.headers.get("host");
    const forwardedHost = request.headers.get("x-forwarded-host");
    const originHost = new URL(origin).host;
    return originHost === host || (forwardedHost ? originHost === forwardedHost : false);
  } catch {
    return false;
  }
}

export type AccountUser = {
  id: string;
  username: string;
  displayName: string;
  createdAt: string;
};

export type SessionUser = { user: AccountUser; sessionId: string };

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  try {
    const candidate = scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return candidate.length === expected.length && timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

export function normalizeUsername(raw: string) {
  return raw.trim().toLowerCase();
}

export function validUsername(username: string) {
  return /^[a-z0-9_]{3,24}$/.test(username);
}

export type CookiePolicy = { secure: boolean; sameSite: "None" | "Lax" };

export function sessionCookie(
  token: string,
  policy: CookiePolicy,
  maxAge = SESSION_MAX_AGE,
) {
  return `${SESSION_COOKIE}=${token}; Path=/; Max-Age=${maxAge}; HttpOnly; SameSite=${policy.sameSite}${
    policy.secure ? "; Secure" : ""
  }`;
}

export function clearSessionCookie(policy: CookiePolicy) {
  return `${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=${policy.sameSite}${
    policy.secure ? "; Secure" : ""
  }`;
}

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_MAX_AGE * 1000);
  const [session] = await db.insert(sessions).values({ token, userId, expiresAt }).returning();
  await db.update(users).set({ lastSeenAt: new Date() }).where(eq(users.id, userId));
  return session;
}

async function readSessionToken() {
  const store = await cookies();
  const fromCookie = store.get(SESSION_COOKIE)?.value;
  if (fromCookie) return fromCookie;
  // Fallback for browsers/embeds that refuse cookies: the client mirrors the
  // token into localStorage and sends it on request headers instead.
  try {
    const headerStore = await headers();
    return headerStore.get(SESSION_HEADER) ?? null;
  } catch {
    return null;
  }
}

export async function getSessionUserFromToken(rawToken: string | null | undefined) {
  if (!rawToken) return null;

  try {
    const rows = await db
      .select({ user: users, sessionId: sessions.id })
      .from(sessions)
      .innerJoin(users, eq(sessions.userId, users.id))
      .where(and(eq(sessions.token, rawToken), gt(sessions.expiresAt, new Date())))
      .limit(1);

    const row = rows[0];
    if (!row) return null;

    return {
      sessionId: row.sessionId,
      user: {
        id: row.user.id,
        username: row.user.username,
        displayName: row.user.displayName,
        createdAt: row.user.createdAt.toISOString(),
      },
    };
  } catch {
    return null;
  }
}

export async function getSessionUser(): Promise<SessionUser | null> {
  return getSessionUserFromToken(await readSessionToken());
}

export async function destroyCurrentSession() {
  const token = await readSessionToken();
  if (!token) return;
  await db.delete(sessions).where(eq(sessions.token, token));
}

/** Sliding expiry so an active session never quietly lapses between visits. */
export async function touchSession(sessionId: string) {
  try {
    await db
      .update(sessions)
      .set({ expiresAt: new Date(Date.now() + SESSION_MAX_AGE * 1000) })
      .where(eq(sessions.id, sessionId));
  } catch {
    // Non-critical: the existing expiry still applies.
  }
}

export async function revokeAllSessions(userId: string) {
  await db.delete(sessions).where(eq(sessions.userId, userId));
}
