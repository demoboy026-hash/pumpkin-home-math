import { DEFAULT_SETTINGS, type Accent, type Settings } from "@/lib/types";
import { DEFAULT_BANNER, type Banner } from "@/lib/banners";

export const SETTINGS_KEY = "pumpkin.settings.v1";
export const HISTORY_KEY = "pumpkin.history.v1";
export const NICKNAME_KEY = "pumpkin.nickname.v1";

export const ACCENTS: { id: Accent; name: string; swatch: string; hint: string }[] = [
  { id: "ember", name: "Ember", swatch: "#ff7a18", hint: "Classic pumpkin" },
  { id: "sunset", name: "Sunset", swatch: "#ff4d6d", hint: "Warm coral" },
  { id: "amber", name: "Amber", swatch: "#ffb703", hint: "Golden harvest" },
  { id: "mono", name: "Mono", swatch: "#e7e5e4", hint: "Quiet & stealthy" },
];

export function readStoredSettings(): Settings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<Settings>;
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function writeStoredSettings(settings: Settings) {
  try {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Storage can be unavailable in private windows; settings still live in React state.
  }
}

const MODIFIER_KEYS = new Set(["Control", "Shift", "Alt", "Meta", "CapsLock", "Tab"]);

function keyLabel(key: string) {
  if (key === " ") return "Space";
  if (key.length === 1) return key.toUpperCase();
  return key;
}

/** Builds a stable "Ctrl+Shift+K" style combo from a keyboard event. */
export function comboFromEvent(event: Pick<KeyboardEvent, "key" | "ctrlKey" | "altKey" | "shiftKey" | "metaKey">) {
  if (MODIFIER_KEYS.has(event.key)) return "";
  const parts: string[] = [];
  if (event.ctrlKey) parts.push("Ctrl");
  if (event.altKey) parts.push("Alt");
  if (event.shiftKey) parts.push("Shift");
  if (event.metaKey) parts.push("Meta");
  parts.push(keyLabel(event.key));
  return parts.join("+");
}

export function prettyCombo(combo: string) {
  return combo
    .split("+")
    .map((part) => (part.length === 1 ? part.toUpperCase() : part))
    .join(" + ");
}

export function isEditableTarget(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false;
  const tag = target.tagName.toLowerCase();
  return tag === "input" || tag === "textarea" || tag === "select" || target.isContentEditable;
}

export function isSafeHttpUrl(value: string) {
  try {
    const parsed = new URL(value);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

export function parseBanner(raw: string | null | undefined): Banner {
  if (!raw) return DEFAULT_BANNER;
  try {
    const parsed = JSON.parse(raw) as Partial<Banner>;
    const kind = parsed.kind === "upload" || parsed.kind === "url" ? parsed.kind : "preset";
    const height = parsed.height === 120 || parsed.height === 230 ? parsed.height : 170;
    return {
      kind,
      presetId: typeof parsed.presetId === "string" && parsed.presetId ? parsed.presetId : DEFAULT_BANNER.presetId,
      mediaId: typeof parsed.mediaId === "string" ? parsed.mediaId.slice(0, 64) : "",
      url: typeof parsed.url === "string" ? parsed.url.slice(0, 800) : "",
      fit: parsed.fit === "contain" ? "contain" : "cover",
      height,
      overlay: typeof parsed.overlay === "number" ? Math.min(1, Math.max(0, parsed.overlay)) : 0.45,
      title: typeof parsed.title === "string" ? parsed.title.slice(0, 60) : "",
      subtitle: typeof parsed.subtitle === "string" ? parsed.subtitle.slice(0, 90) : "",
      animated: parsed.animated !== false,
    };
  } catch {
    return DEFAULT_BANNER;
  }
}

export function parseSettingsRow(row: {
  panicKey: string;
  panicUrl: string;
  panicEnabled: boolean;
  disguiseEnabled: boolean;
  disguiseTitle: string;
  accent: string;
  homepage: string;
  proxyDefault: boolean;
  banner?: string | null;
}): Settings {
  const accent = ACCENTS.some((item) => item.id === row.accent) ? (row.accent as Accent) : "ember";
  return {
    panicKey: row.panicKey,
    panicUrl: row.panicUrl,
    panicEnabled: row.panicEnabled,
    disguiseEnabled: row.disguiseEnabled,
    disguiseTitle: row.disguiseTitle,
    accent,
    homepage: row.homepage,
    proxyDefault: row.proxyDefault,
    openExternalNewTab: true,
    banner: parseBanner(row.banner),
  };
}

export function normalizeTarget(raw: string): string | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  if (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(trimmed)) return `https://${trimmed}`;
  return null;
}

export function looksLikeUrl(raw: string) {
  const trimmed = raw.trim();
  if (!trimmed || /\s/.test(trimmed)) return false;
  return /^https?:\/\//i.test(trimmed) || /^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(trimmed);
}

export function prettyHost(url: string) {
  try {
    const parsed = new URL(url);
    return parsed.hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

export function faviconFor(url: string) {
  try {
    const parsed = new URL(url);
    return `https://www.google.com/s2/favicons?domain=${parsed.hostname}&sz=64`;
  } catch {
    return "";
  }
}
