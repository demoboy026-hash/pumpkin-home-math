"use client";

import { useCallback, useSyncExternalStore } from "react";
import {
  readCachedUser,
  readSessionToken,
  storeCachedUser,
  storeSessionToken,
} from "@/lib/session-client";

export { readCachedUser, readSessionToken, storeCachedUser, storeSessionToken };

export type AccountStats = {
  bookmarks: number;
  messages: number;
  mirrors: number;
  memberSince: string;
};

export type AccountInfo = {
  id: string;
  username: string;
  displayName: string;
  createdAt: string;
  avatar?: string | null;
  effect?: string | null;
};

type MeResponse = {
  user?: AccountInfo | null;
  stats?: AccountStats;
  token?: string;
  sessionValid?: boolean;
  unavailable?: boolean;
};

export type AccountSnapshot = {
  user: AccountInfo | null;
  stats: AccountStats | null;
  loading: boolean;
  unavailable: boolean;
  hasToken: boolean;
  lastError: string | null;
};

const serverSnapshot: AccountSnapshot = {
  user: null,
  stats: null,
  loading: true,
  unavailable: false,
  hasToken: false,
  lastError: null,
};

let snapshot: AccountSnapshot = { ...serverSnapshot };
const listeners = new Set<() => void>();
let inflight: Promise<AccountSnapshot> | null = null;

/**
 * Every account read takes a ticket. Only the newest ticket may write state, so
 * a slow response started before sign-in can never overwrite the fresh account
 * that arrives after it (which made signing in look like being signed out).
 */
let ticket = 0;

/**
 * Right after an explicit sign-in/restore we pin the account for a short while.
 * A cookie-less or momentarily failing follow-up `/me` must never be able to
 * sign the user straight back out again.
 */
let pinnedUser: AccountInfo | null = null;
let graceUntil = 0;
const AUTH_GRACE_MS = 90_000;

function graceActive() {
  return Boolean(pinnedUser) && Date.now() < graceUntil;
}

export function pinAccount(user: AccountInfo, ms = AUTH_GRACE_MS) {
  pinnedUser = user;
  graceUntil = Date.now() + ms;
}

function unpinAccount() {
  pinnedUser = null;
  graceUntil = 0;
}

function syncCache(user: AccountInfo | null) {
  if (user) storeCachedUser(user);
  else storeCachedUser(null);
}

function commit(next: Partial<AccountSnapshot>, options: { force?: boolean } = {}) {
  const clearingUser = next.user === null;

  // Ignore attempts to clear the account during the post-auth grace window.
  if (clearingUser && !options.force && graceActive()) {
    snapshot = {
      ...snapshot,
      stats: snapshot.stats,
      loading: false,
      unavailable: Boolean(next.unavailable),
      lastError: next.lastError ?? snapshot.lastError,
      hasToken: typeof window !== "undefined" ? Boolean(readSessionToken()) : false,
    };
    listeners.forEach((listener) => listener());
    return;
  }

  if (clearingUser && options.force) unpinAccount();

  snapshot = {
    ...snapshot,
    ...next,
    hasToken: typeof window !== "undefined" ? Boolean(readSessionToken()) : false,
  };
  if ("user" in next) syncCache(snapshot.user);
  listeners.forEach((listener) => listener());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function getSnapshot() {
  return snapshot;
}

function getServerSnapshot() {
  return serverSnapshot;
}

/** Drop every request that is already in flight (call right after auth changes). */
export function invalidateAccountRequests() {
  ticket += 1;
  inflight = null;
}

async function requestMe(extraHeaders?: HeadersInit) {
  const response = await fetch("/api/auth/me", {
    cache: "no-store",
    credentials: "same-origin",
    headers: extraHeaders,
  });
  if (response.status === 503) return { unavailable: true } as MeResponse;
  if (!response.ok) throw new Error(`me failed: ${response.status}`);
  return (await response.json()) as MeResponse;
}

/** alive = confirmed, dead = server says the token is invalid, unknown = try later. */
async function probeSession(token: string): Promise<
  { state: "alive"; user: AccountInfo } | { state: "dead" } | { state: "unknown" }
> {
  try {
    const response = await fetch(`/api/auth/session?token=${encodeURIComponent(token)}`, {
      cache: "no-store",
    });
    if (response.status === 401) return { state: "dead" };
    if (!response.ok) return { state: "unknown" };
    const data = (await response.json()) as { restored?: boolean; user?: AccountInfo };
    if (data.restored && data.user) return { state: "alive", user: data.user };
    return { state: "dead" };
  } catch {
    return { state: "unknown" };
  }
}

async function loadAccount(myTicket: number): Promise<AccountSnapshot> {
  const token = readSessionToken();

  try {
    let data = await requestMe();

    // Cookies unavailable (embedded/strict browsers): replay the mirrored token.
    if (!data.user && token) data = await requestMe({ "x-pumpkin-session": token });

    // One more attempt after a short pause — a cold database can answer empty.
    if (!data.user && !data.unavailable) {
      await new Promise((resolve) => setTimeout(resolve, 250));
      data = token ? await requestMe({ "x-pumpkin-session": token }) : await requestMe();
    }

    if (myTicket !== ticket) return snapshot; // a newer request owns the state

    if (data.unavailable) {
      commit({ loading: false, unavailable: true, lastError: "Session store is warming up." });
      return snapshot;
    }

    if (!data.user && token) {
      // Before signing anyone out, confirm with the session endpoint that the
      // stored token is genuinely dead. A transient failure must NEVER delete it —
      // that was what logged people out after navigating away.
      const probe = await probeSession(token);
      if (myTicket !== ticket) return snapshot;

      if (probe.state === "alive") {
        pinAccount(probe.user);
        commit({ user: probe.user, loading: false, unavailable: false, lastError: null });
        void refreshAccount(true);
        return snapshot;
      }

      if (probe.state === "unknown") {
        const fallback = pinnedUser ?? readCachedUser();
        commit({
          user: fallback,
          loading: false,
          unavailable: true,
          lastError: "Could not verify the session yet — keeping you signed in.",
        });
        return snapshot;
      }

      // Definitively dead: drop the token and the cached identity.
      storeSessionToken(null);
      storeCachedUser(null);
    }

    if (data.token) storeSessionToken(data.token);
    commit({
      user: data.user ?? null,
      stats: data.stats ?? null,
      loading: false,
      unavailable: false,
      lastError: null,
    });
    return snapshot;
  } catch {
    if (myTicket !== ticket) return snapshot;
    commit({ loading: false, unavailable: true, lastError: "Could not reach the session store." });
    return snapshot;
  }
}

export function refreshAccount(force = false): Promise<AccountSnapshot> {
  if (!force && inflight) return inflight;

  const myTicket = ++ticket;
  const run = Promise.race([
    loadAccount(myTicket),
    new Promise<AccountSnapshot>((resolve) => {
      setTimeout(() => {
        if (myTicket === ticket) {
          commit({ loading: false, unavailable: true, lastError: "Session check timed out." });
        }
        resolve(snapshot);
      }, 9000);
    }),
  ]).finally(() => {
    inflight = null;
  });

  inflight = run;
  return run;
}

/** Applies a session returned by signup/login so the UI flips instantly. */
export function adoptSession(user: AccountInfo, token?: string | null) {
  if (token) storeSessionToken(token);
  storeCachedUser(user);
  invalidateAccountRequests();
  pinAccount(user);
  commit({ user, loading: false, unavailable: false, lastError: null }, { force: true });
}

export async function restoreSession(): Promise<{
  ok: boolean;
  message: string;
  user?: AccountInfo;
}> {
  const token = readSessionToken();
  if (!token) {
    commit({ hasToken: false, lastError: "There is no saved session on this device." });
    return { ok: false, message: "There is no saved session on this device." };
  }

  const myTicket = ++ticket;

  try {
    const response = await fetch(`/api/auth/session?token=${encodeURIComponent(token)}`, {
      cache: "no-store",
    });
    const data = (await response.json()) as {
      restored?: boolean;
      user?: AccountInfo;
      error?: string;
    };

    if (myTicket !== ticket) return { ok: false, message: "A newer session state took over." };

    if (!response.ok || !data.restored || !data.user) {
      if (response.status === 401) {
        storeSessionToken(null);
        storeCachedUser(null);
      }
      const message = data.error ?? "That saved session could not be restored.";
      commit({
        user: null,
        stats: null,
        loading: false,
        unavailable: false,
        hasToken: Boolean(readSessionToken()),
        lastError: message,
      });
      return { ok: false, message };
    }

    pinAccount(data.user);
    commit({ user: data.user, loading: false, unavailable: false, lastError: null }, { force: true });

    // Reconcile stats/avatar in the background; the pin keeps this from
    // flipping the account off if the cookie was not stored.
    void refreshAccount(true);
    return {
      ok: true,
      message: `Session restored — signed in as @${data.user.username}.`,
      user: data.user,
    };
  } catch {
    const message = "Could not reach the server. Check your connection and try again.";
    commit({ lastError: message });
    return { ok: false, message };
  }
}

export function forgetSavedSession() {
  storeSessionToken(null);
  storeCachedUser(null);
  invalidateAccountRequests();
  commit(
    { user: null, stats: null, loading: false, hasToken: false, lastError: null },
    { force: true },
  );
}

export function setAccountUser(next: AccountInfo | null) {
  if (next) {
    pinAccount(next);
    storeCachedUser(next);
  }
  commit({ user: next }, { force: next === null });
}

let bootStarted = false;
function startBoot() {
  if (bootStarted || typeof window === "undefined") return;
  bootStarted = true;

  // Show the saved identity immediately (navigation or reload) instead of
  // flashing the signed-out form while the session is verified again.
  const cached = readCachedUser();
  if (cached) {
    pinnedUser = cached;
    graceUntil = Date.now() + AUTH_GRACE_MS;
    snapshot = {
      ...snapshot,
      user: cached,
      loading: true,
      hasToken: Boolean(readSessionToken()),
    };
  }

  void refreshAccount().catch(() => commit({ loading: false }));
}

startBoot();

export function useAccount() {
  const state = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const refresh = useCallback((force = false) => refreshAccount(force), []);
  const setUser = useCallback((next: AccountInfo | null) => setAccountUser(next), []);

  return {
    ...state,
    refresh,
    setUser,
    setStats: (next: AccountStats | null) => commit({ stats: next }),
    signedOut: !state.loading && !state.user && !state.unavailable,
  };
}
